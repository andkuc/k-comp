#!/bin/bash
# K-Comp Board Rule Installer
# Run this once with sudo: sudo ./install_linux_rules.sh

echo "Installing udev rules for K-Comp (MCP2221A)..."

# 1. Create the rule file
echo 'SUBSYSTEM=="usb", ATTRS{idVendor}=="04d8", MODE="0666", GROUP="plugdev"' | sudo tee /etc/udev/rules.d/99-kcomp.rules > /dev/null

# 2. Reload rules
sudo udevadm control --reload-rules
sudo udevadm trigger

echo "Success! Please unplug and replug your K-Comp board."
