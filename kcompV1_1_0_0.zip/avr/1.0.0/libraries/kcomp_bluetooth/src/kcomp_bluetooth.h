/*
  kcomp_bluetooth.h - Dummy header file to satisfy Arduino IDE 
  library validation. This library only provides examples.
*/

#ifndef KCOMP_BLUETOOTH_H
#define KCOMP_BLUETOOTH_H

// No code needed here

#endif
