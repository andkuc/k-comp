#include "kcomp_MQ135.h"
#include <EEPROM.h>

static uint8_t _pin = A3;
static float   _baseResistance = 76.6; 

// Curve Parameters
// A = 420 ensures that Fresh Air (Ratio 1.0) calculates to 420 PPM.
static const float _paraA = 420.0;
static const float _paraB = -2.862;

// --- Helper ---
static float getResistance() {
    int val = analogRead(_pin);
    if (val == 0) return 999999.0; 
    return ((1023.0 / (float)val) - 1.0) * MQ_RL_VALUE;
}

// --- Public ---
void initMQ135(uint8_t pin) {
    _pin = pin;
    pinMode(_pin, INPUT);
}

void calibrateMQ135() {
    float total = 0.0;
    // Take 50 samples to set baseline
    for (int i = 0; i < 50; i++) {
        total += getResistance();
        delay(10);
    }
    _baseResistance = total / 50.0;
}

void saveCalibration(int address) {
    EEPROM.put(address, _baseResistance);
}

void loadCalibration(int address) {
    float val;
    EEPROM.get(address, val);
    if (!isnan(val) && val > 1.0 && val < 10000.0) {
        _baseResistance = val;
    }
}

int getRawValue() {
    return analogRead(_pin);
}

float getPPM() {
    float totalPPM = 0.0;
    for (int i = 0; i < 5; i++) {
        float rs = getResistance();
        float ratio = rs / _baseResistance;
        
        // Curve: PPM = 420 * (Ratio ^ -2.86)
        totalPPM += (_paraA * pow(ratio, _paraB));
        delay(10);
    }
    return totalPPM / 5.0;
}

float getAirQualityScore() {
    // We derive score from the PPM to keep them consistent
    float currentPPM = getPPM();
    
    // Map PPM to 0-100%
    // 420 PPM = 0%
    // 2500 PPM = 100% (This is a simplified linear mapping for visualization)
    float score = map(currentPPM, 420, 2500, 0, 100);
    
    if (score < 0) score = 0;
    if (score > 100) score = 100;
    
    return score;
}

uint8_t getAirQualityStatus() {
    float ppm = getPPM();
    if (ppm < 800)  return AIR_FRESH;
    if (ppm < 1500) return AIR_MODERATE;
    return AIR_POOR;
}