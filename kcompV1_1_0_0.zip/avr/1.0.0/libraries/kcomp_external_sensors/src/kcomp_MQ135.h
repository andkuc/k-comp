#ifndef _KCOMP_MQ135_H
#define _KCOMP_MQ135_H

#include "Arduino.h"

// --- Constants ---
#define MQ_RL_VALUE     10.0  

// --- Air Quality Status Codes ---
#define AIR_FRESH       0     // < 800 PPM
#define AIR_MODERATE    1     // 800 - 1500 PPM
#define AIR_POOR        2     // > 1500 PPM

// --- Functions ---
void initMQ135(uint8_t pin);

/*
 * Calibrate: Run in CLEAN OUTDOOR AIR.
 * Sets the baseline resistance (R0) so that current air = 420 PPM.
 */
void calibrateMQ135();
void saveCalibration(int address);
void loadCalibration(int address);

/*
 * Get Raw Analog Value (0-1023).
 * Debugging: See if sensor reacts to lighter/breath.
 */
int getRawValue();

/*
 * Get CO2 Equivalent (PPM).
 * Baseline = 420 PPM (Fresh Air).
 * Note: This is an estimate based on VOCs.
 */
float getPPM();

/*
 * Get Pollution Score (0 - 100%).
 * 0% = Fresh Air (420 PPM)
 * 100% = Heavy Pollution (~2500 PPM)
 */
float getAirQualityScore();

uint8_t getAirQualityStatus();

#endif