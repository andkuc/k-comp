/*
  kcomp_games.h - Dummy header file to satisfy Arduino IDE 
  library validation. This library only provides examples.
*/

#ifndef KCOMP_GAMES_H
#define KCOMP_GAMES_H

// No code needed here

#endif
