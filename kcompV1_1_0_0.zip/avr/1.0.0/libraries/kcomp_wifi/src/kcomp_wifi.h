/*
  kcomp_wifi.h - Dummy header file to satisfy Arduino IDE 
  library validation. This library only provides examples.
*/

#ifndef KCOMP_WIFI_H
#define KCOMP_WIFI_H

// No code needed here

#endif
