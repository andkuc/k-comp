import sys
import time
import subprocess

# --- Constants for MCP2221a ---
VVID = 0x04D8
PPID = 0x00DD

def install_package(package):
    """Installs required Python packages using pip."""
    print(f"Installing dependency: {package}...")
    try:
        # Use --break-system-packages if needed, though generally not recommended
        # Use -q (quiet) to suppress excessive pip output
        subprocess.check_call([sys.executable, "-m", "pip", "install", package, "--break-system-packages", "--user", "-q"])
        print(f"Successfully installed {package}.")
        return True
    except subprocess.CalledProcessError:
        sys.stderr.write(f"Error: Failed to install {package}.\n")
        return False
    except FileNotFoundError:
        # This occurs if 'pip' is not found (i.e., Python not installed or not in PATH)
        sys.stderr.write("Error: Python 'pip' command not found. Ensure Python is installed and in PATH.\n")
        return False


def ensure_package(import_name, install_name):
    """
    Checks if a library is already installed by attempting to import it.
    Only attempts installation if the import fails.
    """
    try:
        __import__(import_name)
        return True
    except ImportError:
        # Import failed, so the package is missing. Install it now.
        return install_package(install_name)


def reset_mcp2221_pulse():
    """Performs the reset pulse (GP3 Low, then High) using EasyMCP2221."""
    
    # 1. Check for 'hidapi' (Import name: 'hid') and install dependency
    if not ensure_package("hid", "hidapi"):
        sys.stderr.write("Error: Could not ensure 'hidapi' dependency. Reset failed.\n")
        return False

    # 2. Check for 'EasyMCP2221' (Import name: 'EasyMCP2221')
    if not ensure_package("EasyMCP2221", "EasyMCP2221"):
        sys.stderr.write("Error: Could not ensure 'EasyMCP2221' library. Reset failed.\n")
        return False

    # Now we can safely import the Device class
    try:
        from EasyMCP2221 import Device
    except ImportError:
        sys.stderr.write("Error: Libraries installed but import failed. Reset failed.\n")
        return False

    print("Looking for MCP2221a to trigger reset...")
    
    try:
        # Connect to device (Defaults to VID 0x04D8, PID 0x00DD)
        mcp = Device(VID=VVID, PID=PPID)
        #print(mcp)
        print("MCP2221a found. Triggering reset pulse...")

        # --- STEP 1: Assert Reset (Drive Low) ---
        # Configure GP3 as Output (if not already set)
        mcp.set_pin_function(gp3="GPIO_OUT")
        # Drive GP3 Low (0)
        mcp.GPIO_write(gp3 = False)

        # Hold reset
        time.sleep(0.1) 

        # --- STEP 2: Release Reset (Drive High) ---
        # Drive GP3 High (1) - Note: Driving High maintains control until avrdude takes over
        mcp.GPIO_write(gp3 = True)
        
        # Optional: Set pin back to High-Z (input) if needed for bootloader sequence
        mcp.set_pin_function(gp3="GPIO_IN") 

        #mcp.close() # does not exist
        
        print("Reset pulse complete.")
        return True

    except Exception as e:
        sys.stderr.write(f"ERROR: Failed to communicate with MCP2221a: {e}\n")
        sys.stderr.write("Reset failed.\n")
        return False

# Main entry point for the script when executed from the shell
if __name__ == "__main__":
    if not reset_mcp2221_pulse():
        # Exit with a non-zero code if reset failed
        sys.exit(1)
    else:
        # Exit with 0 code if successful, allowing AVRDUDE to run
        sys.exit(0)
