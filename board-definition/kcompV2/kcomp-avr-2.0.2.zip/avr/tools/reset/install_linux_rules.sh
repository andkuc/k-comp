#!/usr/bin/env bash
set -euo pipefail

# K-Comp V2 udev Rule Installer (MCP2221A USB + HIDRAW)
# Run once: ./install_linux_rules.sh

RULE_FILE="/etc/udev/rules.d/99-kcomp.rules"

echo "Installing udev rules for K-Comp V2 (MCP2221A 04d8:00dd)..."

cat <<'EOF' | sudo tee "$RULE_FILE" > /dev/null
# K-Comp V2 — Microchip MCP2221A USB-to-UART/HID bridge
SUBSYSTEM=="usb", ATTRS{idVendor}=="04d8", ATTRS{idProduct}=="00dd", MODE="0666", TAG+="uaccess"
KERNEL=="hidraw*", SUBSYSTEM=="hidraw", ATTRS{idVendor}=="04d8", ATTRS{idProduct}=="00dd", MODE="0666", TAG+="uaccess"
EOF

sudo udevadm control --reload-rules
sudo udevadm trigger

echo "Success! Please unplug and replug your K-Comp board."
