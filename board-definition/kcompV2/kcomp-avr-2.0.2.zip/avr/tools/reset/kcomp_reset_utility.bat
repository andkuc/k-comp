@echo off
setlocal
echo Initializing K-Comp V2 reset sequence...
"%~dp0MCP2221CLI.exe" -gpioW=-,-,-,low > nul
if errorlevel 1 (
    echo Warning: MCP2221 auto-reset failed. Check DIP S1-1 or press the RESET button manually.
    exit /b 0
)
ping 127.0.0.1 -n 2 > nul
"%~dp0MCP2221CLI.exe" -gpioW=-,-,-,high > nul
echo Reset sequence complete.
exit /b 0
