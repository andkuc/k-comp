#!/usr/bin/env python3
"""Triggers a GP3 hardware reset pulse on the K-Comp V2 MCP2221A bridge."""

import subprocess
import sys
import time

MCP2221_VID = 0x04D8
MCP2221_PID = 0x00DD


def install_package(package: str) -> bool:
    """Installs a missing Python dependency with PEP-668 fallback."""
    print(f"Installing dependency: {package}...")
    base_cmd = [sys.executable, "-m", "pip", "install", "--user", "-q", package]
    for extra in ([], ["--break-system-packages"]):
        try:
            result = subprocess.run(
                base_cmd + extra,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                text=True,
                check=False,
            )
            if result.returncode == 0:
                print(f"Successfully installed {package}.")
                return True
        except FileNotFoundError:
            sys.stderr.write("Error: Python 'pip' not found. Ensure Python 3 + pip are installed.\n")
            return False

    sys.stderr.write(f"Error: Failed to install {package}.\n")
    return False


def ensure_package(import_name: str, install_name: str) -> bool:
    try:
        __import__(import_name)
        return True
    except ImportError:
        return install_package(install_name)


def reset_mcp2221_pulse() -> bool:
    if not ensure_package("hid", "hidapi"):
        return False
    if not ensure_package("EasyMCP2221", "EasyMCP2221"):
        return False

    try:
        from EasyMCP2221 import Device
    except ImportError:
        sys.stderr.write("Error: EasyMCP2221 installed but import failed.\n")
        return False

    print("Looking for K-Comp V2 (MCP2221A) to trigger reset...")
    try:
        mcp = Device(VID=MCP2221_VID, PID=MCP2221_PID)
        mcp.set_pin_function(gp3="GPIO_OUT")
        mcp.GPIO_write(gp3=False)
        time.sleep(0.1)
        mcp.GPIO_write(gp3=True)
        mcp.set_pin_function(gp3="GPIO_IN")
        print("Reset pulse complete.")
        return True
    except Exception as exc:
        sys.stderr.write(f"ERROR: MCP2221A reset failed: {exc}\n")
        if sys.platform.startswith("linux"):
            sys.stderr.write("Hint: On Linux, run tools/reset/install_linux_rules.sh once and replug the board.\n")
        sys.stderr.write("Hint: Ensure DIP S1-1 is ON, or press the board RESET button manually.\n")
        return False


if __name__ == "__main__":
    sys.exit(0 if reset_mcp2221_pulse() else 1)
