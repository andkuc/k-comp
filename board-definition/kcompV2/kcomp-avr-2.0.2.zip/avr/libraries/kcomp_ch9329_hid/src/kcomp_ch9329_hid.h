// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      ch9329_hid
// @title       CH9329 USB HID Mouse & Keyboard Emulator
// @targets     avr, esp32s3
// @bus         uart (SoftwareSerial on AVR, Serial1 on ESP32-S3; default 9600 baud)
// @timers      none (PCINT on AVR SoftwareSerial)
// @sram_bytes  ~12

#ifndef KCOMP_CH9329_HID_H
#define KCOMP_CH9329_HID_H

#include <Arduino.h>
#include <stddef.h>
#include <stdint.h>

#define CH9329_BAUD_DEFAULT 9600UL

// Modifier key codes
#define KEY_LEFT_CTRL   0x80U
#define KEY_LEFT_SHIFT  0x81U
#define KEY_LEFT_ALT    0x82U
#define KEY_LEFT_GUI    0x83U
#define KEY_RIGHT_CTRL  0x84U
#define KEY_RIGHT_SHIFT 0x85U
#define KEY_RIGHT_ALT   0x86U
#define KEY_RIGHT_GUI   0x87U

// Navigation & editing keys
#define KEY_UP_ARROW     0xDAU
#define KEY_DOWN_ARROW   0xD9U
#define KEY_LEFT_ARROW   0xD8U
#define KEY_RIGHT_ARROW  0xD7U
#define KEY_BACKSPACE    0xB2U
#define KEY_TAB          0xB3U
#define KEY_RETURN       0xB0U
#define KEY_MENU         0xEDU
#define KEY_ESC          0xB1U
#define KEY_INSERT       0xD1U
#define KEY_DELETE       0xD4U
#define KEY_PAGE_UP      0xD3U
#define KEY_PAGE_DOWN    0xD6U
#define KEY_HOME         0xD2U
#define KEY_END          0xD5U
#define KEY_CAPS_LOCK    0xC1U
#define KEY_PRINT_SCREEN 0xCEU
#define KEY_SCROLL_LOCK  0xCFU
#define KEY_PAUSE        0xD0U

// Function keys
#define KEY_F1  0xC2U
#define KEY_F2  0xC3U
#define KEY_F3  0xC4U
#define KEY_F4  0xC5U
#define KEY_F5  0xC6U
#define KEY_F6  0xC7U
#define KEY_F7  0xC8U
#define KEY_F8  0xC9U
#define KEY_F9  0xCAU
#define KEY_F10 0xCBU
#define KEY_F11 0xCCU
#define KEY_F12 0xCDU

// Mouse button bitmasks
#define CH9329_MOUSE_LEFT   0x01U
#define CH9329_MOUSE_RIGHT  0x02U
#define CH9329_MOUSE_MIDDLE 0x04U

// Initialize UART communication with the CH9329 HID bridge.
void initCH9329(uint8_t rxPin, uint8_t txPin, uint32_t baudRate = CH9329_BAUD_DEFAULT);

// Restore CH9329 Mode 0 (combined USB keyboard + mouse at 9600 baud).
void resetCH9329Mode();

// Relative and absolute mouse controls
void moveCH9329Mouse(int8_t dx, int8_t dy);
void clickCH9329Mouse(uint8_t buttons);
void scrollCH9329Mouse(int8_t wheel);
void moveCH9329MouseAbsolute(uint16_t x, uint16_t y);

// Keyboard report controls
size_t pressCH9329Key(uint8_t key);
size_t releaseCH9329Key(uint8_t key);
void   releaseCH9329AllKeys();
size_t writeCH9329Key(uint8_t key);
void   typeCH9329Text(const char* text);

#endif
