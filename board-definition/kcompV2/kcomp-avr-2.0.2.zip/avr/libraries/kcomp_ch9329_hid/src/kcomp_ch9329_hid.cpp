// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_ch9329_hid.h"
#include <string.h>

#if defined(__AVR__)
  #include <SoftwareSerial.h>
  #include <new>
  alignas(SoftwareSerial) static uint8_t ch9329SwSerialStorage[sizeof(SoftwareSerial)];
  static SoftwareSerial* ch9329SwSerial = NULL;
#endif

static Stream* ch9329Port = NULL;
static uint8_t keyReport[8] = {0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U};

// CH9329 frame header and command constants
static constexpr uint8_t FRAME_HEAD_1  = 0x57U;
static constexpr uint8_t FRAME_HEAD_2  = 0xABU;
static constexpr uint8_t FRAME_ADDR    = 0x00U;
static constexpr uint8_t CMD_KB        = 0x02U;
static constexpr uint8_t CMD_MOUSE_ABS = 0x04U;
static constexpr uint8_t CMD_MOUSE_REL = 0x05U;
static constexpr uint8_t CMD_CONFIG    = 0x09U;

static void sendPacket(uint8_t cmd, const uint8_t* data, uint8_t len) {
    if (ch9329Port == NULL) {
        return;
    }

    uint16_t sum = (uint16_t)FRAME_HEAD_1 + FRAME_HEAD_2 + FRAME_ADDR + cmd + len;
    ch9329Port->write(FRAME_HEAD_1);
    ch9329Port->write(FRAME_HEAD_2);
    ch9329Port->write(FRAME_ADDR);
    ch9329Port->write(cmd);
    ch9329Port->write(len);

    for (uint8_t i = 0U; i < len; i++) {
        ch9329Port->write(data[i]);
        sum = (uint16_t)(sum + data[i]);
    }
    ch9329Port->write((uint8_t)(sum & 0xFFU));
    delay(10);
}

static uint8_t mapToHidUsage(uint8_t key) {
    if (key >= 'a' && key <= 'z') return (uint8_t)(0x04U + (key - 'a'));
    if (key >= 'A' && key <= 'Z') return (uint8_t)(0x04U + (key - 'A'));
    if (key >= '1' && key <= '9') return (uint8_t)(0x1EU + (key - '1'));
    if (key == '0')  return 0x27U;
    if (key == ' ')  return 0x2CU;
    if (key == '\n') return 0x28U;
    if (key == '\t') return 0x2BU;

    switch (key) {
        case KEY_RETURN:      return 0x28U;
        case KEY_ESC:         return 0x29U;
        case KEY_BACKSPACE:   return 0x2AU;
        case KEY_TAB:         return 0x2BU;
        case KEY_HOME:        return 0x4AU;
        case KEY_PAGE_UP:     return 0x4BU;
        case KEY_DELETE:      return 0x4CU;
        case KEY_END:         return 0x4DU;
        case KEY_PAGE_DOWN:   return 0x4EU;
        case KEY_RIGHT_ARROW: return 0x4FU;
        case KEY_LEFT_ARROW:  return 0x50U;
        case KEY_DOWN_ARROW:  return 0x51U;
        case KEY_UP_ARROW:    return 0x52U;
        case KEY_F1:  return 0x3AU; case KEY_F2:  return 0x3BU; case KEY_F3:  return 0x3CU;
        case KEY_F4:  return 0x3DU; case KEY_F5:  return 0x3EU; case KEY_F6:  return 0x3FU;
        case KEY_F7:  return 0x40U; case KEY_F8:  return 0x41U; case KEY_F9:  return 0x42U;
        case KEY_F10: return 0x43U; case KEY_F11: return 0x44U; case KEY_F12: return 0x45U;
        default: return 0x00U;
    }
}

static void sendKeyReport() {
    sendPacket(CMD_KB, keyReport, 8U);
}

void initCH9329(uint8_t rxPin, uint8_t txPin, uint32_t baudRate) {
    memset(keyReport, 0, sizeof(keyReport));

#if defined(__AVR__)
    if (ch9329SwSerial != NULL) {
        ch9329SwSerial->~SoftwareSerial();
        ch9329SwSerial = NULL;
    }
    ch9329SwSerial = new (ch9329SwSerialStorage) SoftwareSerial(rxPin, txPin);
    if (ch9329SwSerial != NULL) {
        ch9329SwSerial->begin((long)baudRate);
        ch9329Port = ch9329SwSerial;
    }
#elif defined(ESP32)
    Serial1.begin(baudRate, SERIAL_8N1, rxPin, txPin);
    ch9329Port = &Serial1;
#else
    (void)rxPin;
    (void)txPin;
    (void)baudRate;
    ch9329Port = NULL;
#endif
    delay(500);
}

void resetCH9329Mode() {
    uint8_t cfg[50];
    memset(cfg, 0, sizeof(cfg));
    cfg[0] = 0x00U;
    cfg[5] = 0x25U; cfg[6] = 0x80U;   // 9600 baud
    cfg[11] = 0x1AU; cfg[12] = 0x86U; // VID
    cfg[13] = 0xE0U; cfg[14] = 0x10U; // PID
    cfg[16] = 0x0AU; cfg[18] = 0x64U;
    sendPacket(CMD_CONFIG, cfg, 50U);
    delay(100);
}

void moveCH9329MouseAbsolute(uint16_t x, uint16_t y) {
    if (x == 0U && y == 0U) {
        x = 1U;
        y = 1U;
    }
    if (x > 4096U) x = 4096U;
    if (y > 4096U) y = 4096U;

    const uint8_t data[7] = {
        0x02U, 0x00U,
        (uint8_t)(x & 0xFFU), (uint8_t)((x >> 8) & 0xFFU),
        (uint8_t)(y & 0xFFU), (uint8_t)((y >> 8) & 0xFFU),
        0x00U
    };
    sendPacket(CMD_MOUSE_ABS, data, 7U);
}

void moveCH9329Mouse(int8_t dx, int8_t dy) {
    const uint8_t data[5] = {0x01U, 0x00U, (uint8_t)dx, (uint8_t)dy, 0x00U};
    sendPacket(CMD_MOUSE_REL, data, 5U);
}

void clickCH9329Mouse(uint8_t buttons) {
    const uint8_t data[5] = {0x01U, buttons, 0x00U, 0x00U, 0x00U};
    sendPacket(CMD_MOUSE_REL, data, 5U);
}

void scrollCH9329Mouse(int8_t wheel) {
    const uint8_t data[5] = {0x01U, 0x00U, 0x00U, 0x00U, (uint8_t)wheel};
    sendPacket(CMD_MOUSE_REL, data, 5U);
}

size_t pressCH9329Key(uint8_t key) {
    if (key >= 0x80U && key <= 0x87U) {
        keyReport[0] = (uint8_t)(keyReport[0] | (uint8_t)(1U << (key - 0x80U)));
    } else {
        const uint8_t hidCode = mapToHidUsage(key);
        if (hidCode == 0U) {
            return 0U;
        }
        for (uint8_t i = 2U; i < 8U; i++) {
            if (keyReport[i] == hidCode) {
                return 1U;
            }
        }
        for (uint8_t i = 2U; i < 8U; i++) {
            if (keyReport[i] == 0U) {
                keyReport[i] = hidCode;
                break;
            }
        }
    }
    sendKeyReport();
    return 1U;
}

size_t releaseCH9329Key(uint8_t key) {
    if (key >= 0x80U && key <= 0x87U) {
        keyReport[0] = (uint8_t)(keyReport[0] & (uint8_t)(~(1U << (key - 0x80U))));
    } else {
        const uint8_t hidCode = mapToHidUsage(key);
        for (uint8_t i = 2U; i < 8U; i++) {
            if (keyReport[i] == hidCode) {
                keyReport[i] = 0U;
            }
        }
    }
    sendKeyReport();
    return 1U;
}

void releaseCH9329AllKeys() {
    memset(keyReport, 0, sizeof(keyReport));
    sendKeyReport();
    static const uint8_t mData[5] = {0x01U, 0x00U, 0x00U, 0x00U, 0x00U};
    sendPacket(CMD_MOUSE_REL, mData, 5U);
}

size_t writeCH9329Key(uint8_t key) {
    const bool upper = (key >= 'A' && key <= 'Z');
    if (upper) pressCH9329Key(KEY_LEFT_SHIFT);
    pressCH9329Key(key);
    delay(10);
    releaseCH9329Key(key);
    if (upper) releaseCH9329Key(KEY_LEFT_SHIFT);
    return 1U;
}

void typeCH9329Text(const char* text) {
    if (text == NULL) {
        return;
    }
    while (*text != '\0') {
        writeCH9329Key((uint8_t)*text);
        text++;
        delay(20);
    }
}
