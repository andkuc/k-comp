// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_as608.h"

#if defined(__AVR__)
  #include <SoftwareSerial.h>
  #include <new>
  alignas(SoftwareSerial) static uint8_t as608SwSerialStorage[sizeof(SoftwareSerial)];
  static SoftwareSerial* as608SwSerial = NULL;
#endif

static Stream* as608Port = NULL;

// AS608 protocol instruction codes
static constexpr uint8_t CMD_GEN_IMG   = 0x01U;
static constexpr uint8_t CMD_IMG_2_TZ  = 0x02U;
static constexpr uint8_t CMD_SEARCH    = 0x04U;
static constexpr uint8_t CMD_REG_MODEL = 0x05U;
static constexpr uint8_t CMD_STORE     = 0x06U;
static constexpr uint8_t CMD_LOAD_CHAR = 0x07U;
static constexpr uint8_t CMD_UP_CHAR   = 0x08U;
static constexpr uint8_t CMD_DELETE    = 0x0CU;
static constexpr uint8_t CMD_EMPTY     = 0x0DU;
static constexpr uint8_t CMD_VFY_PWD   = 0x13U;
static constexpr uint8_t CMD_TEMPLATE  = 0x1DU;
static constexpr uint8_t CMD_LED       = 0x35U;

static constexpr uint32_t AS608_TIMEOUT_MS = 1000UL;
static constexpr uint32_t AS608_ENROLL_STEP_TIMEOUT_MS = 15000UL;

static void writePacket(uint8_t instruction, const uint8_t* args, uint8_t argLen) {
    if (as608Port == NULL) {
        return;
    }

    const uint16_t wireLen = (uint16_t)argLen + 3U;
    uint16_t checksum = 0x01U + (uint16_t)(wireLen >> 8) + (uint16_t)(wireLen & 0xFFU) + instruction;

    static const uint8_t header[6] = {0xEFU, 0x01U, 0xFFU, 0xFFU, 0xFFU, 0xFFU};
    as608Port->write(header, 6U);
    as608Port->write((uint8_t)0x01U);
    as608Port->write((uint8_t)(wireLen >> 8));
    as608Port->write((uint8_t)(wireLen & 0xFFU));
    as608Port->write(instruction);

    for (uint8_t i = 0U; i < argLen; i++) {
        as608Port->write(args[i]);
        checksum = (uint16_t)(checksum + args[i]);
    }

    as608Port->write((uint8_t)(checksum >> 8));
    as608Port->write((uint8_t)(checksum & 0xFFU));
}

static int16_t readAck(uint8_t* rxData, uint8_t maxLen) {
    if (as608Port == NULL || rxData == NULL || maxLen == 0U) {
        return AS608_COMM_ERROR;
    }

    const uint32_t startMs = millis();
    uint8_t state = 0U;
    uint16_t payloadLen = 0U;
    uint16_t checksum = 0U;
    uint16_t calcChecksum = 0U;
    uint8_t dataIdx = 0U;

    while ((millis() - startMs) < AS608_TIMEOUT_MS) {
        if (as608Port->available() > 0) {
            const uint8_t b = (uint8_t)as608Port->read();
            switch (state) {
                case 0: state = (b == 0xEFU) ? 1U : 0U; break;
                case 1: state = (b == 0x01U) ? 2U : 0U; break;
                case 2:
                case 3:
                case 4:
                case 5: state = (b == 0xFFU) ? (uint8_t)(state + 1U) : 0U; break;
                case 6:
                    if (b == 0x07U) {
                        calcChecksum = b;
                        state = 7U;
                    } else {
                        state = 0U;
                    }
                    break;
                case 7:
                    payloadLen = (uint16_t)b << 8;
                    calcChecksum = (uint16_t)(calcChecksum + b);
                    state = 8U;
                    break;
                case 8:
                    payloadLen = (uint16_t)(payloadLen | b);
                    calcChecksum = (uint16_t)(calcChecksum + b);
                    if (payloadLen < 2U) {
                        return AS608_COMM_ERROR;
                    }
                    payloadLen = (uint16_t)(payloadLen - 2U);
                    dataIdx = 0U;
                    state = (payloadLen > 0U) ? 9U : 10U;
                    break;
                case 9:
                    if (dataIdx < maxLen) {
                        rxData[dataIdx] = b;
                    }
                    dataIdx++;
                    calcChecksum = (uint16_t)(calcChecksum + b);
                    if (dataIdx >= payloadLen) {
                        state = 10U;
                    }
                    break;
                case 10:
                    checksum = (uint16_t)b << 8;
                    state = 11U;
                    break;
                case 11:
                    checksum = (uint16_t)(checksum | b);
                    if (checksum == calcChecksum) {
                        return (int16_t)rxData[0];
                    }
                    return AS608_COMM_ERROR;
                default:
                    state = 0U;
                    break;
            }
        }
    }
    return AS608_COMM_ERROR;
}

bool initAS608(uint8_t rxPin, uint8_t txPin, uint32_t baudRate) {
#if defined(__AVR__)
    if (as608SwSerial != NULL) {
        as608SwSerial->~SoftwareSerial();
        as608SwSerial = NULL;
    }
    as608SwSerial = new (as608SwSerialStorage) SoftwareSerial(rxPin, txPin);
    if (as608SwSerial == NULL) {
        as608Port = NULL;
        return false;
    }
    as608SwSerial->begin((long)baudRate);
    as608Port = as608SwSerial;
#elif defined(ESP32)
    Serial1.begin(baudRate, SERIAL_8N1, rxPin, txPin);
    as608Port = &Serial1;
#else
    (void)rxPin;
    (void)txPin;
    (void)baudRate;
    as608Port = NULL;
    return false;
#endif

    // Allow AS608 module time to boot and stabilize its UART
    delay(250);
    return isAS608Connected();
}

bool isAS608Connected() {
    if (as608Port == NULL) {
        return false;
    }
    while (as608Port->available() > 0) {
        as608Port->read();
    }

    static const uint8_t defaultPwd[4] = {0x00U, 0x00U, 0x00U, 0x00U};
    writePacket(CMD_VFY_PWD, defaultPwd, 4U);
    uint8_t response[4] = {0U};
    return readAck(response, 4U) == 0x00;
}

int16_t scanAS608Fingerprint() {
    if (as608Port == NULL) {
        return AS608_COMM_ERROR;
    }

    uint8_t response[8] = {0U};
    writePacket(CMD_GEN_IMG, NULL, 0U);
    int16_t status = readAck(response, 4U);
    if (status == 0x02) return AS608_NO_FINGER;
    if (status != 0x00) return AS608_IMAGE_FAIL;

    static const uint8_t buf1[1] = {0x01U};
    writePacket(CMD_IMG_2_TZ, buf1, 1U);
    if (readAck(response, 4U) != 0x00) {
        return AS608_IMAGE_FAIL;
    }

    static const uint8_t searchArgs[5] = {0x01U, 0x00U, 0x00U, 0x00U, 0xC8U};
    writePacket(CMD_SEARCH, searchArgs, 5U);
    status = readAck(response, 8U);
    if (status == 0x00) {
        return (int16_t)(((uint16_t)response[1] << 8) | response[2]);
    }
    return AS608_MATCH_FAIL;
}

int8_t enrollAS608Fingerprint(uint8_t targetId) {
    if (as608Port == NULL) {
        return AS608_COMM_ERROR;
    }

    uint8_t response[4] = {0U};
    int16_t status = -1;

    // Step 1: Wait for first finger placement (bounded by timeout)
    uint32_t startMs = millis();
    while (status != 0x00) {
        if ((millis() - startMs) >= AS608_ENROLL_STEP_TIMEOUT_MS) {
            return AS608_COMM_ERROR;
        }
        writePacket(CMD_GEN_IMG, NULL, 0U);
        status = readAck(response, 4U);
    }

    static const uint8_t buf1[1] = {0x01U};
    writePacket(CMD_IMG_2_TZ, buf1, 1U);
    if (readAck(response, 4U) != 0x00) {
        return AS608_IMAGE_FAIL;
    }

    // Step 2: Wait for finger removal
    startMs = millis();
    status = 0x00;
    while (status != 0x02) {
        if ((millis() - startMs) >= AS608_ENROLL_STEP_TIMEOUT_MS) {
            return AS608_COMM_ERROR;
        }
        writePacket(CMD_GEN_IMG, NULL, 0U);
        status = readAck(response, 4U);
    }
    delay(500);

    // Step 3: Wait for second placement of the same finger
    startMs = millis();
    status = -1;
    while (status != 0x00) {
        if ((millis() - startMs) >= AS608_ENROLL_STEP_TIMEOUT_MS) {
            return AS608_COMM_ERROR;
        }
        writePacket(CMD_GEN_IMG, NULL, 0U);
        status = readAck(response, 4U);
    }

    static const uint8_t buf2[1] = {0x02U};
    writePacket(CMD_IMG_2_TZ, buf2, 1U);
    if (readAck(response, 4U) != 0x00) {
        return AS608_IMAGE_FAIL;
    }

    // Step 4: Combine both feature buffers into a template and store to Flash
    writePacket(CMD_REG_MODEL, NULL, 0U);
    if (readAck(response, 4U) != 0x00) {
        return AS608_MATCH_FAIL;
    }

    const uint8_t storeArgs[3] = {0x01U, 0x00U, targetId};
    writePacket(CMD_STORE, storeArgs, 3U);
    if (readAck(response, 4U) == 0x00) {
        return AS608_OK;
    }
    return AS608_ENROLL_FAIL;
}

int8_t deleteAS608Fingerprint(uint16_t id) {
    if (as608Port == NULL) {
        return AS608_COMM_ERROR;
    }
    uint8_t response[4] = {0U};
    const uint8_t args[4] = {(uint8_t)(id >> 8), (uint8_t)(id & 0xFFU), 0x00U, 0x01U};
    writePacket(CMD_DELETE, args, 4U);
    return (readAck(response, 4U) == 0x00) ? AS608_OK : AS608_COMM_ERROR;
}

bool clearAS608Fingerprints() {
    if (as608Port == NULL) {
        return false;
    }
    uint8_t response[4] = {0U};
    writePacket(CMD_EMPTY, NULL, 0U);
    return readAck(response, 4U) == 0x00;
}

int16_t getAS608FingerprintCount() {
    if (as608Port == NULL) {
        return -1;
    }
    uint8_t response[4] = {0U};
    writePacket(CMD_TEMPLATE, NULL, 0U);
    if (readAck(response, 4U) == 0x00) {
        return (int16_t)(((uint16_t)response[1] << 8) | response[2]);
    }
    return -1;
}

bool isAS608SlotOccupied(uint16_t id) {
    if (as608Port == NULL) {
        return false;
    }
    uint8_t response[4] = {0U};
    const uint8_t args[3] = {0x01U, (uint8_t)(id >> 8), (uint8_t)(id & 0xFFU)};
    writePacket(CMD_LOAD_CHAR, args, 3U);
    return readAck(response, 4U) == 0x00;
}

void setAS608Led(uint8_t mode, uint8_t color, uint8_t speed, uint8_t cycles) {
    if (as608Port == NULL) {
        return;
    }
    uint8_t response[4] = {0U};
    const uint8_t args[4] = {mode, speed, color, cycles};
    writePacket(CMD_LED, args, 4U);
    (void)readAck(response, 4U);
}

bool getAS608Template(uint16_t id, uint8_t* buffer) {
    if (as608Port == NULL || buffer == NULL) {
        return false;
    }

    uint8_t response[4] = {0U};
    const uint8_t loadArgs[3] = {0x01U, (uint8_t)(id >> 8), (uint8_t)(id & 0xFFU)};
    writePacket(CMD_LOAD_CHAR, loadArgs, 3U);
    if (readAck(response, 4U) != 0x00) {
        return false;
    }

    static const uint8_t upArgs[1] = {0x01U};
    writePacket(CMD_UP_CHAR, upArgs, 1U);
    if (readAck(response, 4U) != 0x00) {
        return false;
    }

    uint16_t bytesRead = 0U;
    const uint32_t startMs = millis();

    while (bytesRead < 512U && (millis() - startMs) < 3000UL) {
        if (as608Port->available() >= 9) {
            if ((uint8_t)as608Port->read() == 0xEFU && (uint8_t)as608Port->read() == 0x01U) {
                for (uint8_t i = 0U; i < 4U; i++) {
                    (void)as608Port->read();
                }
                const uint8_t packetType = (uint8_t)as608Port->read();
                const uint8_t lenHi = (uint8_t)as608Port->read();
                const uint8_t lenLo = (uint8_t)as608Port->read();
                uint16_t len = (uint16_t)(((uint16_t)lenHi << 8) | lenLo);
                if (len < 2U) {
                    return false;
                }
                len = (uint16_t)(len - 2U);

                for (uint16_t i = 0U; i < len; i++) {
                    while (as608Port->available() == 0) {
                        if ((millis() - startMs) >= 3000UL) {
                            return false;
                        }
                    }
                    const uint8_t b = (uint8_t)as608Port->read();
                    if (bytesRead < 512U) {
                        buffer[bytesRead++] = b;
                    }
                }

                // Discard 2 checksum bytes
                for (uint8_t i = 0U; i < 2U; i++) {
                    while (as608Port->available() == 0) {
                        if ((millis() - startMs) >= 3000UL) {
                            return false;
                        }
                    }
                    (void)as608Port->read();
                }

                if (packetType == 0x08U) {
                    break;
                }
            }
        }
    }

    return bytesRead == 512U;
}
