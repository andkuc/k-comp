// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      as608
// @title       AS608 Optical Fingerprint Sensor
// @targets     avr, esp32s3
// @bus         uart (SoftwareSerial on AVR, Serial1 on ESP32-S3; default 57600 baud)
// @timers      none (PCINT on AVR SoftwareSerial)
// @sram_bytes  ~72

#ifndef KCOMP_AS608_H
#define KCOMP_AS608_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Standardized status codes
#define AS608_OK          0
#define AS608_NO_FINGER   (-1)
#define AS608_IMAGE_FAIL  (-2)
#define AS608_MATCH_FAIL  (-3)
#define AS608_ENROLL_FAIL (-4)
#define AS608_COMM_ERROR  (-5)

// LED ring animation modes
#define AS608_LED_BREATHING   1U
#define AS608_LED_FLASHING    2U
#define AS608_LED_ALWAYS_ON   3U
#define AS608_LED_ALWAYS_OFF  4U
#define AS608_LED_GRADUAL_ON  5U
#define AS608_LED_GRADUAL_OFF 6U

// LED ring colors
#define AS608_LED_RED    1U
#define AS608_LED_BLUE   2U
#define AS608_LED_PURPLE 3U

// Initialize UART communication and verify the AS608 default password.
// Returns true if the sensor responds properly.
bool initAS608(uint8_t rxPin, uint8_t txPin, uint32_t baudRate = 57600UL);

// Verify that the AS608 responds to a password handshake.
bool isAS608Connected();

// Capture a finger image and search the internal database.
// Returns matched ID (>= 0) or a negative AS608_* error code.
int16_t scanAS608Fingerprint();

// Enroll a new fingerprint into targetId (blocking two-scan sequence).
// Returns AS608_OK on success or a negative AS608_* error code.
int8_t enrollAS608Fingerprint(uint8_t targetId);

// Delete a single stored template by ID. Returns AS608_OK or AS608_COMM_ERROR.
int8_t deleteAS608Fingerprint(uint16_t id);

// Erase all stored fingerprint templates. Returns true on success.
bool clearAS608Fingerprints();

// Return the number of stored templates, or -1 on communication error.
int16_t getAS608FingerprintCount();

// Check whether a specific template slot is occupied.
bool isAS608SlotOccupied(uint16_t id);

// Control the sensor's integrated ring LED.
void setAS608Led(uint8_t mode, uint8_t color, uint8_t speed, uint8_t cycles);

// Download a 512-byte raw fingerprint template into buffer (must be >= 512 bytes).
bool getAS608Template(uint16_t id, uint8_t* buffer);

#endif
