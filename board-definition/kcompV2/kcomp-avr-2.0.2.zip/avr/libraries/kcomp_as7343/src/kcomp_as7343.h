// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      as7343
// @title       AS7343 14-Channel Spectral Sensor
// @targets     avr, esp32s3
// @bus         i2c (0x39)
// @timers      none (uses millis() timeout)
// @sram_bytes  ~34

#ifndef KCOMP_AS7343_H
#define KCOMP_AS7343_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Default I2C address of the AS7343
#define AS7343_I2C_ADDR 0x39U

// Spectral and clear/NIR channel snapshot
struct AS7343Data {
    uint16_t f1_405nm;   // Violet
    uint16_t f2_425nm;   // Violet / Blue
    uint16_t fz_450nm;   // Deep Blue
    uint16_t f3_475nm;   // Blue / Cyan
    uint16_t f4_515nm;   // Cyan / Green
    uint16_t f5_550nm;   // Green
    uint16_t fy_555nm;   // Yellow / Green
    uint16_t fxl_600nm;  // Orange
    uint16_t f6_640nm;   // Red / Orange
    uint16_t f7_690nm;   // Red
    uint16_t f8_745nm;   // Deep Red
    uint16_t clear;      // Broadband unfiltered light
    uint16_t nir;        // Near infrared (855 nm)
    bool valid;
    bool updated;
};

// Initialize I2C and configure the 18-channel Auto-SMUX sequencer.
// Returns true if the sensor responds at the specified address.
bool initAS7343(uint8_t address = AS7343_I2C_ADDR);

// Poll until new spectral data is ready and read all channels into internal state.
// Returns true on success, false if uninitialized or timed out.
bool updateAS7343();

// Return the latest captured spectral snapshot.
AS7343Data getAS7343Data();

// Enable or disable the onboard illumination LED (current clamped to 4..255 mA).
void setAS7343LED(bool enable, uint8_t current_mA = 10U);

// Set analog sensor gain register level (0..12).
void setAS7343Gain(uint8_t gain_level);

#endif
