// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_as7343.h"
#include <Wire.h>
#include <string.h>

// Internal AS7343 register map
static constexpr uint8_t REG_ENABLE     = 0x80U;
static constexpr uint8_t REG_ATIME      = 0x81U;
static constexpr uint8_t REG_STATUS2    = 0x90U;
static constexpr uint8_t REG_DATA_START = 0x95U;
static constexpr uint8_t REG_CFG0       = 0xBFU;
static constexpr uint8_t REG_CFG1       = 0xC6U;
static constexpr uint8_t REG_LED        = 0xCDU;
static constexpr uint8_t REG_ASTEP_L    = 0xD4U;
static constexpr uint8_t REG_ASTEP_H    = 0xD5U;
static constexpr uint8_t REG_CFG20      = 0xD6U;

static constexpr uint32_t AVALID_TIMEOUT_MS = 800UL;

static uint8_t as7343Addr = AS7343_I2C_ADDR;
static AS7343Data spectralData = {
    0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, false, false
};
static bool sensorReady = false;

static void writeReg(uint8_t reg, uint8_t value) {
    Wire.beginTransmission(as7343Addr);
    Wire.write(reg);
    Wire.write(value);
    Wire.endTransmission();
}

static uint8_t readReg(uint8_t reg) {
    Wire.beginTransmission(as7343Addr);
    Wire.write(reg);
    if (Wire.endTransmission() != 0) {
        return 0U;
    }
    if (Wire.requestFrom(as7343Addr, (uint8_t)1U) != 1U) {
        return 0U;
    }
    return (uint8_t)Wire.read();
}

bool initAS7343(uint8_t address) {
    as7343Addr = address;
    sensorReady = false;
    spectralData.valid = false;
    spectralData.updated = false;
    Wire.begin();

    Wire.beginTransmission(as7343Addr);
    if (Wire.endTransmission() != 0) {
        return false;
    }

    // Select register bank 0 and power on (PON)
    writeReg(REG_CFG0, 0x00U);
    writeReg(REG_ENABLE, 0x01U);
    delay(10);

    // Configure integration timing (~50 ms cycle) and default gain (AGAIN_32X = 6)
    writeReg(REG_ATIME, 29U);
    writeReg(REG_ASTEP_L, (uint8_t)(599U & 0xFFU));
    writeReg(REG_ASTEP_H, (uint8_t)((599U >> 8) & 0xFFU));
    writeReg(REG_CFG1, 6U);

    // Enable 18-channel Auto-SMUX sequencer and start spectral engine (PON + SPEN)
    writeReg(REG_CFG20, 0x60U);
    writeReg(REG_ENABLE, 0x03U);

    sensorReady = true;
    return true;
}

bool updateAS7343() {
    if (!sensorReady) {
        return false;
    }
    spectralData.updated = false;

    const uint32_t startMs = millis();
    while ((readReg(REG_STATUS2) & 0x40U) == 0U) {
        if ((millis() - startMs) > AVALID_TIMEOUT_MS) {
            return false;
        }
        delay(5);
    }

    uint8_t buffer[36];
    memset(buffer, 0, sizeof(buffer));

    // Read first 18 bytes of spectral channel data
    Wire.beginTransmission(as7343Addr);
    Wire.write(REG_DATA_START);
    Wire.endTransmission();
    if (Wire.requestFrom(as7343Addr, (uint8_t)18U) == 18U) {
        for (uint8_t i = 0U; i < 18U; i++) {
            buffer[i] = (uint8_t)Wire.read();
        }
    }

    // Read remaining 18 bytes of spectral channel data
    Wire.beginTransmission(as7343Addr);
    Wire.write((uint8_t)(REG_DATA_START + 18U));
    Wire.endTransmission();
    if (Wire.requestFrom(as7343Addr, (uint8_t)18U) == 18U) {
        for (uint8_t i = 0U; i < 18U; i++) {
            buffer[18U + i] = (uint8_t)Wire.read();
        }
    }

    uint16_t ch[18];
    for (uint8_t i = 0U; i < 18U; i++) {
        const uint8_t lsb = buffer[i * 2U];
        const uint8_t msb = buffer[i * 2U + 1U];
        ch[i] = (uint16_t)(((uint16_t)msb << 8) | lsb);
    }

    // Map Auto-SMUX channels to wavelength bands
    spectralData.fz_450nm  = ch[0];
    spectralData.fy_555nm  = ch[1];
    spectralData.fxl_600nm = ch[2];
    spectralData.nir       = ch[3];
    spectralData.clear     = (uint16_t)(((uint32_t)ch[4] + (uint32_t)ch[10] + (uint32_t)ch[16]) / 3UL);
    spectralData.f2_425nm  = ch[6];
    spectralData.f3_475nm  = ch[7];
    spectralData.f4_515nm  = ch[8];
    spectralData.f6_640nm  = ch[9];
    spectralData.f1_405nm  = ch[12];
    spectralData.f7_690nm  = ch[13];
    spectralData.f8_745nm  = ch[14];
    spectralData.f5_550nm  = ch[15];

    spectralData.valid = true;
    spectralData.updated = true;
    return true;
}

AS7343Data getAS7343Data() {
    return spectralData;
}

void setAS7343LED(bool enable, uint8_t current_mA) {
    if (!sensorReady) {
        return;
    }
    const uint8_t clampedMa = (current_mA < 4U) ? 4U : current_mA;
    // LED current register encodes (mA - 4) / 2 in bits 6..0 (bit 7 enables LED driver)
    uint8_t currentCode = (uint8_t)((clampedMa - 4U) / 2U);
    if (currentCode > 0x7FU) {
        currentCode = 0x7FU;
    }
    const uint8_t regVal = enable ? (uint8_t)(0x80U | currentCode) : currentCode;
    writeReg(REG_LED, regVal);
}

void setAS7343Gain(uint8_t gain_level) {
    if (!sensorReady) {
        return;
    }
    const uint8_t clampedGain = (gain_level > 12U) ? 12U : gain_level;
    const uint8_t cfg1 = readReg(REG_CFG1);
    writeReg(REG_CFG1, (uint8_t)((cfg1 & 0xE0U) | clampedGain));
}
