// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_paj7620.h"
#include <Wire.h>

// Portable Flash storage macros: PROGMEM on AVR, standard const on ESP32/other MCUs
#if defined(__AVR__)
  #include <avr/pgmspace.h>
  #define PAJ_PROGMEM PROGMEM
  #define PAJ_READ_BYTE(addr) pgm_read_byte(addr)
#else
  #define PAJ_PROGMEM
  #define PAJ_READ_BYTE(addr) (*(const uint8_t*)(addr))
#endif

// Internal register bank and status addresses
static constexpr uint8_t REG_BANK_SELECT  = 0xEFU;
static constexpr uint8_t REG_PART_ID_LOW  = 0x00U;
static constexpr uint8_t REG_PART_ID_HIGH = 0x01U;
static constexpr uint8_t REG_GESTURE_1    = 0x43U;
static constexpr uint8_t REG_GESTURE_2    = 0x44U;
static constexpr uint8_t REG_FPS_MODE     = 0x65U;

// PixArt PAJ7620U2 register initialization pairs stored in Flash
static const uint8_t PAJ7620_INIT_REGS[][2] PAJ_PROGMEM = {
    {0xEFU, 0x00U}, // Switch to Register Bank 0
    {0x37U, 0x07U}, {0x38U, 0x17U}, {0x39U, 0x06U}, {0x41U, 0x00U},
    {0x42U, 0x00U}, {0x46U, 0x2DU}, {0x47U, 0x0FU}, {0x48U, 0x3CU},
    {0x49U, 0x00U}, {0x4AU, 0x1EU}, {0x4CU, 0x20U}, {0x51U, 0x10U},
    {0x5EU, 0x10U}, {0x60U, 0x27U}, {0x80U, 0x42U}, {0x81U, 0x44U},
    {0x82U, 0x04U}, {0x8BU, 0x01U}, {0x90U, 0x06U}, {0x95U, 0x0AU},
    {0x96U, 0x0CU}, {0x97U, 0x05U}, {0x9AU, 0x14U}, {0x9CU, 0x3FU},
    {0xA5U, 0x19U}, {0xCCU, 0x19U}, {0xCDU, 0x0BU}, {0xCEU, 0x13U},
    {0xCFU, 0x64U}, {0xD0U, 0x21U},
    {0xEFU, 0x01U}, // Switch to Register Bank 1
    {0x02U, 0x0FU}, {0x03U, 0x10U}, {0x04U, 0x02U}, {0x25U, 0x01U},
    {0x27U, 0x39U}, {0x28U, 0x7FU}, {0x29U, 0x08U}, {0x3EU, 0xFFU},
    {0x5EU, 0x3DU}, {0x65U, 0x96U}, {0x67U, 0x97U}, {0x69U, 0xCDU},
    {0x6AU, 0x01U}, {0x6DU, 0x2CU}, {0x6EU, 0x01U}, {0x72U, 0x01U},
    {0x73U, 0x35U}, {0x74U, 0x00U}, {0x77U, 0x01U},
    {0xEFU, 0x00U}, // Return to Register Bank 0 for gesture polling
    {0x41U, 0xFFU}, // Enable all 8 directional and rotational gestures
    {0x42U, 0x01U}  // Enable Wave gesture
};

// Module-private state (6 bytes SRAM total)
static uint8_t  pajAddr = PAJ7620_I2C_ADDR;
static uint8_t  cachedGesture = PAJ7620_GESTURE_NONE;
static uint32_t lastGestureMs = 0UL;
static uint16_t gestureCooldownMs = 250U;

static bool writeReg8(uint8_t reg, uint8_t val) {
    Wire.beginTransmission(pajAddr);
    Wire.write(reg);
    Wire.write(val);
    return Wire.endTransmission() == 0;
}

static bool readReg8(uint8_t reg, uint8_t* outVal) {
    Wire.beginTransmission(pajAddr);
    Wire.write(reg);
    if (Wire.endTransmission(false) != 0) {
        return false;
    }
    if (Wire.requestFrom(pajAddr, (uint8_t)1U) != 1U) {
        return false;
    }
    *outVal = (uint8_t)Wire.read();
    return true;
}

bool initPAJ7620(uint8_t address) {
    pajAddr = address;
    cachedGesture = PAJ7620_GESTURE_NONE;
    lastGestureMs = 0UL;

    Wire.begin();
    // Allow internal PAJ7620U2 power rail and state machine to stabilize
    delay(2);

    Wire.beginTransmission(pajAddr);
    Wire.endTransmission();
    delay(2);

    if (!writeReg8(REG_BANK_SELECT, 0x00U)) {
        return false;
    }

    uint8_t idLow = 0U;
    uint8_t idHigh = 0U;
    if (!readReg8(REG_PART_ID_LOW, &idLow) || !readReg8(REG_PART_ID_HIGH, &idHigh)) {
        return false;
    }

    // Expected PAJ7620U2 ID is 0x7620 (0x20 in low register, 0x76 in high register)
    if (idLow != 0x20U || idHigh != 0x76U) {
        return false;
    }

    const uint8_t regCount = (uint8_t)(sizeof(PAJ7620_INIT_REGS) / sizeof(PAJ7620_INIT_REGS[0]));
    for (uint8_t i = 0U; i < regCount; i++) {
        const uint8_t reg = PAJ_READ_BYTE(&PAJ7620_INIT_REGS[i][0]);
        const uint8_t val = PAJ_READ_BYTE(&PAJ7620_INIT_REGS[i][1]);
        writeReg8(reg, val);
    }

    return true;
}

bool updatePAJ7620() {
    cachedGesture = PAJ7620_GESTURE_NONE;

    Wire.beginTransmission(pajAddr);
    Wire.write(REG_GESTURE_1);
    if (Wire.endTransmission(false) != 0) {
        return false;
    }

    if (Wire.requestFrom(pajAddr, (uint8_t)2U) != 2U) {
        return false;
    }

    const uint8_t reg43 = (uint8_t)Wire.read();
    const uint8_t reg44 = (uint8_t)Wire.read();

    uint8_t detected = PAJ7620_GESTURE_NONE;
    if (reg43 != 0x00U) {
        detected = reg43;
    } else if ((reg44 & 0x01U) != 0U) {
        detected = PAJ7620_GESTURE_WAVE;
    }

    if (detected == PAJ7620_GESTURE_NONE) {
        return false;
    }

    // Suppress rebound gestures while a hand exits the optical field of view
    if (gestureCooldownMs > 0U) {
        const uint32_t nowMs = millis();
        if ((nowMs - lastGestureMs) < gestureCooldownMs) {
            return false;
        }
        lastGestureMs = nowMs;
    }

    cachedGesture = detected;
    return true;
}

uint8_t getPAJ7620Gesture() {
    return cachedGesture;
}

void setPAJ7620FastMode(bool enable) {
    writeReg8(REG_BANK_SELECT, 0x01U);
    // 0xAC = 240 fps fast gesture mode, 0x96 = 120 fps normal mode
    writeReg8(REG_FPS_MODE, enable ? 0xACU : 0x96U);
    writeReg8(REG_BANK_SELECT, 0x00U);
}

void setPAJ7620CooldownMs(uint16_t cooldownMs) {
    gestureCooldownMs = cooldownMs;
}
