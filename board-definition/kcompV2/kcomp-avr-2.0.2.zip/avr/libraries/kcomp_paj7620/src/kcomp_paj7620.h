// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      paj7620
// @title       PAJ7620U2 9-Gesture Optical Sensor
// @targets     avr, esp32s3
// @bus         i2c (0x73)
// @timers      none (uses millis() cooldown)
// @sram_bytes  ~6

#ifndef KCOMP_PAJ7620_H
#define KCOMP_PAJ7620_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Default I2C address of the PAJ7620U2
#define PAJ7620_I2C_ADDR 0x73U

// Gesture output constants returned by getPAJ7620Gesture()
#define PAJ7620_GESTURE_NONE              0x00U
#define PAJ7620_GESTURE_UP                0x01U
#define PAJ7620_GESTURE_DOWN              0x02U
#define PAJ7620_GESTURE_LEFT              0x04U
#define PAJ7620_GESTURE_RIGHT             0x08U
#define PAJ7620_GESTURE_FORWARD           0x10U
#define PAJ7620_GESTURE_BACKWARD          0x20U
#define PAJ7620_GESTURE_CLOCKWISE         0x40U
#define PAJ7620_GESTURE_COUNTER_CLOCKWISE 0x80U
#define PAJ7620_GESTURE_WAVE              0xFFU

// Wake the PAJ7620U2 at the given I2C address, verify ID 0x7620, and load
// the Bank 0 / Bank 1 register initialization table from Flash.
bool initPAJ7620(uint8_t address = PAJ7620_I2C_ADDR);

// Poll the sensor and update the cached gesture state. Returns true when a
// non-zero gesture is accepted (respecting the configured cooldown window).
bool updatePAJ7620();

// Return the most recently accepted gesture code (PAJ7620_GESTURE_* or NONE).
uint8_t getPAJ7620Gesture();

// Switch sensor frame rate between Normal (120 fps, false) and Fast (240 fps, true).
void setPAJ7620FastMode(bool enable);

// Set a non-blocking cooldown window (in ms) after an accepted gesture to
// suppress false rebound triggers as a hand leaves the detection zone.
void setPAJ7620CooldownMs(uint16_t cooldownMs);

#endif
