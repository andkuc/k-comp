// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      ir_transmitter
// @title       Infrared Transmitter (NEC, Sony SIRC, Samsung, Acer)
// @targets     avr, esp32s3
// @bus         digital (1 output pin driving IR LED)
// @timers      none (uses micros() + delayMicroseconds() bit-banging)
// @sram_bytes  ~1

#ifndef KCOMP_IR_TRANSMITTER_H
#define KCOMP_IR_TRANSMITTER_H

#include <Arduino.h>
#include <stdint.h>

// Generic 21-button NEC remote codes
#define IR_BTN_POWER    0xFFA25DUL
#define IR_BTN_MODE     0xFF629DUL
#define IR_BTN_MUTE     0xFFE21DUL
#define IR_BTN_PLAY     0xFF22DDUL
#define IR_BTN_PREV     0xFF02FDUL
#define IR_BTN_NEXT     0xFFC23DUL
#define IR_BTN_EQ       0xFFE01FUL
#define IR_BTN_VOL_DOWN 0xFFA857UL
#define IR_BTN_VOL_UP   0xFF906FUL
#define IR_BTN_0        0xFF6897UL
#define IR_BTN_RPT      0xFF9867UL
#define IR_BTN_USD      0xFFB04FUL
#define IR_BTN_1        0xFF30CFUL
#define IR_BTN_2        0xFF18E7UL
#define IR_BTN_3        0xFF7A85UL
#define IR_BTN_4        0xFF10EFUL
#define IR_BTN_5        0xFF38C7UL
#define IR_BTN_6        0xFF5AA5UL
#define IR_BTN_7        0xFF42BDUL
#define IR_BTN_8        0xFF4AB5UL
#define IR_BTN_9        0xFF52ADUL

// Sony TV 12-bit SIRC codes
#define SONY_BTN_POWER    0xA90UL
#define SONY_BTN_MUTE     0x290UL
#define SONY_BTN_VOL_UP   0x490UL
#define SONY_BTN_VOL_DOWN 0xC90UL
#define SONY_BTN_CH_UP    0x090UL
#define SONY_BTN_CH_DOWN  0x890UL

// Samsung TV 32-bit codes
#define SAMSUNG_BTN_POWER    0xE0E040BFUL
#define SAMSUNG_BTN_SOURCE   0xE0E0807FUL
#define SAMSUNG_BTN_MUTE     0xE0E0F00FUL
#define SAMSUNG_BTN_VOL_UP   0xE0E0E01FUL
#define SAMSUNG_BTN_VOL_DOWN 0xE0E0D02FUL
#define SAMSUNG_BTN_CH_UP    0xE0E048B7UL
#define SAMSUNG_BTN_CH_DOWN  0xE0E008F7UL

// Acer projector NEC extended codes
#define ACER_BTN_POWER  0x1CB920DFUL
#define ACER_BTN_SOURCE 0x1CB9A05FUL
#define ACER_BTN_HIDE   0x1CB9F10EUL

// Configure the IR LED output pin.
void initIRTransmitter(uint8_t pin);

// Transmit infrared frames in standard remote protocols.
void sendIR21Button(uint32_t hexCode);
void sendIRSonyTV(uint32_t hexCode);
void sendIRSamsungTV(uint32_t hexCode);
void sendIRAcerBeamer(uint32_t hexCode);

#endif
