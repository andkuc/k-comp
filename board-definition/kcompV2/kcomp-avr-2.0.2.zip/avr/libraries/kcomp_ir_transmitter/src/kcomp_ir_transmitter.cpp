// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_ir_transmitter.h"

static uint8_t irTxPin = 3U;

static void sendMark(uint16_t durationUs, uint8_t carrierKhz) {
    const uint16_t halfPeriodUs = (carrierKhz == 40U) ? 12U : 13U;
    const uint32_t startUs = micros();
    while ((micros() - startUs) < durationUs) {
        digitalWrite(irTxPin, HIGH);
        delayMicroseconds(halfPeriodUs);
        digitalWrite(irTxPin, LOW);
        delayMicroseconds(halfPeriodUs);
    }
}

static void sendSpace(uint16_t durationUs) {
    digitalWrite(irTxPin, LOW);
    delayMicroseconds(durationUs);
}

void initIRTransmitter(uint8_t pin) {
    irTxPin = pin;
    pinMode(irTxPin, OUTPUT);
    digitalWrite(irTxPin, LOW);
}

void sendIR21Button(uint32_t hexCode) {
    sendMark(9000U, 38U);
    sendSpace(4500U);

    for (int8_t i = 31; i >= 0; i--) {
        sendMark(560U, 38U);
        if ((hexCode & (1UL << (uint8_t)i)) != 0UL) {
            sendSpace(1690U);
        } else {
            sendSpace(560U);
        }
    }
    sendMark(560U, 38U);
    digitalWrite(irTxPin, LOW);
}

void sendIRSonyTV(uint32_t hexCode) {
    for (uint8_t repeat = 0U; repeat < 3U; repeat++) {
        sendMark(2400U, 40U);
        sendSpace(600U);

        for (uint8_t i = 0U; i < 12U; i++) {
            if ((hexCode & (1UL << i)) != 0UL) {
                sendMark(1200U, 40U);
            } else {
                sendMark(600U, 40U);
            }
            sendSpace(600U);
        }
        digitalWrite(irTxPin, LOW);
        delay(45);
    }
}

void sendIRSamsungTV(uint32_t hexCode) {
    sendMark(4500U, 38U);
    sendSpace(4500U);

    for (int8_t i = 31; i >= 0; i--) {
        sendMark(560U, 38U);
        if ((hexCode & (1UL << (uint8_t)i)) != 0UL) {
            sendSpace(1690U);
        } else {
            sendSpace(560U);
        }
    }
    sendMark(560U, 38U);
    digitalWrite(irTxPin, LOW);
}

void sendIRAcerBeamer(uint32_t hexCode) {
    sendIR21Button(hexCode);
}
