// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      ky039
// @title       KY-039 Optical Pulse / Heartbeat Sensor
// @targets     avr, esp32s3
// @bus         analog (1 ADC pin)
// @timers      none (uses millis() 20 ms window)
// @sram_bytes  ~52

#ifndef KCOMP_KY039_H
#define KCOMP_KY039_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Pulse measurement snapshot returned by updateKY039()
struct KY039Data {
    bool beatDetected;       // True for one update cycle when a pulse peak is detected
    uint8_t bpm;             // Weighted average heart rate in beats per minute
    uint16_t intervalDiffMs; // Consecutive inter-beat interval delta in ms
    uint16_t filteredSignal; // Moving-average filtered analog signal value
};

// Initialize the KY-039 analog signal pin.
void initKY039(uint8_t pin);

// Sample the analog pin and advance the 20 ms filter and beat detector.
KY039Data updateKY039();

#endif
