// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_ky039.h"

static constexpr uint8_t  KY039_INVALID_PIN = 255U;
static constexpr uint8_t  WINDOW_SIZE       = 5U;
static constexpr uint8_t  RISE_STEPS_MIN  = 5U;
static constexpr uint32_t CHUNK_MS          = 20UL;

static uint8_t  kyPin = KY039_INVALID_PIN;
static KY039Data latestPulse = {false, 0U, 0U, 0U};

static uint32_t chunkStartMs = 0UL;
static uint32_t chunkSum = 0UL;
static uint16_t chunkSamples = 0U;

static float historyBuf[WINDOW_SIZE] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
static float windowSum = 0.0f;
static uint8_t windowIdx = 0U;
static float prevFiltered = 0.0f;
static uint8_t riseCount = 0U;
static bool inRisingEdge = false;

static uint32_t lastBeatMs = 0UL;
static uint16_t interval1Ms = 0U;
static uint16_t interval2Ms = 0U;
static uint16_t interval3Ms = 0U;

static uint16_t absDiff16(uint16_t a, uint16_t b) {
    return (a >= b) ? (uint16_t)(a - b) : (uint16_t)(b - a);
}

void initKY039(uint8_t pin) {
    kyPin = pin;
    pinMode(kyPin, INPUT);
    chunkStartMs = millis();
    chunkSum = 0UL;
    chunkSamples = 0U;
    windowSum = 0.0f;
    windowIdx = 0U;
    prevFiltered = 0.0f;
    riseCount = 0U;
    inRisingEdge = false;
    lastBeatMs = 0UL;
    interval1Ms = 0U;
    interval2Ms = 0U;
    interval3Ms = 0U;
    latestPulse.beatDetected = false;
    latestPulse.bpm = 0U;
    latestPulse.intervalDiffMs = 0U;
    latestPulse.filteredSignal = 0U;
    for (uint8_t i = 0U; i < WINDOW_SIZE; i++) {
        historyBuf[i] = 0.0f;
    }
}

KY039Data updateKY039() {
    latestPulse.beatDetected = false;
    if (kyPin == KY039_INVALID_PIN) {
        return latestPulse;
    }

    const uint32_t nowMs = millis();
    chunkSum += (uint32_t)analogRead(kyPin);
    chunkSamples++;

    if ((nowMs - chunkStartMs) >= CHUNK_MS) {
        const float avgChunk = (chunkSamples > 0U) ? ((float)chunkSum / (float)chunkSamples) : 0.0f;
        chunkSum = 0UL;
        chunkSamples = 0U;
        chunkStartMs += CHUNK_MS;

        windowSum -= historyBuf[windowIdx];
        windowSum += avgChunk;
        historyBuf[windowIdx] = avgChunk;
        windowIdx = (uint8_t)((windowIdx + 1U) % WINDOW_SIZE);

        const float filtered = windowSum / (float)WINDOW_SIZE;
        latestPulse.filteredSignal = (uint16_t)filtered;

        if (filtered > prevFiltered) {
            riseCount++;
            if (!inRisingEdge && riseCount >= RISE_STEPS_MIN) {
                inRisingEdge = true;
                latestPulse.beatDetected = true;

                const uint32_t deltaMs = (lastBeatMs > 0UL) ? (nowMs - lastBeatMs) : 0UL;
                lastBeatMs = nowMs;

                interval3Ms = interval2Ms;
                interval2Ms = interval1Ms;
                interval1Ms = (deltaMs > 65535UL) ? 65535U : (uint16_t)deltaMs;

                if (interval3Ms > 0U && interval1Ms > 0U && interval2Ms > 0U) {
                    const float weightedMs = (0.4f * (float)interval1Ms) +
                                           (0.3f * (float)interval2Ms) +
                                           (0.3f * (float)interval3Ms);
                    if (weightedMs > 1.0f) {
                        const float bpmCalc = 60000.0f / weightedMs;
                        latestPulse.bpm = (bpmCalc > 255.0f) ? 255U : (uint8_t)bpmCalc;
                    }
                    latestPulse.intervalDiffMs = absDiff16(interval1Ms, interval2Ms);
                }
            }
        } else {
            inRisingEdge = false;
            riseCount = 0U;
        }
        prevFiltered = filtered;
    }

    return latestPulse;
}
