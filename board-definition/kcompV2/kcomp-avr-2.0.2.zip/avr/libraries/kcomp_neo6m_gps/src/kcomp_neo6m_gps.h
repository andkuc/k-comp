// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      neo6m_gps
// @title       GY-NEO6M GPS Receiver (NMEA)
// @targets     avr, esp32s3
// @bus         uart (SoftwareSerial on AVR, Serial1 on ESP32-S3; default 9600 baud)
// @timers      none (PCINT on AVR SoftwareSerial)
// @sram_bytes  ~170

#ifndef KCOMP_NEO6M_GPS_H
#define KCOMP_NEO6M_GPS_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// 8-point compass cardinal directions
enum GPSCardinal : uint8_t {
    CARDINAL_N = 0U,
    CARDINAL_NE,
    CARDINAL_E,
    CARDINAL_SE,
    CARDINAL_S,
    CARDINAL_SW,
    CARDINAL_W,
    CARDINAL_NW,
    CARDINAL_UNKNOWN
};

// Parsed GPS navigation, fix quality, and local time snapshot
struct GPSData {
    double latitude;
    double longitude;
    float altitude;
    float speedKmh;
    float courseDeg;
    uint16_t year;
    uint8_t month;
    uint8_t day;
    uint8_t hour;
    uint8_t minute;
    uint8_t second;
    int8_t timezoneOffset;
    bool dstActive;
    uint8_t satellites;
    float hdop;
    bool valid;
    bool updated;
};

// Initialize UART communication with the NEO-6M GPS module.
bool initGPS(uint8_t rxPin, uint8_t txPin, uint32_t baudRate = 9600UL);

// Process incoming NMEA bytes; call continuously in loop().
// Returns true when a valid $GPRMC fix sentence was parsed.
bool updateGPS();

// Return the latest parsed GPS snapshot.
GPSData getGPSData();

// Configure manual timezone offset (hours), DST (+1 h), or solar auto-estimate.
void setGPSTimezoneOffset(int8_t hours);
void setGPSDST(bool enabled);
void setGPSAutoTimezone(bool enable);

// Great-circle distance (meters), bearing (degrees), and compass cardinal helpers.
double getGPSDistanceMeters(double lat1, double lon1, double lat2, double lon2);
double getGPSCourseDeg(double lat1, double lon1, double lat2, double lon2);
GPSCardinal getGPSCardinal(double courseDeg);

#endif
