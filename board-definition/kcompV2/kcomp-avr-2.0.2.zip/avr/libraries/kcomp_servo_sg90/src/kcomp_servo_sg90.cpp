// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_servo_sg90.h"

#if defined(__AVR__)
  #include <avr/interrupt.h>
  #include <avr/io.h>
#endif

// Standard RC servo pulse bounds (microseconds) within a 20 ms (50 Hz) frame
static constexpr uint16_t SERVO_MIN_US     = 544U;
static constexpr uint16_t SERVO_NEUTRAL_US = 1500U;
static constexpr uint16_t SERVO_MAX_US     = 2400U;
static constexpr uint16_t SERVO_FRAME_US   = 20000U;

struct ServoChannel {
    uint8_t  pin;
    uint8_t  type;
    bool     active;
    uint16_t pulseUs;
};

static volatile ServoChannel channels[SERVO_MAX_COUNT] = {
    {0U, SERVO_TYPE_180, false, SERVO_NEUTRAL_US},
    {0U, SERVO_TYPE_180, false, SERVO_NEUTRAL_US},
    {0U, SERVO_TYPE_180, false, SERVO_NEUTRAL_US},
    {0U, SERVO_TYPE_180, false, SERVO_NEUTRAL_US}
};

#if defined(__AVR__)
// At 16 MHz with Timer1 prescaler 8, 1 tick = 0.5 us (2 ticks per microsecond)
static constexpr uint16_t TICKS_PER_US   = 2U;
static constexpr uint16_t FRAME_TICKS    = SERVO_FRAME_US * TICKS_PER_US;

static bool timer1Initialized = false;
static volatile uint8_t  isrChannel = 0U;
static volatile uint16_t isrFrameTicks = 0U;

static void initTimer1ServoEngine() {
    if (timer1Initialized) {
        return;
    }
    noInterrupts();
    TCCR1A = 0U;
    TCCR1B = 0U;
    TCNT1  = 0U;
    // CTC mode (WGM12) + prescaler 8 (CS11) -> 2 MHz (0.5 us resolution)
    TCCR1B = (uint8_t)((1U << WGM12) | (1U << CS11));
    OCR1A  = 4000U;
    TIFR1  = (uint8_t)(1U << OCF1A);
    TIMSK1 |= (uint8_t)(1U << OCIE1A);
    isrChannel = 0U;
    isrFrameTicks = 0U;
    timer1Initialized = true;
    interrupts();
}

ISR(TIMER1_COMPA_vect) {
    // End pulse on the previously driven channel
    if (isrChannel > 0U && isrChannel <= SERVO_MAX_COUNT) {
        const uint8_t prev = (uint8_t)(isrChannel - 1U);
        if (channels[prev].active) {
            digitalWrite(channels[prev].pin, LOW);
        }
    }

    // Start pulse on the next active channel
    while (isrChannel < SERVO_MAX_COUNT) {
        const uint8_t ch = isrChannel++;
        if (channels[ch].active) {
            const uint16_t ticks = channels[ch].pulseUs * TICKS_PER_US;
            digitalWrite(channels[ch].pin, HIGH);
            OCR1A = ticks;
            isrFrameTicks = (uint16_t)(isrFrameTicks + ticks);
            return;
        }
    }

    // Wait out the remainder of the 20 ms frame before starting channel 0 again
    uint16_t restTicks = (isrFrameTicks < FRAME_TICKS) ? (uint16_t)(FRAME_TICKS - isrFrameTicks) : 2000U;
    if (restTicks < 500U) {
        restTicks = 500U;
    }
    OCR1A = restTicks;
    isrChannel = 0U;
    isrFrameTicks = 0U;
}
#endif

static void applyPulseUs(uint8_t id, uint16_t pulseUs) {
    if (pulseUs < SERVO_MIN_US) pulseUs = SERVO_MIN_US;
    if (pulseUs > SERVO_MAX_US) pulseUs = SERVO_MAX_US;

#if defined(__AVR__)
    noInterrupts();
    channels[id].pulseUs = pulseUs;
    interrupts();
#elif defined(ESP32)
    channels[id].pulseUs = pulseUs;
    // 14-bit LEDC duty at 50 Hz (20000 us period): duty = pulseUs * 16383 / 20000
    const uint32_t duty = ((uint32_t)pulseUs * 16383UL) / (uint32_t)SERVO_FRAME_US;
    ledcWrite(channels[id].pin, duty);
#else
    channels[id].pulseUs = pulseUs;
#endif
}

bool initServo(uint8_t id, uint8_t pin, uint8_t type) {
    if (id >= SERVO_MAX_COUNT) {
        return false;
    }

    pinMode(pin, OUTPUT);
    digitalWrite(pin, LOW);

#if defined(__AVR__)
    noInterrupts();
    channels[id].pin = pin;
    channels[id].type = type;
    channels[id].pulseUs = SERVO_NEUTRAL_US;
    channels[id].active = true;
    interrupts();
    initTimer1ServoEngine();
#elif defined(ESP32)
    channels[id].pin = pin;
    channels[id].type = type;
    channels[id].pulseUs = SERVO_NEUTRAL_US;
    channels[id].active = true;
    ledcAttach(pin, 50U, 14U);
    applyPulseUs(id, SERVO_NEUTRAL_US);
#else
    channels[id].pin = pin;
    channels[id].type = type;
    channels[id].pulseUs = SERVO_NEUTRAL_US;
    channels[id].active = true;
#endif

    stopServo(id);
    return true;
}

void setServoAngle(uint8_t id, uint8_t angle) {
    if (id >= SERVO_MAX_COUNT || !channels[id].active) {
        return;
    }
    if (channels[id].type != SERVO_TYPE_180) {
        return;
    }
    if (angle > 180U) {
        angle = 180U;
    }
    const uint16_t pulseUs = (uint16_t)(SERVO_MIN_US + (((uint32_t)angle * (SERVO_MAX_US - SERVO_MIN_US)) / 180UL));
    applyPulseUs(id, pulseUs);
}

void setServoSpeed(uint8_t id, int8_t speed) {
    if (id >= SERVO_MAX_COUNT || !channels[id].active) {
        return;
    }
    if (channels[id].type != SERVO_TYPE_360) {
        return;
    }
    if (speed < -100) speed = -100;
    if (speed > 100)  speed = 100;

    // Map -100..+100 % to SERVO_MIN_US..SERVO_MAX_US (0 % = SERVO_NEUTRAL_US)
    const uint16_t halfSpan = (SERVO_MAX_US - SERVO_MIN_US) / 2U;
    const int32_t offset = ((int32_t)speed * (int32_t)halfSpan) / 100L;
    applyPulseUs(id, (uint16_t)((int32_t)SERVO_NEUTRAL_US + offset));
}

void stopServo(uint8_t id) {
    if (id >= SERVO_MAX_COUNT || !channels[id].active) {
        return;
    }
    if (channels[id].type == SERVO_TYPE_360) {
        applyPulseUs(id, SERVO_NEUTRAL_US);
    }
}
