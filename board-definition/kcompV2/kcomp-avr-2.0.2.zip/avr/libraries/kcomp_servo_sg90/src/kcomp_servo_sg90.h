// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      servo_sg90
// @title       SG90 Micro Servo (180 deg & 360 deg Continuous)
// @targets     avr, esp32s3
// @bus         pwm/digital (up to 4 servos; zero Servo.h dependency)
// @timers      Timer1 on AVR (conflicts with PWM on D9/D10), LEDC hardware PWM on ESP32-S3
// @sram_bytes  ~20

#ifndef KCOMP_SERVO_SG90_H
#define KCOMP_SERVO_SG90_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Supported SG90 servo types
#define SERVO_TYPE_180 0U  // Positional servo (0..180 degrees)
#define SERVO_TYPE_360 1U  // Continuous rotation servo (-100..+100 % speed)

// Maximum concurrent servo channels
#define SERVO_MAX_COUNT 4U

// Attach a servo channel (id 0..3) to a digital pin and set neutral position.
bool initServo(uint8_t id, uint8_t pin, uint8_t type);

// Set target angle (0..180 degrees) for a SERVO_TYPE_180 channel.
void setServoAngle(uint8_t id, uint8_t angle);

// Set target speed (-100..+100 %) for a SERVO_TYPE_360 continuous channel.
void setServoSpeed(uint8_t id, int8_t speed);

// Stop a 360-degree continuous servo (neutral 1500 us pulse).
// Positional 180-degree servos keep holding their current angle.
void stopServo(uint8_t id);

#endif
