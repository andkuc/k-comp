// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_joystick.h"

static constexpr int16_t JOYSTICK_CENTER_RAW = 512;
static constexpr int16_t JOYSTICK_MAX_DEFLECTION = 512;
static constexpr int16_t JOYSTICK_DEADZONE = 50;

static uint16_t isqrt32(uint32_t value) {
    uint32_t res = 0UL;
    uint32_t bit = 1UL << 30;
    while (bit > value) {
        bit >>= 2;
    }
    while (bit != 0UL) {
        if (value >= res + bit) {
            value -= res + bit;
            res = (res >> 1) + bit;
        } else {
            res >>= 1;
        }
        bit >>= 2;
    }
    return (uint16_t)res;
}

static JoystickDirection classifyDirection(int16_t x, int16_t y) {
    if (x >= -JOYSTICK_DEADZONE && x <= JOYSTICK_DEADZONE) {
        x = 0;
    }
    if (y >= -JOYSTICK_DEADZONE && y <= JOYSTICK_DEADZONE) {
        y = 0;
    }

    if (x == 0 && y == 0) return JOYSTICK_CENTER;
    if (x < 0 && y == 0)  return JOYSTICK_LEFT;
    if (x > 0 && y == 0)  return JOYSTICK_RIGHT;
    if (x == 0 && y > 0)  return JOYSTICK_UP;
    if (x == 0 && y < 0)  return JOYSTICK_DOWN;
    if (x < 0 && y > 0)   return JOYSTICK_UP_LEFT;
    if (x > 0 && y > 0)   return JOYSTICK_UP_RIGHT;
    if (x < 0 && y < 0)   return JOYSTICK_DOWN_LEFT;
    return JOYSTICK_DOWN_RIGHT;
}

static uint16_t abs16(int16_t v) {
    return (v < 0) ? (uint16_t)(-v) : (uint16_t)v;
}

void initJoystick() {
    pinMode(JOYSTICK_X_PIN, INPUT);
    pinMode(JOYSTICK_Y_PIN, INPUT);
}

uint16_t getJoystickXRaw() {
    return (uint16_t)analogRead(JOYSTICK_X_PIN);
}

int16_t getJoystickXValue() {
    return (int16_t)getJoystickXRaw() - JOYSTICK_CENTER_RAW;
}

uint16_t getJoystickYRaw() {
    return (uint16_t)analogRead(JOYSTICK_Y_PIN);
}

int16_t getJoystickYValue() {
    return (int16_t)getJoystickYRaw() - JOYSTICK_CENTER_RAW;
}

JoystickDirection getJoystickDirection() {
    const int16_t x = getJoystickXValue();
    const int16_t y = getJoystickYValue();
    return classifyDirection(x, y);
}

JoystickState getJoystickState() {
    // Sample both axes exactly once so direction and intensity stay consistent
    const int16_t x = getJoystickXValue();
    const int16_t y = getJoystickYValue();

    JoystickState state;
    state.direction = classifyDirection(x, y);

    switch (state.direction) {
        case JOYSTICK_CENTER:
            state.intensity = 0U;
            break;
        case JOYSTICK_LEFT:
        case JOYSTICK_RIGHT: {
            uint16_t pct = (uint16_t)(((uint32_t)abs16(x) * 100UL) / JOYSTICK_MAX_DEFLECTION);
            state.intensity = (pct > 100U) ? 100U : (uint8_t)pct;
            break;
        }
        case JOYSTICK_UP:
        case JOYSTICK_DOWN: {
            uint16_t pct = (uint16_t)(((uint32_t)abs16(y) * 100UL) / JOYSTICK_MAX_DEFLECTION);
            state.intensity = (pct > 100U) ? 100U : (uint8_t)pct;
            break;
        }
        default: {
            const uint32_t magSq = (uint32_t)((int32_t)x * (int32_t)x + (int32_t)y * (int32_t)y);
            const uint16_t mag = isqrt32(magSq);
            uint16_t pct = (uint16_t)(((uint32_t)mag * 95UL) / JOYSTICK_MAX_DEFLECTION);
            state.intensity = (pct > 100U) ? 100U : (uint8_t)pct;
            break;
        }
    }

    return state;
}
