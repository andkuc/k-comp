// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      joystick
// @title       Onboard 2-Axis Analog Joystick (KY-023)
// @targets     avr
// @bus         analog (X A2, Y A1)
// @timers      none
// @sram_bytes  0

#ifndef KCOMP_JOYSTICK_H
#define KCOMP_JOYSTICK_H

#include <Arduino.h>
#include <stdint.h>

#define JOYSTICK_X_PIN A2
#define JOYSTICK_Y_PIN A1

enum JoystickDirection : uint8_t {
    JOYSTICK_CENTER,
    JOYSTICK_LEFT,
    JOYSTICK_RIGHT,
    JOYSTICK_UP,
    JOYSTICK_DOWN,
    JOYSTICK_UP_LEFT,
    JOYSTICK_UP_RIGHT,
    JOYSTICK_DOWN_LEFT,
    JOYSTICK_DOWN_RIGHT
};

struct JoystickState {
    JoystickDirection direction;
    uint8_t intensity;  // 0..100 %
};

void initJoystick();

uint16_t getJoystickXRaw();
int16_t getJoystickXValue();

uint16_t getJoystickYRaw();
int16_t getJoystickYValue();

JoystickDirection getJoystickDirection();
JoystickState getJoystickState();

#endif
