// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      pn532
// @title       PN532 NFC / RFID Controller
// @targets     avr, esp32s3
// @bus         i2c (0x24)
// @timers      none
// @sram_bytes  ~20

#ifndef KCOMP_PN532_H
#define KCOMP_PN532_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Default 7-bit I2C address of the PN532
#define PN532_I2C_ADDR 0x24U

// Operation status codes
#define PN532_OK        0
#define PN532_ERROR    (-1)
#define PN532_TIMEOUT  (-2)
#define PN532_NO_CARD  (-3)
#define PN532_AUTH_FAIL (-4)

// Supported NFC tag types
enum PN532CardType : uint8_t {
    PN532_CARD_UNKNOWN       = 0U,
    PN532_CARD_MIFARE_CLASSIC = 1U,
    PN532_CARD_NTAG          = 2U
};

// Initialize the PN532 over I2C and configure SAM for contactless target scanning.
// Returns true if ACK is received from the PN532.
bool initPN532(uint8_t address = PN532_I2C_ADDR);

// Poll for a Type A (106 kbps) NFC tag and cache its UID and type internally.
// Returns PN532_OK when a tag is found, or PN532_NO_CARD / PN532_ERROR.
int8_t scanPN532Tag();

// Return the detected card architecture of the last scanned tag.
uint8_t getPN532TagType();

// Return the UID byte length (typically 4 or 7) of the last scanned tag.
uint8_t getPN532UidLength();

// Copy up to maxLen bytes of the last scanned tag UID into uidArray.
void getPN532Uid(uint8_t* uidArray, uint8_t maxLen = 7U);

// Read 16 bytes (MIFARE block or 4 consecutive NTAG pages starting at 'slot').
int8_t readPN532TagMemory(uint8_t slot, uint8_t* bufferArray);

// Write 16 bytes (MIFARE block or 4 consecutive NTAG pages starting at 'slot').
int8_t writePN532TagMemory(uint8_t slot, const uint8_t* dataArray);

// Override the 6-byte MIFARE Classic Key A (default: FF FF FF FF FF FF).
void setPN532MifareKey(const uint8_t* keyArray);

#endif
