// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_pn532.h"
#include <Wire.h>
#include <string.h>

static constexpr uint8_t CMD_SAM_CONFIGURATION   = 0x14U;
static constexpr uint8_t CMD_IN_LIST_PASSIVE_TGT = 0x4AU;
static constexpr uint8_t CMD_IN_DATA_EXCHANGE    = 0x40U;

struct CachedTag {
    uint8_t uid[7];
    uint8_t uidLength;
    uint8_t type;
};

static uint8_t pnAddr = PN532_I2C_ADDR;
static CachedTag activeTag = {{0U, 0U, 0U, 0U, 0U, 0U, 0U}, 0U, PN532_CARD_UNKNOWN};
static uint8_t mifareKey[6] = {0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU};

static void writeCommand(const uint8_t* cmd, uint8_t cmdLen) {
    uint8_t checksum = 0U;

    Wire.beginTransmission(pnAddr);
    Wire.write(0x00U);
    Wire.write(0x00U);
    Wire.write(0xFFU);

    const uint8_t frameLen = (uint8_t)(cmdLen + 1U);
    Wire.write(frameLen);
    Wire.write((uint8_t)((uint8_t)(~frameLen) + 1U));

    Wire.write(0xD4U);
    checksum = (uint8_t)(checksum + 0xD4U);

    for (uint8_t i = 0U; i < cmdLen; i++) {
        Wire.write(cmd[i]);
        checksum = (uint8_t)(checksum + cmd[i]);
    }

    Wire.write((uint8_t)((uint8_t)(~checksum) + 1U));
    Wire.write(0x00U);
    Wire.endTransmission();
}

static bool waitUntilReady(uint16_t timeoutMs) {
    const uint32_t startMs = millis();
    while ((millis() - startMs) < timeoutMs) {
        if (Wire.requestFrom(pnAddr, (uint8_t)1U) == 1U) {
            if ((uint8_t)Wire.read() == 0x01U) {
                return true;
            }
        }
        delay(5);
    }
    return false;
}

static bool readAck() {
    if (!waitUntilReady(150U)) {
        return false;
    }
    if (Wire.requestFrom(pnAddr, (uint8_t)7U) != 7U) {
        return false;
    }
    if ((uint8_t)Wire.read() != 0x01U) {
        return false;
    }

    static const uint8_t expectedAck[6] = {0x00U, 0x00U, 0xFFU, 0x00U, 0xFFU, 0x00U};
    for (uint8_t i = 0U; i < 6U; i++) {
        if ((uint8_t)Wire.read() != expectedAck[i]) {
            return false;
        }
    }
    return true;
}

static int8_t readResponse(uint8_t* buffer, uint8_t maxLen) {
    if (!waitUntilReady(1000U)) {
        return PN532_TIMEOUT;
    }
    const uint8_t reqCount = (uint8_t)(maxLen + 9U);
    const uint8_t got = Wire.requestFrom(pnAddr, reqCount);
    if (got < 9U) {
        return PN532_ERROR;
    }

    if ((uint8_t)Wire.read() != 0x01U) return PN532_ERROR;
    if ((uint8_t)Wire.read() != 0x00U || (uint8_t)Wire.read() != 0x00U || (uint8_t)Wire.read() != 0xFFU) {
        return PN532_ERROR;
    }

    const uint8_t len = (uint8_t)Wire.read();
    const uint8_t lcs = (uint8_t)Wire.read();
    if ((uint8_t)(len + lcs) != 0x00U) {
        return PN532_ERROR;
    }

    const uint8_t tfi = (uint8_t)Wire.read();
    if (tfi != 0xD5U) {
        return PN532_ERROR;
    }

    if (len == 0U) {
        return PN532_ERROR;
    }
    const uint8_t payloadLen = (uint8_t)(len - 1U);
    uint8_t remaining = (uint8_t)(got - 7U);

    for (uint8_t i = 0U; i < payloadLen; i++) {
        const uint8_t b = (remaining > 0U) ? (remaining--, (uint8_t)Wire.read()) : 0U;
        if (i < maxLen && buffer != NULL) {
            buffer[i] = b;
        }
    }
    while (remaining > 0U) {
        Wire.read();
        remaining--;
    }

    return (int8_t)payloadLen;
}

bool initPN532(uint8_t address) {
    pnAddr = address;
    activeTag.type = PN532_CARD_UNKNOWN;
    activeTag.uidLength = 0U;
    Wire.begin();
    delay(10);

    // Wakeup ping for PN532 boards in low-power standby
    Wire.beginTransmission(pnAddr);
    Wire.endTransmission();
    delay(10);

    const uint8_t samCmd[4] = {CMD_SAM_CONFIGURATION, 0x01U, 0x14U, 0x01U};
    writeCommand(samCmd, 4U);
    if (!readAck()) {
        return false;
    }

    uint8_t resp[8];
    readResponse(resp, 8U);
    return true;
}

int8_t scanPN532Tag() {
    const uint8_t scanCmd[3] = {CMD_IN_LIST_PASSIVE_TGT, 0x01U, 0x00U};
    writeCommand(scanCmd, 3U);
    if (!readAck()) {
        return PN532_ERROR;
    }

    if (!waitUntilReady(50U)) {
        return PN532_NO_CARD;
    }

    uint8_t resp[20];
    const int8_t len = readResponse(resp, 20U);
    if (len < 7 || (uint8_t)resp[0] != (uint8_t)(CMD_IN_LIST_PASSIVE_TGT + 1U)) {
        return PN532_ERROR;
    }
    if (resp[1] == 0U) {
        return PN532_NO_CARD;
    }

    const uint8_t sak = resp[5];
    uint8_t uidLen = resp[6];
    if (uidLen > 7U) {
        uidLen = 7U;
    }

    activeTag.uidLength = uidLen;
    for (uint8_t i = 0U; i < uidLen; i++) {
        activeTag.uid[i] = ((uint8_t)(7U + i) < (uint8_t)len) ? resp[7U + i] : 0U;
    }

    if (sak == 0x08U || sak == 0x18U) {
        activeTag.type = PN532_CARD_MIFARE_CLASSIC;
    } else if (sak == 0x00U) {
        activeTag.type = PN532_CARD_NTAG;
    } else {
        activeTag.type = PN532_CARD_UNKNOWN;
    }

    return PN532_OK;
}

uint8_t getPN532TagType() {
    return activeTag.type;
}

uint8_t getPN532UidLength() {
    return activeTag.uidLength;
}

void getPN532Uid(uint8_t* uidArray, uint8_t maxLen) {
    if (uidArray == NULL) {
        return;
    }
    const uint8_t count = (activeTag.uidLength < maxLen) ? activeTag.uidLength : maxLen;
    for (uint8_t i = 0U; i < count; i++) {
        uidArray[i] = activeTag.uid[i];
    }
}

void setPN532MifareKey(const uint8_t* keyArray) {
    if (keyArray == NULL) {
        return;
    }
    for (uint8_t i = 0U; i < 6U; i++) {
        mifareKey[i] = keyArray[i];
    }
}

static bool authenticateMifare(uint8_t blockNumber) {
    const uint8_t authCmd[15] = {
        CMD_IN_DATA_EXCHANGE, 0x01U, 0x60U, blockNumber,
        mifareKey[0], mifareKey[1], mifareKey[2],
        mifareKey[3], mifareKey[4], mifareKey[5],
        activeTag.uid[0], activeTag.uid[1], activeTag.uid[2], activeTag.uid[3]
    };

    writeCommand(authCmd, 15U);
    if (!readAck()) {
        return false;
    }

    uint8_t resp[8];
    const int8_t len = readResponse(resp, 8U);
    return (len >= 2 && (uint8_t)resp[0] == (uint8_t)(CMD_IN_DATA_EXCHANGE + 1U) && resp[1] == 0x00U);
}

int8_t readPN532TagMemory(uint8_t slot, uint8_t* bufferArray) {
    if (bufferArray == NULL) {
        return PN532_ERROR;
    }
    if (activeTag.type == PN532_CARD_UNKNOWN) {
        return PN532_NO_CARD;
    }

    if (activeTag.type == PN532_CARD_MIFARE_CLASSIC) {
        if (!authenticateMifare(slot)) {
            return PN532_AUTH_FAIL;
        }
    } else if (activeTag.type != PN532_CARD_NTAG) {
        return PN532_ERROR;
    }

    const uint8_t readCmd[4] = {CMD_IN_DATA_EXCHANGE, 0x01U, 0x30U, slot};
    writeCommand(readCmd, 4U);
    if (!readAck()) {
        return PN532_ERROR;
    }

    uint8_t resp[24];
    const int8_t len = readResponse(resp, 24U);
    if (len < 18 || resp[1] != 0x00U) {
        return PN532_ERROR;
    }

    for (uint8_t i = 0U; i < 16U; i++) {
        bufferArray[i] = resp[2U + i];
    }
    return PN532_OK;
}

int8_t writePN532TagMemory(uint8_t slot, const uint8_t* dataArray) {
    if (dataArray == NULL) {
        return PN532_ERROR;
    }
    if (activeTag.type == PN532_CARD_UNKNOWN) {
        return PN532_NO_CARD;
    }

    if (activeTag.type == PN532_CARD_MIFARE_CLASSIC) {
        if (!authenticateMifare(slot)) {
            return PN532_AUTH_FAIL;
        }

        uint8_t writeCmd[20];
        writeCmd[0] = CMD_IN_DATA_EXCHANGE;
        writeCmd[1] = 0x01U;
        writeCmd[2] = 0xA0U;
        writeCmd[3] = slot;
        for (uint8_t i = 0U; i < 16U; i++) {
            writeCmd[4U + i] = dataArray[i];
        }

        writeCommand(writeCmd, 20U);
        if (!readAck()) {
            return PN532_ERROR;
        }

        uint8_t resp[8];
        const int8_t len = readResponse(resp, 8U);
        return (len >= 2 && resp[1] == 0x00U) ? PN532_OK : PN532_ERROR;
    }

    if (activeTag.type == PN532_CARD_NTAG) {
        for (uint8_t pageOffset = 0U; pageOffset < 4U; pageOffset++) {
            const uint8_t writeCmd[8] = {
                CMD_IN_DATA_EXCHANGE, 0x01U, 0xA2U,
                (uint8_t)(slot + pageOffset),
                dataArray[pageOffset * 4U + 0U],
                dataArray[pageOffset * 4U + 1U],
                dataArray[pageOffset * 4U + 2U],
                dataArray[pageOffset * 4U + 3U]
            };

            writeCommand(writeCmd, 8U);
            if (!readAck()) {
                return PN532_ERROR;
            }

            uint8_t resp[8];
            const int8_t len = readResponse(resp, 8U);
            if (len < 2 || resp[1] != 0x00U) {
                return PN532_ERROR;
            }
        }
        return PN532_OK;
    }

    return PN532_ERROR;
}
