// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_tof400c.h"
#include <Wire.h>

// VL53L1X 16-bit register map constants
static constexpr uint16_t VL53L1X_MODEL_ID_EXPECTED = 0xEACC;

static constexpr uint16_t REG_SOFT_RESET                           = 0x0000;
static constexpr uint16_t REG_OSC_MEASURED_FAST_OSC_FREQ           = 0x0006;
static constexpr uint16_t REG_VHV_CONFIG_TIMEOUT_MACROP_LOOP_BOUND = 0x0008;
static constexpr uint16_t REG_VHV_CONFIG_COUNT_THRESH              = 0x000B;
static constexpr uint16_t REG_ALGO_PART_TO_PART_RANGE_OFFSET_MM    = 0x001E;
static constexpr uint16_t REG_MM_CONFIG_OUTER_OFFSET_MM            = 0x0022;
static constexpr uint16_t REG_DSS_CONFIG_TARGET_TOTAL_RATE_MCPS    = 0x0024;
static constexpr uint16_t REG_GPIO_TIO_HV_STATUS                   = 0x0031;
static constexpr uint16_t REG_SIGMA_ESTIMATOR_EFF_PULSE_WIDTH_NS   = 0x0036;
static constexpr uint16_t REG_SIGMA_ESTIMATOR_EFF_AMBIENT_WIDTH_NS = 0x0037;
static constexpr uint16_t REG_ALGO_CROSSTALK_COMP_VALID_HEIGHT_MM  = 0x0039;
static constexpr uint16_t REG_ALGO_RANGE_IGNORE_VALID_HEIGHT_MM    = 0x003E;
static constexpr uint16_t REG_ALGO_RANGE_MIN_CLIP                  = 0x003F;
static constexpr uint16_t REG_ALGO_CONSISTENCY_CHECK_TOLERANCE     = 0x0040;
static constexpr uint16_t REG_PHASECAL_CONFIG_TIMEOUT_MACROP       = 0x004B;
static constexpr uint16_t REG_DSS_CONFIG_ROI_MODE_CONTROL          = 0x004F;
static constexpr uint16_t REG_SYSTEM_THRESH_RATE_HIGH              = 0x0050;
static constexpr uint16_t REG_SYSTEM_THRESH_RATE_LOW               = 0x0052;
static constexpr uint16_t REG_DSS_CONFIG_MANUAL_EFF_SPADS_SELECT   = 0x0054;
static constexpr uint16_t REG_DSS_CONFIG_APERTURE_ATTENUATION      = 0x0057;
static constexpr uint16_t REG_RANGE_CONFIG_TIMEOUT_MACROP_A        = 0x005E;
static constexpr uint16_t REG_RANGE_CONFIG_VCSEL_PERIOD_A          = 0x0060;
static constexpr uint16_t REG_RANGE_CONFIG_TIMEOUT_MACROP_B        = 0x0061;
static constexpr uint16_t REG_RANGE_CONFIG_VCSEL_PERIOD_B          = 0x0063;
static constexpr uint16_t REG_RANGE_CONFIG_SIGMA_THRESH            = 0x0064;
static constexpr uint16_t REG_RANGE_CONFIG_MIN_COUNT_RATE_MCPS     = 0x0066;
static constexpr uint16_t REG_RANGE_CONFIG_VALID_PHASE_HIGH        = 0x0069;
static constexpr uint16_t REG_SYSTEM_INTERMEASUREMENT_PERIOD       = 0x006C;
static constexpr uint16_t REG_SYSTEM_GROUPED_PARAMETER_HOLD_0      = 0x0071;
static constexpr uint16_t REG_SYSTEM_SEED_CONFIG                   = 0x0077;
static constexpr uint16_t REG_SD_CONFIG_WOI_SD0                    = 0x0078;
static constexpr uint16_t REG_SD_CONFIG_INITIAL_PHASE_SD0          = 0x007A;
static constexpr uint16_t REG_SYSTEM_GROUPED_PARAMETER_HOLD_1      = 0x007C;
static constexpr uint16_t REG_SD_CONFIG_QUANTIFIER                 = 0x007E;
static constexpr uint16_t REG_SYSTEM_SEQUENCE_CONFIG               = 0x0081;
static constexpr uint16_t REG_SYSTEM_GROUPED_PARAMETER_HOLD        = 0x0082;
static constexpr uint16_t REG_SYSTEM_INTERRUPT_CLEAR               = 0x0086;
static constexpr uint16_t REG_SYSTEM_MODE_START                    = 0x0087;
static constexpr uint16_t REG_RESULT_RANGE_STATUS                  = 0x0089;
static constexpr uint16_t REG_RESULT_OSC_CALIBRATE_VAL             = 0x00DE;
static constexpr uint16_t REG_FIRMWARE_SYSTEM_STATUS               = 0x00E5;
static constexpr uint16_t REG_IDENTIFICATION_MODEL_ID              = 0x010F;

static uint8_t tofAddr = TOF400C_I2C_ADDR;
static TOF400CData latestData = {false, 0U};

static void writeReg8(uint16_t reg, uint8_t value) {
    Wire.beginTransmission(tofAddr);
    Wire.write((uint8_t)(reg >> 8));
    Wire.write((uint8_t)(reg & 0xFFU));
    Wire.write(value);
    Wire.endTransmission();
}

static void writeReg16(uint16_t reg, uint16_t value) {
    Wire.beginTransmission(tofAddr);
    Wire.write((uint8_t)(reg >> 8));
    Wire.write((uint8_t)(reg & 0xFFU));
    Wire.write((uint8_t)(value >> 8));
    Wire.write((uint8_t)(value & 0xFFU));
    Wire.endTransmission();
}

static void writeReg32(uint16_t reg, uint32_t value) {
    Wire.beginTransmission(tofAddr);
    Wire.write((uint8_t)(reg >> 8));
    Wire.write((uint8_t)(reg & 0xFFU));
    Wire.write((uint8_t)((value >> 24) & 0xFFUL));
    Wire.write((uint8_t)((value >> 16) & 0xFFUL));
    Wire.write((uint8_t)((value >> 8) & 0xFFUL));
    Wire.write((uint8_t)(value & 0xFFUL));
    Wire.endTransmission();
}

static bool readReg8(uint16_t reg, uint8_t* outVal) {
    Wire.beginTransmission(tofAddr);
    Wire.write((uint8_t)(reg >> 8));
    Wire.write((uint8_t)(reg & 0xFFU));
    if (Wire.endTransmission() != 0) {
        return false;
    }
    if (Wire.requestFrom(tofAddr, (uint8_t)1U) != 1U) {
        return false;
    }
    *outVal = (uint8_t)Wire.read();
    return true;
}

static bool readReg16(uint16_t reg, uint16_t* outVal) {
    Wire.beginTransmission(tofAddr);
    Wire.write((uint8_t)(reg >> 8));
    Wire.write((uint8_t)(reg & 0xFFU));
    if (Wire.endTransmission() != 0) {
        return false;
    }
    if (Wire.requestFrom(tofAddr, (uint8_t)2U) != 2U) {
        return false;
    }
    const uint8_t msb = (uint8_t)Wire.read();
    const uint8_t lsb = (uint8_t)Wire.read();
    *outVal = (uint16_t)(((uint16_t)msb << 8) | lsb);
    return true;
}

bool initTOF400C(uint8_t address) {
    tofAddr = address;
    latestData.isValid = false;
    latestData.distanceMM = 0U;
    Wire.begin();

    uint16_t modelId = 0U;
    if (!readReg16(REG_IDENTIFICATION_MODEL_ID, &modelId) || modelId != VL53L1X_MODEL_ID_EXPECTED) {
        return false;
    }

    // Reset VL53L1X core and wait for firmware boot flag
    writeReg8(REG_SOFT_RESET, 0x00U);
    delay(100);
    writeReg8(REG_SOFT_RESET, 0x01U);
    delay(1);

    uint8_t fwStatus = 0U;
    uint16_t timeoutMs = 0U;
    while (true) {
        if (readReg8(REG_FIRMWARE_SYSTEM_STATUS, &fwStatus) && (fwStatus & 0x01U) != 0U) {
            break;
        }
        delay(1);
        timeoutMs++;
        if (timeoutMs > 100U) {
            return false;
        }
    }

    uint16_t fastOscFreq = 0U;
    readReg16(REG_OSC_MEASURED_FAST_OSC_FREQ, &fastOscFreq);

    writeReg16(REG_VHV_CONFIG_TIMEOUT_MACROP_LOOP_BOUND, (uint16_t)(fastOscFreq * 2000U));
    writeReg8(REG_VHV_CONFIG_COUNT_THRESH, 43U);
    writeReg16(REG_DSS_CONFIG_TARGET_TOTAL_RATE_MCPS, 0x0A00U);
    writeReg8(REG_GPIO_TIO_HV_STATUS, 0x02U);
    writeReg8(REG_SIGMA_ESTIMATOR_EFF_PULSE_WIDTH_NS, 8U);
    writeReg8(REG_SIGMA_ESTIMATOR_EFF_AMBIENT_WIDTH_NS, 16U);
    writeReg8(REG_ALGO_CROSSTALK_COMP_VALID_HEIGHT_MM, 0x01U);
    writeReg8(REG_ALGO_RANGE_IGNORE_VALID_HEIGHT_MM, 0xFFU);
    writeReg8(REG_ALGO_RANGE_MIN_CLIP, 0U);
    writeReg8(REG_ALGO_CONSISTENCY_CHECK_TOLERANCE, 2U);
    writeReg16(REG_SYSTEM_THRESH_RATE_HIGH, 0x0000U);
    writeReg16(REG_SYSTEM_THRESH_RATE_LOW, 0x0000U);
    writeReg8(REG_DSS_CONFIG_APERTURE_ATTENUATION, 0x38U);
    writeReg16(REG_RANGE_CONFIG_SIGMA_THRESH, 360U);
    writeReg16(REG_RANGE_CONFIG_MIN_COUNT_RATE_MCPS, 192U);
    writeReg8(REG_SYSTEM_GROUPED_PARAMETER_HOLD_0, 0x01U);
    writeReg8(REG_SYSTEM_GROUPED_PARAMETER_HOLD_1, 0x01U);
    writeReg8(REG_SD_CONFIG_QUANTIFIER, 2U);
    writeReg8(REG_SYSTEM_GROUPED_PARAMETER_HOLD, 0x00U);
    writeReg8(REG_SYSTEM_SEED_CONFIG, 1U);
    writeReg8(REG_SYSTEM_SEQUENCE_CONFIG, 0x8BU);
    writeReg16(REG_DSS_CONFIG_MANUAL_EFF_SPADS_SELECT, (uint16_t)(200U << 8));
    writeReg8(REG_DSS_CONFIG_ROI_MODE_CONTROL, 2U);

    // Apply factory part-to-part range offset compensation
    uint16_t outerOffsetMm = 0U;
    if (readReg16(REG_MM_CONFIG_OUTER_OFFSET_MM, &outerOffsetMm)) {
        writeReg16(REG_ALGO_PART_TO_PART_RANGE_OFFSET_MM, (uint16_t)(outerOffsetMm * 4U));
    }

    setTOF400CMode(TOF400C_MODE_LONG);
    return true;
}

void setTOF400CMode(TOF400CMode mode) {
    writeReg8(REG_SYSTEM_MODE_START, 0x00U);

    switch (mode) {
        case TOF400C_MODE_SHORT:
            writeReg8(REG_PHASECAL_CONFIG_TIMEOUT_MACROP, 0x14U);
            writeReg8(REG_RANGE_CONFIG_VCSEL_PERIOD_A, 0x07U);
            writeReg8(REG_RANGE_CONFIG_VCSEL_PERIOD_B, 0x05U);
            writeReg8(REG_RANGE_CONFIG_VALID_PHASE_HIGH, 0x38U);
            writeReg16(REG_SD_CONFIG_WOI_SD0, 0x0705U);
            writeReg16(REG_SD_CONFIG_INITIAL_PHASE_SD0, 0x0606U);
            writeReg16(REG_RANGE_CONFIG_TIMEOUT_MACROP_A, 0x014DU);
            writeReg16(REG_RANGE_CONFIG_TIMEOUT_MACROP_B, 0x014DU);
            break;

        case TOF400C_MODE_MEDIUM:
            writeReg8(REG_PHASECAL_CONFIG_TIMEOUT_MACROP, 0x0AU);
            writeReg8(REG_RANGE_CONFIG_VCSEL_PERIOD_A, 0x0BU);
            writeReg8(REG_RANGE_CONFIG_VCSEL_PERIOD_B, 0x09U);
            writeReg8(REG_RANGE_CONFIG_VALID_PHASE_HIGH, 0x78U);
            writeReg16(REG_SD_CONFIG_WOI_SD0, 0x0B09U);
            writeReg16(REG_SD_CONFIG_INITIAL_PHASE_SD0, 0x0A0AU);
            writeReg16(REG_RANGE_CONFIG_TIMEOUT_MACROP_A, 0x01CCU);
            writeReg16(REG_RANGE_CONFIG_TIMEOUT_MACROP_B, 0x01CCU);
            break;

        case TOF400C_MODE_LONG:
        default:
            writeReg8(REG_PHASECAL_CONFIG_TIMEOUT_MACROP, 0x0AU);
            writeReg8(REG_RANGE_CONFIG_VCSEL_PERIOD_A, 0x0FU);
            writeReg8(REG_RANGE_CONFIG_VCSEL_PERIOD_B, 0x0DU);
            writeReg8(REG_RANGE_CONFIG_VALID_PHASE_HIGH, 0xB8U);
            writeReg16(REG_SD_CONFIG_WOI_SD0, 0x0F0DU);
            writeReg16(REG_SD_CONFIG_INITIAL_PHASE_SD0, 0x0E0EU);
            writeReg16(REG_RANGE_CONFIG_TIMEOUT_MACROP_A, 0x01CCU);
            writeReg16(REG_RANGE_CONFIG_TIMEOUT_MACROP_B, 0x01CCU);
            break;
    }

    uint16_t oscCalibrate = 0U;
    readReg16(REG_RESULT_OSC_CALIBRATE_VAL, &oscCalibrate);
    writeReg32(REG_SYSTEM_INTERMEASUREMENT_PERIOD, 50UL * (uint32_t)oscCalibrate);

    writeReg8(REG_SYSTEM_INTERRUPT_CLEAR, 0x01U);
    writeReg8(REG_SYSTEM_MODE_START, 0x40U);
}

TOF400CData getTOF400CData() {
    latestData.isValid = false;

    uint8_t gpioStatus = 0U;
    if (!readReg8(REG_GPIO_TIO_HV_STATUS, &gpioStatus) || (gpioStatus & 0x01U) != 0U) {
        return latestData;
    }

    // 17-byte sequential read starting at RESULT__RANGE_STATUS (0x0089)
    Wire.beginTransmission(tofAddr);
    Wire.write((uint8_t)(REG_RESULT_RANGE_STATUS >> 8));
    Wire.write((uint8_t)(REG_RESULT_RANGE_STATUS & 0xFFU));
    if (Wire.endTransmission() != 0) {
        return latestData;
    }
    if (Wire.requestFrom(tofAddr, (uint8_t)17U) != 17U) {
        return latestData;
    }

    uint8_t buf[17];
    for (uint8_t i = 0U; i < 17U; i++) {
        buf[i] = (uint8_t)Wire.read();
    }

    // Clear interrupt so the sensor begins its next ranging cycle
    writeReg8(REG_SYSTEM_INTERRUPT_CLEAR, 0x01U);

    const uint8_t rangeStatus = (uint8_t)(buf[0] & 0x1FU);
    const uint16_t spads = (uint16_t)(((uint16_t)buf[3] << 8) | buf[4]);
    const uint16_t peakSignal = (uint16_t)(((uint16_t)buf[5] << 8) | buf[6]);
    const uint16_t rangeMm = (uint16_t)(((uint16_t)buf[13] << 8) | buf[14]);

    // Dynamic SPAD selection keeps return signal rate near target without saturating
    if (spads > 0U && peakSignal > 0U) {
        const uint32_t totalRate = ((uint32_t)peakSignal * 256UL) / (uint32_t)spads;
        if (totalRate > 0UL) {
            uint32_t requiredSpads = ((uint32_t)0x0A00UL * 256UL) / totalRate;
            if (requiredSpads > 0xFFFFUL) {
                requiredSpads = 0xFFFFUL;
            }
            writeReg16(REG_DSS_CONFIG_MANUAL_EFF_SPADS_SELECT, (uint16_t)requiredSpads);
        }
    }

    const bool validStatus = (rangeStatus == 0U || rangeStatus == 9U || rangeStatus == 4U || rangeStatus == 7U);
    if (rangeMm > 0U && validStatus) {
        latestData.distanceMM = rangeMm;
        latestData.isValid = true;
    }

    return latestData;
}
