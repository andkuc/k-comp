// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      tof400c
// @title       TOF400C (VL53L1X) Laser Distance Sensor
// @targets     avr, esp32s3
// @bus         i2c (0x29)
// @timers      none
// @sram_bytes  ~6

#ifndef KCOMP_TOF400C_H
#define KCOMP_TOF400C_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Default I2C address of the TOF400C (VL53L1X)
#define TOF400C_I2C_ADDR 0x29U

// Ranging timing / range profiles
enum TOF400CMode : uint8_t {
    TOF400C_MODE_SHORT  = 0U,  // Up to ~1.3 m (resilient in bright ambient light)
    TOF400C_MODE_MEDIUM = 1U,  // Up to ~3.0 m
    TOF400C_MODE_LONG   = 2U   // Up to ~4.0 m (default, best indoors/low light)
};

// Distance measurement result
struct TOF400CData {
    bool isValid;         // True when a fresh valid range sample was read
    uint16_t distanceMM;  // Measured target distance in millimeters
};

// Initialize the TOF400C (VL53L1X), verify model ID 0xEACC, and start ranging.
// Returns true on success, false if missing or boot timed out.
bool initTOF400C(uint8_t address = TOF400C_I2C_ADDR);

// Switch between Short, Medium, and Long ranging modes.
void setTOF400CMode(TOF400CMode mode);

// Poll hardware status and read the latest distance measurement when ready.
TOF400CData getTOF400CData();

#endif
