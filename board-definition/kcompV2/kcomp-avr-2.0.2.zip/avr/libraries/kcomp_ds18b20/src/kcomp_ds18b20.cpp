// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_ds18b20.h"

static constexpr uint8_t  DS_INVALID_PIN       = 255U;
static constexpr uint8_t  CMD_SKIP_ROM         = 0xCCU;
static constexpr uint8_t  CMD_CONVERT_T        = 0x44U;
static constexpr uint8_t  CMD_READ_SCRATCHPAD  = 0xBEU;
static constexpr uint32_t CONVERSION_TIME_MS   = 750UL;

static uint8_t  dsPin = DS_INVALID_PIN;
static uint32_t conversionStartMs = 0UL;
static bool     isConverting = false;

// ==============================================================================
// Minimal Self-Contained 1-Wire Bit-Banging Engine (Zero External Library)
// ==============================================================================

static bool oneWireReset() {
    if (dsPin == DS_INVALID_PIN) {
        return false;
    }

    pinMode(dsPin, INPUT);
    // Pull bus LOW for 480 us reset pulse
    noInterrupts();
    pinMode(dsPin, OUTPUT);
    digitalWrite(dsPin, LOW);
    interrupts();
    delayMicroseconds(480);

    // Release bus and sample presence pulse after 70 us
    noInterrupts();
    pinMode(dsPin, INPUT);
    delayMicroseconds(70);
    const bool present = (digitalRead(dsPin) == LOW);
    interrupts();

    // Finish the 480 us presence timeslot
    delayMicroseconds(410);
    return present;
}

static void oneWireWriteBit(bool bitVal) {
    noInterrupts();
    pinMode(dsPin, OUTPUT);
    digitalWrite(dsPin, LOW);
    if (bitVal) {
        delayMicroseconds(6);
        pinMode(dsPin, INPUT);
        interrupts();
        delayMicroseconds(64);
    } else {
        delayMicroseconds(60);
        pinMode(dsPin, INPUT);
        interrupts();
        delayMicroseconds(10);
    }
}

static bool oneWireReadBit() {
    noInterrupts();
    pinMode(dsPin, OUTPUT);
    digitalWrite(dsPin, LOW);
    delayMicroseconds(3);
    pinMode(dsPin, INPUT);
    delayMicroseconds(10);
    const bool bitVal = (digitalRead(dsPin) == HIGH);
    interrupts();
    delayMicroseconds(53);
    return bitVal;
}

static void oneWireWriteByte(uint8_t value) {
    for (uint8_t i = 0U; i < 8U; i++) {
        oneWireWriteBit((value & 0x01U) != 0U);
        value >>= 1;
    }
}

static uint8_t oneWireReadByte() {
    uint8_t value = 0U;
    for (uint8_t i = 0U; i < 8U; i++) {
        if (oneWireReadBit()) {
            value |= (uint8_t)(1U << i);
        }
    }
    return value;
}

// Dallas/Maxim 1-Wire CRC-8 (polynomial x^8 + x^5 + x^4 + 1 -> reflected 0x8C)
static uint8_t oneWireCrc8(const uint8_t* data, uint8_t len) {
    uint8_t crc = 0U;
    for (uint8_t i = 0U; i < len; i++) {
        uint8_t inByte = data[i];
        for (uint8_t bit = 0U; bit < 8U; bit++) {
            const uint8_t mix = (uint8_t)((crc ^ inByte) & 0x01U);
            crc >>= 1;
            if (mix != 0U) {
                crc ^= 0x8CU;
            }
            inByte >>= 1;
        }
    }
    return crc;
}

// ==============================================================================
// Public API
// ==============================================================================

bool initDS18B20(uint8_t pin) {
    dsPin = pin;
    isConverting = false;
    pinMode(dsPin, INPUT);
    return oneWireReset();
}

void requestDS18B20() {
    if (dsPin == DS_INVALID_PIN) {
        return;
    }
    if (!oneWireReset()) {
        isConverting = false;
        return;
    }
    oneWireWriteByte(CMD_SKIP_ROM);
    oneWireWriteByte(CMD_CONVERT_T);
    conversionStartMs = millis();
    isConverting = true;
}

DS18B20Data getDS18B20Data() {
    DS18B20Data result = {false, 0.0f};
    if (dsPin == DS_INVALID_PIN || !isConverting) {
        return result;
    }

    if ((millis() - conversionStartMs) < CONVERSION_TIME_MS) {
        return result;
    }
    isConverting = false;

    if (!oneWireReset()) {
        return result;
    }
    oneWireWriteByte(CMD_SKIP_ROM);
    oneWireWriteByte(CMD_READ_SCRATCHPAD);

    uint8_t scratchpad[9];
    for (uint8_t i = 0U; i < 9U; i++) {
        scratchpad[i] = oneWireReadByte();
    }

    if (oneWireCrc8(scratchpad, 8U) != scratchpad[8]) {
        return result;
    }

    const int16_t rawTemp = (int16_t)(((uint16_t)scratchpad[1] << 8) | scratchpad[0]);
    result.temperatureC = (float)rawTemp / 16.0f;
    result.isValid = true;
    return result;
}
