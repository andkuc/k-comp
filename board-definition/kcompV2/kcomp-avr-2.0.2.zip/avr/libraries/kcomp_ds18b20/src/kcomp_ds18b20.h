// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      ds18b20
// @title       DS18B20 Waterproof 1-Wire Temperature Sensor
// @targets     avr, esp32s3
// @bus         1-wire (1 digital pin + external 4.7k pull-up; zero external OneWire lib)
// @timers      none (brief interrupt-guarded microsecond bit slots)
// @sram_bytes  ~12

#ifndef KCOMP_DS18B20_H
#define KCOMP_DS18B20_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Temperature reading result returned by getDS18B20Data()
struct DS18B20Data {
    bool isValid;        // True when 750 ms conversion finished and CRC-8 passed
    float temperatureC;  // Measured temperature in degrees Celsius
};

// Initialize the 1-Wire bus on 'pin' and check for a DS18B20 presence pulse.
// Returns true if a sensor responds, false if missing or pull-up is absent.
bool initDS18B20(uint8_t pin);

// Start a non-blocking 12-bit temperature conversion (takes ~750 ms).
void requestDS18B20();

// Poll conversion status and read scratchpad + CRC-8 once 750 ms have elapsed.
DS18B20Data getDS18B20Data();

#endif
