// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      button
// @title       Shared Button Callback & Timing Definitions
// @targets     avr
// @bus         none (header-only shared types)
// @timers      none
// @sram_bytes  0

#ifndef KCOMP_BUTTON_H
#define KCOMP_BUTTON_H

#include <stdint.h>

// Default button timing thresholds (milliseconds)
#define BUTTON_DEBOUNCE_MS    25U
#define BUTTON_CLICK_MS       200U
#define BUTTON_LONG_PRESS_MS  600U

// Callback signature for asynchronous button events (click, double-click, long press)
typedef void (*ButtonCallback)(void);

#endif
