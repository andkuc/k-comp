// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      button_select
// @title       Onboard SELECT Button
// @targets     avr
// @bus         digital (D4, DIP S1-5, external 10k pull-down, active HIGH)
// @timers      none (uses millis())
// @sram_bytes  ~26

#ifndef KCOMP_BUTTON_SELECT_H
#define KCOMP_BUTTON_SELECT_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>
#include "kcomp_button.h"

// Hardware pin for the K-Comp V2 SELECT button (switches HIGH when pressed)
#define BUTTON_SELECT_PIN 4

// Configure the SELECT button pin and reset internal event state
void initButtonSelect();

// Read the immediate raw button state (true while pressed, false when released)
bool isButtonSelectPressed();

// Advance the non-blocking debounce and gesture state machine; call regularly in loop()
void updateButtonSelect();

// Register optional event callbacks (pass NULL to detach an existing callback)
void attachButtonSelectClick(ButtonCallback callback);
void attachButtonSelectDoubleClick(ButtonCallback callback);
void attachButtonSelectLongPressed(ButtonCallback callback);
void attachButtonSelectLongReleased(ButtonCallback callback);

#endif
