// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_soil_sensor.h"

static constexpr uint8_t  SOIL_INVALID_PIN = 255U;
static constexpr uint8_t  SOIL_AVG_SAMPLES = 5U;

static uint8_t  soilPin = SOIL_INVALID_PIN;
static uint16_t dryValue = 800U;
static uint16_t wetValue = 300U;

void initSoilSensor(uint8_t pin) {
    soilPin = pin;
    pinMode(soilPin, INPUT);
}

void setSoilSensorCalibration(uint16_t dryRaw, uint16_t wetRaw) {
    dryValue = dryRaw;
    wetValue = wetRaw;
}

uint16_t getSoilSensorRaw() {
    if (soilPin == SOIL_INVALID_PIN) {
        return 0U;
    }

    uint32_t sum = 0UL;
    for (uint8_t i = 0U; i < SOIL_AVG_SAMPLES; i++) {
        sum += (uint32_t)analogRead(soilPin);
        if ((i + 1U) < SOIL_AVG_SAMPLES) {
            delay(2);
        }
    }
    return (uint16_t)(sum / SOIL_AVG_SAMPLES);
}

uint8_t getSoilSensorMoisture() {
    if (soilPin == SOIL_INVALID_PIN) {
        return 0U;
    }

    const uint16_t raw = getSoilSensorRaw();
    if (dryValue == wetValue) {
        return 0U;
    }

    // Capacitive probes typically read higher in dry air and lower in wet soil
    int32_t scaled = 0;
    if (dryValue > wetValue) {
        if (raw >= dryValue) return 0U;
        if (raw <= wetValue) return 100U;
        scaled = (((int32_t)dryValue - (int32_t)raw) * 100L) / ((int32_t)dryValue - (int32_t)wetValue);
    } else {
        if (raw <= dryValue) return 0U;
        if (raw >= wetValue) return 100U;
        scaled = (((int32_t)raw - (int32_t)dryValue) * 100L) / ((int32_t)wetValue - (int32_t)dryValue);
    }

    if (scaled < 0L)   return 0U;
    if (scaled > 100L) return 100U;
    return (uint8_t)scaled;
}
