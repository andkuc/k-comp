// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      soil_sensor
// @title       Capacitive Soil Moisture Sensor
// @targets     avr, esp32s3
// @bus         analog (1 ADC pin)
// @timers      none
// @sram_bytes  ~5

#ifndef KCOMP_SOIL_SENSOR_H
#define KCOMP_SOIL_SENSOR_H

#include <Arduino.h>
#include <stdint.h>

// Default ADC full-scale ceiling (1023 on 10-bit AVR ADC)
#define SOIL_ADC_MAX_DEFAULT 1023U

// Initialize the capacitive soil moisture sensor on an analog input pin.
void initSoilSensor(uint8_t pin);

// Set raw ADC reference points for 0% (dry air) and 100% (submerged in water).
void setSoilSensorCalibration(uint16_t dryRaw, uint16_t wetRaw);

// Read averaged raw analog value from the sensor pin.
uint16_t getSoilSensorRaw();

// Read calibrated soil moisture percentage (0..100%).
uint8_t getSoilSensorMoisture();

#endif
