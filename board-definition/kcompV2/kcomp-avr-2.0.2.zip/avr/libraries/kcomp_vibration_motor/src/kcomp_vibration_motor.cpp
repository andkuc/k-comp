// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_vibration_motor.h"

static constexpr uint8_t VIB_INVALID_PIN = 255U;

static uint8_t  vibPin = VIB_INVALID_PIN;
static uint32_t pulseStartMs = 0UL;
static uint16_t pulseDurationMs = 0U;
static bool     pulseActive = false;

void initVibrationMotor(uint8_t pin) {
    vibPin = pin;
    pulseActive = false;
    pulseDurationMs = 0U;
    pinMode(vibPin, OUTPUT);
    analogWrite(vibPin, 0);
}

void setVibrationMotor(uint8_t intensity) {
    if (vibPin == VIB_INVALID_PIN) {
        return;
    }
    pulseActive = false;
    analogWrite(vibPin, (int)intensity);
}

void stopVibrationMotor() {
    if (vibPin == VIB_INVALID_PIN) {
        return;
    }
    pulseActive = false;
    analogWrite(vibPin, 0);
}

void pulseVibrationMotor(uint8_t intensity, uint16_t durationMs) {
    if (vibPin == VIB_INVALID_PIN) {
        return;
    }
    if (durationMs == 0U || intensity == 0U) {
        stopVibrationMotor();
        return;
    }
    pulseStartMs = millis();
    pulseDurationMs = durationMs;
    pulseActive = true;
    analogWrite(vibPin, (int)intensity);
}

void updateVibrationMotor() {
    if (vibPin == VIB_INVALID_PIN || !pulseActive) {
        return;
    }
    if ((millis() - pulseStartMs) >= pulseDurationMs) {
        analogWrite(vibPin, 0);
        pulseActive = false;
    }
}
