// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      vibration_motor
// @title       PWM Vibration Motor Module
// @targets     avr, esp32s3
// @bus         pwm (1 PWM-capable pin)
// @timers      none (uses millis() for timed pulses)
// @sram_bytes  ~12

#ifndef KCOMP_VIBRATION_MOTOR_H
#define KCOMP_VIBRATION_MOTOR_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Initialize the vibration motor on a PWM-capable output pin.
void initVibrationMotor(uint8_t pin);

// Set steady vibration duty cycle (0 = off, 255 = full power) and cancel any pulse.
void setVibrationMotor(uint8_t intensity);

// Stop vibration immediately.
void stopVibrationMotor();

// Start a non-blocking vibration pulse (0..255 intensity) for durationMs milliseconds.
void pulseVibrationMotor(uint8_t intensity, uint16_t durationMs);

// Advance non-blocking pulse timing; call regularly in loop().
void updateVibrationMotor();

#endif
