// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_tcs34725.h"
#include <Wire.h>
#include <math.h>

static constexpr uint8_t COMMAND_BIT  = 0x80U;
static constexpr uint8_t AUTOINC_BIT  = 0x20U;
static constexpr uint8_t REG_ENABLE   = 0x00U;
static constexpr uint8_t REG_ATIME    = 0x01U;
static constexpr uint8_t REG_CONTROL  = 0x0FU;
static constexpr uint8_t REG_ID       = 0x12U;
static constexpr uint8_t REG_STATUS   = 0x13U;
static constexpr uint8_t REG_CDATAL   = 0x14U;

static uint8_t colorAddr = TCS34725_I2C_ADDR;
static uint16_t rawRed = 0U;
static uint16_t rawGreen = 0U;
static uint16_t rawBlue = 0U;
static uint16_t rawClear = 0U;
static bool hasValidReading = false;

static uint16_t hsvHue = 0U;
static uint8_t hsvSaturation = 0U;
static uint8_t hsvBrightness = 0U;

static uint16_t threshBlack = 250U;
static uint16_t threshWhite = 10000U;
static uint16_t darkR = 0U;
static uint16_t darkG = 0U;
static uint16_t darkB = 0U;

static uint16_t wbR = 365U;
static uint16_t wbG = 370U;
static uint16_t wbB = 265U;

static bool writeReg8(uint8_t reg, uint8_t value) {
    Wire.beginTransmission(colorAddr);
    Wire.write((uint8_t)(COMMAND_BIT | reg));
    Wire.write(value);
    return Wire.endTransmission() == 0;
}

static bool readReg8(uint8_t reg, uint8_t* outVal) {
    Wire.beginTransmission(colorAddr);
    Wire.write((uint8_t)(COMMAND_BIT | reg));
    if (Wire.endTransmission(false) != 0) {
        return false;
    }
    if (Wire.requestFrom(colorAddr, (uint8_t)1U) != 1U) {
        return false;
    }
    *outVal = (uint8_t)Wire.read();
    return true;
}

static void readRawChannels() {
    Wire.beginTransmission(colorAddr);
    Wire.write((uint8_t)(COMMAND_BIT | AUTOINC_BIT | REG_CDATAL));
    if (Wire.endTransmission(false) != 0) {
        return;
    }
    if (Wire.requestFrom(colorAddr, (uint8_t)8U) != 8U) {
        return;
    }

    const uint16_t c = (uint16_t)((uint8_t)Wire.read() | ((uint16_t)(uint8_t)Wire.read() << 8));
    const uint16_t r = (uint16_t)((uint8_t)Wire.read() | ((uint16_t)(uint8_t)Wire.read() << 8));
    const uint16_t g = (uint16_t)((uint8_t)Wire.read() | ((uint16_t)(uint8_t)Wire.read() << 8));
    const uint16_t b = (uint16_t)((uint8_t)Wire.read() | ((uint16_t)(uint8_t)Wire.read() << 8));

    if (!hasValidReading) {
        rawClear = c;
        rawRed = r;
        rawGreen = g;
        rawBlue = b;
        hasValidReading = true;
    } else {
        rawClear = (uint16_t)(((uint32_t)rawClear + c) >> 1);
        rawRed   = (uint16_t)(((uint32_t)rawRed   + r) >> 1);
        rawGreen = (uint16_t)(((uint32_t)rawGreen + g) >> 1);
        rawBlue  = (uint16_t)(((uint32_t)rawBlue  + b) >> 1);
    }
}

static void updatePerceptualHSV() {
    int32_t rClean = (int32_t)rawRed - (int32_t)darkR;
    int32_t gClean = (int32_t)rawGreen - (int32_t)darkG;
    int32_t bClean = (int32_t)rawBlue - (int32_t)darkB;
    if (rClean < 0) rClean = 0;
    if (gClean < 0) gClean = 0;
    if (bClean < 0) bClean = 0;

    const int32_t rW = (rClean * 1000L) / (int32_t)wbR;
    const int32_t gW = (gClean * 1000L) / (int32_t)wbG;
    const int32_t bW = (bClean * 1000L) / (int32_t)wbB;

    int32_t cMax = rW;
    if (gW > cMax) cMax = gW;
    if (bW > cMax) cMax = bW;

    int32_t cMin = rW;
    if (gW < cMin) cMin = gW;
    if (bW < cMin) cMin = bW;

    const int32_t delta = cMax - cMin;

    uint32_t diffuseWhite = (uint32_t)threshBlack * 10UL;
    if (diffuseWhite > threshWhite) diffuseWhite = threshWhite;
    if (diffuseWhite <= threshBlack) diffuseWhite = (uint32_t)threshBlack + 1000UL;

    if (rawClear <= threshBlack) {
        hsvBrightness = 0U;
    } else if (rawClear >= diffuseWhite) {
        hsvBrightness = 100U;
    } else {
        const uint32_t span = diffuseWhite - (uint32_t)threshBlack;
        const uint32_t norm = (((uint32_t)(rawClear - threshBlack)) * 100UL) / span;
        const float vLin = (float)norm / 100.0f;
        const uint8_t vGamma = (uint8_t)(sqrtf(vLin) * 100.0f + 0.5f);
        hsvBrightness = (vGamma > 100U) ? 100U : vGamma;
    }

    if (cMax <= 10 || delta <= 0) {
        hsvSaturation = 0U;
        hsvHue = 0U;
        return;
    }

    int32_t satPct = (delta * 100L) / cMax;
    if (satPct < 0)   satPct = 0;
    if (satPct > 100) satPct = 100;
    hsvSaturation = (uint8_t)satPct;

    int32_t h = 0;
    if (cMax == rW) {
        h = (60L * (gW - bW)) / delta;
        if (h < 0) h += 360;
    } else if (cMax == gW) {
        h = 120L + (60L * (bW - rW)) / delta;
    } else {
        h = 240L + (60L * (rW - gW)) / delta;
    }
    if (h < 0)    h += 360;
    if (h >= 360) h -= 360;
    hsvHue = (uint16_t)h;
}

bool initColorSensor(uint8_t address) {
    colorAddr = address;
    hasValidReading = false;
    Wire.begin();

    uint8_t id = 0U;
    if (!readReg8(REG_ID, &id) || (id != 0x44U && id != 0x4DU)) {
        return false;
    }

    if (!writeReg8(REG_ATIME, COLOR_TIME_101MS)) return false;
    if (!writeReg8(REG_CONTROL, COLOR_GAIN_4X)) return false;
    if (!writeReg8(REG_ENABLE, 0x01U)) return false;
    delay(3);
    return writeReg8(REG_ENABLE, 0x03U);
}

void setColorIntegrationTime(uint8_t timeSetting) {
    writeReg8(REG_ATIME, timeSetting);
    hasValidReading = false;
}

void setColorGain(uint8_t gainSetting) {
    writeReg8(REG_CONTROL, (uint8_t)(gainSetting & 0x03U));
    hasValidReading = false;
}

void calibrateColorEngine(uint16_t blackThreshold, uint16_t whiteThreshold) {
    threshBlack = blackThreshold;
    threshWhite = (whiteThreshold > blackThreshold) ? whiteThreshold : (uint16_t)(blackThreshold + 1000U);
}

void calibrateBlackLevel() {
    hasValidReading = false;
    updateColorSensor();
    uint32_t sumR = rawRed, sumG = rawGreen, sumB = rawBlue, sumC = rawClear;
    for (uint8_t i = 0U; i < 3U; i++) {
        delay(30);
        readRawChannels();
        sumR += rawRed;
        sumG += rawGreen;
        sumB += rawBlue;
        sumC += rawClear;
    }
    darkR = (uint16_t)(sumR >> 2);
    darkG = (uint16_t)(sumG >> 2);
    darkB = (uint16_t)(sumB >> 2);
    const uint16_t avgC = (uint16_t)(sumC >> 2);
    threshBlack = (uint16_t)(avgC + (avgC >> 1) + 40U);
}

void calibrateWhiteBalance() {
    hasValidReading = false;
    updateColorSensor();
    uint32_t sumR = rawRed, sumG = rawGreen, sumB = rawBlue, sumC = rawClear;
    for (uint8_t i = 0U; i < 3U; i++) {
        delay(30);
        readRawChannels();
        sumR += rawRed;
        sumG += rawGreen;
        sumB += rawBlue;
        sumC += rawClear;
    }
    const uint32_t r = sumR >> 2;
    const uint32_t g = sumG >> 2;
    const uint32_t b = sumB >> 2;
    const uint32_t c = sumC >> 2;
    const uint32_t rgbSum = r + g + b;

    if (rgbSum > 100UL) {
        wbR = (uint16_t)((r * 1000UL) / rgbSum);
        wbG = (uint16_t)((g * 1000UL) / rgbSum);
        wbB = (uint16_t)((b * 1000UL) / rgbSum);
    }
    if (c > (uint32_t)threshBlack + 500UL) {
        threshWhite = (uint16_t)((c * 85UL) / 100UL);
    }
}

void updateColorSensor() {
    uint8_t status = 0U;
    if (!hasValidReading) {
        const uint32_t startMs = millis();
        while ((millis() - startMs) <= 160UL) {
            if (readReg8(REG_STATUS, &status) && (status & 0x01U) != 0U) {
                break;
            }
        }
        readRawChannels();
        updatePerceptualHSV();
        return;
    }

    if (readReg8(REG_STATUS, &status) && (status & 0x01U) != 0U) {
        readRawChannels();
        updatePerceptualHSV();
    }
}

uint16_t getColorRed()        { return rawRed; }
uint16_t getColorGreen()      { return rawGreen; }
uint16_t getColorBlue()       { return rawBlue; }
uint16_t getColorClear()      { return rawClear; }
uint16_t getColorHue()        { return hsvHue; }
uint8_t getColorSaturation()  { return hsvSaturation; }
uint8_t getColorBrightness()  { return hsvBrightness; }

uint16_t getColorLux() {
    const float lux = (-0.32466f * (float)rawRed) + (1.57837f * (float)rawGreen) + (-0.73191f * (float)rawBlue);
    return (lux > 0.0f) ? (uint16_t)lux : 0U;
}

uint16_t getColorTemperature() {
    const float xTri = -0.14282f * (float)rawRed + 1.54924f * (float)rawGreen - 0.95641f * (float)rawBlue;
    const float yTri = -0.32466f * (float)rawRed + 1.57837f * (float)rawGreen - 0.73191f * (float)rawBlue;
    const float zTri = -0.68202f * (float)rawRed + 0.77073f * (float)rawGreen + 0.56332f * (float)rawBlue;
    const float sum = xTri + yTri + zTri;
    if (sum <= 0.001f) {
        return 0U;
    }
    const float xc = xTri / sum;
    const float yc = yTri / sum;
    const float denom = 0.1858f - yc;
    if (fabsf(denom) < 0.0001f) {
        return 0U;
    }
    const float n = (xc - 0.3320f) / denom;
    const float cct = 449.0f * (n * n * n) + 3525.0f * (n * n) + 6823.3f * n + 5520.33f;
    return (cct > 0.0f) ? (uint16_t)cct : 0U;
}

uint8_t estimateColor() {
    if (!hasValidReading) {
        updateColorSensor();
    }
    if (rawClear < threshBlack) {
        return (uint8_t)COLOR_BLACK;
    }

    const uint16_t h = hsvHue;
    const uint8_t s = hsvSaturation;
    const uint8_t v = hsvBrightness;

    const uint32_t rgbSum = (uint32_t)rawRed + (uint32_t)rawGreen + (uint32_t)rawBlue;
    if (rgbSum == 0UL) {
        return (uint8_t)COLOR_BLACK;
    }
    const uint8_t rPct = (uint8_t)(((uint32_t)rawRed   * 100UL) / rgbSum);
    const uint8_t gPct = (uint8_t)(((uint32_t)rawGreen * 100UL) / rgbSum);
    const uint8_t bPct = (uint8_t)(((uint32_t)rawBlue  * 100UL) / rgbSum);

    const bool neutralGray = (rPct >= 30U && rPct <= 42U &&
                              gPct >= 31U && gPct <= 43U &&
                              bPct >= 21U && bPct <= 34U && s < 30U);

    if (s < 24U || neutralGray || (rawClear >= threshWhite && s < 28U)) {
        if (rawClear >= threshWhite || (v >= 85U && s < 18U)) {
            return (uint8_t)COLOR_WHITE;
        }
        return (uint8_t)COLOR_GREY;
    }

    if (h >= 295U || h < 15U) {
        if (v < 30U && rPct >= 50U && bPct <= 19U) {
            return (uint8_t)COLOR_DARK_RED;
        }
        if (h >= 295U || bPct >= gPct || bPct >= 17U || rPct < 62U || s < 70U) {
            return (uint8_t)COLOR_PINK;
        }
        if (v < 36U) {
            return (uint8_t)COLOR_DARK_RED;
        }
        return (uint8_t)COLOR_RED;
    }

    if (h >= 15U && h < 34U) {
        if (h < 25U && (bPct >= 18U || (s < 58U && v >= 58U))) {
            return (uint8_t)COLOR_PINK;
        }
        if (h >= 27U && gPct >= 36U && bPct <= 16U && v >= 45U) {
            return (uint8_t)COLOR_YELLOW;
        }
        if (rPct >= 44U && bPct <= 20U && (v < 52U || s < 60U)) {
            return (uint8_t)COLOR_BROWN;
        }
        if (rPct < 44U || s < 32U) {
            return (uint8_t)COLOR_GREY;
        }
        return (uint8_t)COLOR_ORANGE;
    }

    if (h >= 34U && h < 65U) {
        if (rawGreen >= rawRed || h >= 60U) {
            return (uint8_t)COLOR_LIME_GREEN;
        }
        if (s < 52U && bPct >= 16U) {
            return (uint8_t)COLOR_LIGHT_YELLOW;
        }
        return (uint8_t)COLOR_YELLOW;
    }

    if (h >= 65U && h < 168U) {
        if (v < 32U) {
            return (uint8_t)COLOR_FOREST_GREEN;
        }
        if (h < 118U || s < 52U || v >= 75U) {
            return (uint8_t)COLOR_LIME_GREEN;
        }
        if (v < 42U && s < 56U) {
            return (uint8_t)COLOR_FOREST_GREEN;
        }
        return (uint8_t)COLOR_GREEN;
    }

    if (h >= 168U && h < 252U) {
        if (v < 32U) {
            return (uint8_t)COLOR_NAVY_BLUE;
        }
        if (h < 208U) {
            if (h < 186U && s >= 58U) return (uint8_t)COLOR_CYAN;
            return (uint8_t)COLOR_LIGHT_BLUE;
        }
        if (s < 52U || v >= 78U) {
            return (uint8_t)COLOR_LIGHT_BLUE;
        }
        if (v < 40U && s < 58U) {
            return (uint8_t)COLOR_NAVY_BLUE;
        }
        return (uint8_t)COLOR_BLUE;
    }

    if (h >= 252U && h < 295U) {
        if (v < 30U && h < 272U) {
            return (uint8_t)COLOR_NAVY_BLUE;
        }
        if (h >= 282U && rPct > bPct) {
            return (uint8_t)COLOR_PINK;
        }
        return (uint8_t)COLOR_PURPLE;
    }

    return (uint8_t)COLOR_UNKNOWN;
}

const char* getColorName(uint8_t colorCode) {
    switch (colorCode) {
        case COLOR_BLACK:        return "Black";
        case COLOR_WHITE:        return "White";
        case COLOR_GREY:         return "Grey";
        case COLOR_RED:          return "Red";
        case COLOR_DARK_RED:     return "Dark Red";
        case COLOR_GREEN:        return "Green";
        case COLOR_FOREST_GREEN: return "Forest Green";
        case COLOR_LIME_GREEN:   return "Lime Green";
        case COLOR_BLUE:         return "Blue";
        case COLOR_NAVY_BLUE:    return "Navy Blue";
        case COLOR_LIGHT_BLUE:   return "Light Blue";
        case COLOR_YELLOW:       return "Yellow";
        case COLOR_LIGHT_YELLOW: return "Light Yellow";
        case COLOR_ORANGE:       return "Orange";
        case COLOR_PINK:         return "Pink";
        case COLOR_BROWN:        return "Brown";
        case COLOR_PURPLE:       return "Purple";
        case COLOR_CYAN:         return "Cyan";
        default:                 return "Unknown";
    }
}
