// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      tcs34725
// @title       TCS34725 RGB Color & Light Sensor
// @targets     avr, esp32s3
// @bus         i2c (0x29)
// @timers      none
// @sram_bytes  ~26

#ifndef KCOMP_TCS34725_H
#define KCOMP_TCS34725_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Default I2C address of the TCS34725
#define TCS34725_I2C_ADDR 0x29U

// Integration time register values (ATIME)
#define COLOR_TIME_2_4MS  0xFFU
#define COLOR_TIME_24MS   0xF6U
#define COLOR_TIME_50MS   0xEBU
#define COLOR_TIME_101MS  0xD5U
#define COLOR_TIME_154MS  0xC0U
#define COLOR_TIME_700MS  0x00U

// Analog gain register values (CONTROL)
#define COLOR_GAIN_1X     0x00U
#define COLOR_GAIN_4X     0x01U
#define COLOR_GAIN_16X    0x02U
#define COLOR_GAIN_60X    0x03U

// 1-byte color classification codes
enum ColorCode : uint8_t {
    COLOR_UNKNOWN      = 0U,
    COLOR_BLACK        = 1U,
    COLOR_WHITE        = 2U,
    COLOR_GREY         = 3U,
    COLOR_RED          = 4U,
    COLOR_DARK_RED     = 5U,
    COLOR_GREEN        = 6U,
    COLOR_FOREST_GREEN = 7U,
    COLOR_LIME_GREEN   = 8U,
    COLOR_BLUE         = 9U,
    COLOR_NAVY_BLUE    = 10U,
    COLOR_LIGHT_BLUE   = 11U,
    COLOR_YELLOW       = 12U,
    COLOR_LIGHT_YELLOW = 13U,
    COLOR_ORANGE       = 14U,
    COLOR_PINK         = 15U,
    COLOR_BROWN        = 16U,
    COLOR_PURPLE       = 17U,
    COLOR_CYAN         = 18U
};

// Initialize the TCS34725 over I2C and enable RGBC measurement.
// Returns true if sensor ID 0x44 or 0x4D is detected.
bool initColorSensor(uint8_t address = TCS34725_I2C_ADDR);

// Configure integration time and analog gain
void setColorIntegrationTime(uint8_t timeSetting);
void setColorGain(uint8_t gainSetting);

// Poll conversion status and refresh raw and perceptual HSV values
void updateColorSensor();

// Calibration helpers for dark level and white reference
void calibrateColorEngine(uint16_t blackThreshold, uint16_t whiteThreshold);
void calibrateWhiteBalance();
void calibrateBlackLevel();

// Raw channel, illuminance, color temperature, and perceptual HSV getters
uint16_t getColorRed();
uint16_t getColorGreen();
uint16_t getColorBlue();
uint16_t getColorClear();
uint16_t getColorLux();
uint16_t getColorTemperature();
uint16_t getColorHue();
uint8_t getColorSaturation();
uint8_t getColorBrightness();

// Classify current reading into a ColorCode and map to a label string
uint8_t estimateColor();
const char* getColorName(uint8_t colorCode);

#endif
