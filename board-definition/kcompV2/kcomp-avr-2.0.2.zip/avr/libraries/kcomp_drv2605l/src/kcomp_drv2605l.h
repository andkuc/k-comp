// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      drv2605l
// @title       DRV2605L Haptic Motor Driver
// @targets     avr, esp32s3
// @bus         i2c (0x5A)
// @timers      none
// @sram_bytes  ~1

#ifndef KCOMP_DRV2605L_H
#define KCOMP_DRV2605L_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Default I2C address of the DRV2605L
#define DRV2605L_I2C_ADDR 0x5AU

// Built-in ROM haptic effect IDs
#define VIBE_STOP             0U
#define VIBE_STRONG_CLICK_100 1U
#define VIBE_STRONG_CLICK_60  2U
#define VIBE_STRONG_CLICK_30  3U
#define VIBE_SHARP_CLICK_100  4U
#define VIBE_SHARP_CLICK_60   5U
#define VIBE_SHARP_CLICK_30   6U
#define VIBE_SHARP_TICK_100   7U
#define VIBE_SHARP_TICK_60    8U
#define VIBE_SHARP_TICK_30    9U
#define VIBE_SOFT_BUMP_100    10U
#define VIBE_SOFT_BUMP_60     11U
#define VIBE_SOFT_BUMP_30     12U
#define VIBE_DOUBLE_CLICK_100 13U
#define VIBE_DOUBLE_CLICK_60  14U
#define VIBE_TRIPLE_CLICK_100 15U
#define VIBE_SOFT_FUZZ_60     16U

#define VIBE_STRONG_BUZZ_100  47U
#define VIBE_STRONG_BUZZ_80   48U
#define VIBE_STRONG_BUZZ_60   49U
#define VIBE_STRONG_BUZZ_40   50U
#define VIBE_STRONG_BUZZ_20   51U
#define VIBE_PULSE_ALERT_100  52U
#define VIBE_PULSE_ALERT_80   53U
#define VIBE_PULSE_ALERT_60   54U
#define VIBE_PULSE_ALERT_40   55U
#define VIBE_PULSE_ALERT_20   56U

#define VIBE_TRANSITION_UP    58U
#define VIBE_TRANSITION_DOWN  59U
#define VIBE_RAMP_UP_LONG     114U
#define VIBE_RAMP_DOWN_LONG   115U
#define VIBE_RAMP_UP_SHORT    116U
#define VIBE_RAMP_DOWN_SHORT  117U

#define VIBE_HEARTBEAT        73U
#define VIBE_HEARTBEAT_FAST   74U
#define VIBE_HEARTBEAT_SLOW   75U

// Initialize the DRV2605L over I2C and select ERM library 1.
// Returns true if the chip responds at the specified address.
bool initDRV2605L(uint8_t address = DRV2605L_I2C_ADDR);

// Trigger a single ROM waveform effect immediately.
void playDRV2605LEffect(uint8_t effectId);

// Stop active waveform playback.
void stopDRV2605L();

// Assign a ROM effect ID to sequence slot 0..7.
void setDRV2605LSequenceSlot(uint8_t slotNumber, uint8_t effectId);

// Trigger playback of the configured sequence slots.
void playDRV2605LSequence();

// Switch to Audio-to-Vibe mode using AC-coupled analog signal on the IN pin.
void setDRV2605LAudioMode();

// Return to internal ROM waveform trigger mode.
void setDRV2605LRomMode();

// Switch to Real-Time Playback (RTP) mode for direct intensity control.
void setDRV2605LRealTimeMode();

// Set raw vibration drive strength (0..255) while in Real-Time Playback mode.
void setDRV2605LIntensity(uint8_t intensity);

#endif
