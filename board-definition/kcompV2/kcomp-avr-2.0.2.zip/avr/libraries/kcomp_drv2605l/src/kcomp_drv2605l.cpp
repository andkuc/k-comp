// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_drv2605l.h"
#include <Wire.h>

// Internal DRV2605L register addresses
static constexpr uint8_t REG_MODE       = 0x01U;
static constexpr uint8_t REG_RTP_INPUT  = 0x02U;
static constexpr uint8_t REG_LIBRARY    = 0x03U;
static constexpr uint8_t REG_WAVESEQ1   = 0x04U;
static constexpr uint8_t REG_WAVESEQ2   = 0x05U;
static constexpr uint8_t REG_GO         = 0x0CU;
static constexpr uint8_t REG_CONTROL1   = 0x1BU;
static constexpr uint8_t REG_CONTROL3   = 0x1DU;

// Operating modes
static constexpr uint8_t MODE_INTERNAL_TRIG = 0x00U;
static constexpr uint8_t MODE_AUDIO_TO_VIBE = 0x04U;
static constexpr uint8_t MODE_REAL_TIME     = 0x05U;

static uint8_t drvAddr = DRV2605L_I2C_ADDR;

static bool writeRegister8(uint8_t reg, uint8_t value) {
    Wire.beginTransmission(drvAddr);
    Wire.write(reg);
    Wire.write(value);
    return Wire.endTransmission() == 0;
}

static uint8_t readRegister8(uint8_t reg) {
    Wire.beginTransmission(drvAddr);
    Wire.write(reg);
    if (Wire.endTransmission() != 0) {
        return 0U;
    }
    if (Wire.requestFrom(drvAddr, (uint8_t)1U) != 1U) {
        return 0U;
    }
    return (uint8_t)Wire.read();
}

bool initDRV2605L(uint8_t address) {
    drvAddr = address;
    Wire.begin();

    Wire.beginTransmission(drvAddr);
    if (Wire.endTransmission() != 0) {
        return false;
    }

    // Exit standby and select ERM library 1
    if (!writeRegister8(REG_MODE, MODE_INTERNAL_TRIG)) {
        return false;
    }
    return writeRegister8(REG_LIBRARY, 1U);
}

void playDRV2605LEffect(uint8_t effectId) {
    writeRegister8(REG_WAVESEQ1, effectId);
    writeRegister8(REG_WAVESEQ2, VIBE_STOP);
    writeRegister8(REG_GO, 1U);
}

void stopDRV2605L() {
    writeRegister8(REG_GO, 0U);
}

void setDRV2605LSequenceSlot(uint8_t slotNumber, uint8_t effectId) {
    if (slotNumber > 7U) {
        return;
    }
    writeRegister8((uint8_t)(REG_WAVESEQ1 + slotNumber), effectId);
}

void playDRV2605LSequence() {
    writeRegister8(REG_GO, 1U);
}

void setDRV2605LAudioMode() {
    // Enable AC coupling on IN pin and select analog input mode
    const uint8_t ctrl1 = readRegister8(REG_CONTROL1);
    writeRegister8(REG_CONTROL1, (uint8_t)(ctrl1 | 0x20U));

    const uint8_t ctrl3 = readRegister8(REG_CONTROL3);
    writeRegister8(REG_CONTROL3, (uint8_t)(ctrl3 & 0xFEU));

    writeRegister8(REG_MODE, MODE_AUDIO_TO_VIBE);
}

void setDRV2605LRomMode() {
    writeRegister8(REG_MODE, MODE_INTERNAL_TRIG);
}

void setDRV2605LRealTimeMode() {
    writeRegister8(REG_MODE, MODE_REAL_TIME);
}

void setDRV2605LIntensity(uint8_t intensity) {
    writeRegister8(REG_RTP_INPUT, intensity);
}
