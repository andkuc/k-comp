// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_ld2410.h"

#if defined(__AVR__)
  #include <SoftwareSerial.h>
  #include <new>
  alignas(SoftwareSerial) static uint8_t ld2410SwSerialStorage[sizeof(SoftwareSerial)];
  static SoftwareSerial* ld2410SwSerial = NULL;
#endif

static Stream* ld2410Port = NULL;

enum LD2410ParseState : uint8_t {
    WAIT_HEADER_1,
    WAIT_HEADER_2,
    WAIT_HEADER_3,
    WAIT_HEADER_4,
    READ_PAYLOAD,
    CHECK_FOOTER_1,
    CHECK_FOOTER_2,
    CHECK_FOOTER_3
};

static LD2410ParseState parseState = WAIT_HEADER_1;
static uint8_t frameBuf[64];
static uint8_t frameIdx = 0U;

static bool hasTarget = false;
static int16_t detectionDistCm = 0;
static uint8_t movingEnergy = 0U;
static uint8_t stationaryEnergy = 0U;
static uint8_t targetType = 0U;

static void parseRadarPacket() {
    if (frameIdx < 13U) {
        return;
    }
    targetType = frameBuf[4];
    hasTarget = (targetType != 0x00U);
    movingEnergy = frameBuf[7];
    stationaryEnergy = frameBuf[10];
    detectionDistCm = (int16_t)(((uint16_t)frameBuf[12] << 8) | frameBuf[11]);
}

bool initLD2410(uint8_t rxPin, uint8_t txPin, uint32_t baudRate) {
    parseState = WAIT_HEADER_1;
    frameIdx = 0U;
    hasTarget = false;
    detectionDistCm = 0;
    movingEnergy = 0U;
    stationaryEnergy = 0U;
    targetType = 0U;

#if defined(__AVR__)
    if (ld2410SwSerial != NULL) {
        ld2410SwSerial->~SoftwareSerial();
        ld2410SwSerial = NULL;
    }
    ld2410SwSerial = new (ld2410SwSerialStorage) SoftwareSerial(rxPin, txPin);
    if (ld2410SwSerial == NULL) {
        ld2410Port = NULL;
        return false;
    }
    ld2410SwSerial->begin((long)baudRate);
    ld2410Port = ld2410SwSerial;
#elif defined(ESP32)
    Serial1.begin(baudRate, SERIAL_8N1, rxPin, txPin);
    ld2410Port = &Serial1;
#else
    (void)rxPin;
    (void)txPin;
    (void)baudRate;
    ld2410Port = NULL;
    return false;
#endif

    // Listen for up to 1.5 seconds for a valid radar frame
    const uint32_t startMs = millis();
    while ((millis() - startMs) < 1500UL) {
        if (updateLD2410()) {
            return true;
        }
    }
    return false;
}

bool updateLD2410() {
    if (ld2410Port == NULL) {
        return false;
    }

    bool updated = false;
    while (ld2410Port->available() > 0) {
        const uint8_t b = (uint8_t)ld2410Port->read();

        switch (parseState) {
            case WAIT_HEADER_1: parseState = (b == 0xF4U) ? WAIT_HEADER_2 : WAIT_HEADER_1; break;
            case WAIT_HEADER_2: parseState = (b == 0xF3U) ? WAIT_HEADER_3 : WAIT_HEADER_1; break;
            case WAIT_HEADER_3: parseState = (b == 0xF2U) ? WAIT_HEADER_4 : WAIT_HEADER_1; break;
            case WAIT_HEADER_4:
                if (b == 0xF1U) {
                    parseState = READ_PAYLOAD;
                    frameIdx = 0U;
                } else {
                    parseState = WAIT_HEADER_1;
                }
                break;

            case READ_PAYLOAD:
                if (frameIdx < 60U) {
                    frameBuf[frameIdx++] = b;
                } else {
                    parseState = WAIT_HEADER_1;
                    break;
                }
                if (b == 0xF8U) {
                    parseState = CHECK_FOOTER_1;
                }
                break;

            case CHECK_FOOTER_1:
                if (frameIdx < 63U) frameBuf[frameIdx++] = b;
                parseState = (b == 0xF7U) ? CHECK_FOOTER_2 : READ_PAYLOAD;
                break;

            case CHECK_FOOTER_2:
                if (frameIdx < 63U) frameBuf[frameIdx++] = b;
                parseState = (b == 0xF6U) ? CHECK_FOOTER_3 : READ_PAYLOAD;
                break;

            case CHECK_FOOTER_3:
                if (frameIdx < 63U) frameBuf[frameIdx++] = b;
                if (b == 0xF5U) {
                    parseRadarPacket();
                    updated = true;
                    parseState = WAIT_HEADER_1;
                } else {
                    parseState = READ_PAYLOAD;
                }
                break;
        }
    }
    return updated;
}

void setLD2410BaudRate(uint32_t newBaud) {
    if (ld2410Port == NULL) {
        return;
    }
    const uint8_t idx = (newBaud == 9600UL) ? 0x01U : ((newBaud == 256000UL) ? 0x07U : 0x04U);

    static const uint8_t cmdEnable[13] = {0xFDU, 0xFCU, 0xFBU, 0xFAU, 0x04U, 0x00U, 0x01U, 0x00U, 0x00U, 0x04U, 0x03U, 0x02U, 0x01U};
    const uint8_t cmdBaud[14]          = {0xFDU, 0xFCU, 0xFBU, 0xFAU, 0x04U, 0x00U, 0xA1U, 0x00U, idx,   0x00U, 0x04U, 0x03U, 0x02U, 0x01U};
    static const uint8_t cmdRestart[12] = {0xFDU, 0xFCU, 0xFBU, 0xFAU, 0x02U, 0x00U, 0xFEU, 0x00U, 0x04U, 0x03U, 0x02U, 0x01U};

    ld2410Port->write(cmdEnable, sizeof(cmdEnable));
    delay(50);
    ld2410Port->write(cmdBaud, sizeof(cmdBaud));
    delay(50);
    ld2410Port->write(cmdRestart, sizeof(cmdRestart));
    delay(200);
}

bool isLD2410PresenceDetected() { return hasTarget; }
bool isLD2410Moving()           { return targetType == 1U || targetType == 3U; }
bool isLD2410Stationary()       { return targetType == 2U || targetType == 3U; }
int16_t getLD2410DistanceCM()   { return detectionDistCm; }
uint8_t getLD2410MovingEnergy() { return movingEnergy; }
uint8_t getLD2410StationaryEnergy() { return stationaryEnergy; }
