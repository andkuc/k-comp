// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      ld2410
// @title       HLK-LD2410C 24 GHz Human Presence Radar
// @targets     avr, esp32s3
// @bus         uart (SoftwareSerial on AVR @ 9600, Serial1 on ESP32-S3 @ 256000/9600)
// @timers      none (PCINT on AVR SoftwareSerial)
// @sram_bytes  ~80

#ifndef KCOMP_LD2410_H
#define KCOMP_LD2410_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Initialize the LD2410 radar UART and wait up to 1.5 s for a valid data frame.
// Returns true if a valid radar frame is received.
bool initLD2410(uint8_t rxPin, uint8_t txPin, uint32_t baudRate = 9600UL);

// Process incoming UART bytes; call continuously in loop().
// Returns true when a complete radar frame was parsed.
bool updateLD2410();

// Presence and motion state getters
bool isLD2410PresenceDetected();
bool isLD2410Moving();
bool isLD2410Stationary();

// Distance (cm) and signal energy (0..100) getters
int16_t getLD2410DistanceCM();
uint8_t getLD2410MovingEnergy();
uint8_t getLD2410StationaryEnergy();

// Reconfigure the sensor's internal baud rate (e.g., 9600 or 256000) and restart it.
void setLD2410BaudRate(uint32_t newBaud);

#endif
