// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      aht10
// @title       AHT10 Temperature & Humidity Sensor
// @targets     avr, esp32s3
// @bus         i2c (0x38 default, 0x39 alt)
// @timers      none
// @sram_bytes  ~1

#ifndef KCOMP_AHT10_H
#define KCOMP_AHT10_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Supported I2C addresses
#define AHT10_ADDR_DEFAULT 0x38
#define AHT10_ADDR_ALT     0x39

// Initialize the AHT10 sensor on the I2C bus and run factory calibration.
// Returns true if the sensor acknowledges at the given address, false otherwise.
bool initAHT10(uint8_t address = AHT10_ADDR_DEFAULT);

// Perform a soft reset of the AHT10 sensor. Returns true on I2C ACK.
bool resetAHT10();

// Trigger a measurement and return temperature in degrees Celsius (NAN on I2C error).
float getAHT10Temperature();

// Trigger a measurement and return relative humidity in %RH (NAN on I2C error).
float getAHT10Humidity();

#endif
