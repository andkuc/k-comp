// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_aht10.h"
#include <Wire.h>
#include <math.h>

// Internal AHT10 command bytes
static constexpr uint8_t AHT10_CMD_CALIBRATE = 0xE1U;
static constexpr uint8_t AHT10_CMD_TRIGGER   = 0xACU;
static constexpr uint8_t AHT10_CMD_SOFTRESET = 0xBAU;

// Module-private active I2C address
static uint8_t aht10Addr = AHT10_ADDR_DEFAULT;

// Trigger a single conversion and extract the 20-bit raw humidity or temperature value.
static bool readAHT10Raw(bool wantHumidity, uint32_t* outRaw) {
    Wire.beginTransmission(aht10Addr);
    Wire.write(AHT10_CMD_TRIGGER);
    Wire.write(0x33U);
    Wire.write(0x00U);
    if (Wire.endTransmission() != 0) {
        return false;
    }

    // Datasheet requires at least 75 ms for conversion
    delay(80);

    if (Wire.requestFrom(aht10Addr, (uint8_t)6U) != 6U) {
        return false;
    }

    uint8_t data[6];
    for (uint8_t i = 0U; i < 6U; i++) {
        data[i] = (uint8_t)Wire.read();
    }

    if (wantHumidity) {
        // 20-bit humidity spans bytes 1, 2, and upper nibble of byte 3
        *outRaw = ((uint32_t)data[1] << 12) | ((uint32_t)data[2] << 4) | ((uint32_t)data[3] >> 4);
    } else {
        // 20-bit temperature spans lower nibble of byte 3, byte 4, and byte 5
        *outRaw = ((uint32_t)(data[3] & 0x0FU) << 16) | ((uint32_t)data[4] << 8) | (uint32_t)data[5];
    }
    return true;
}

bool initAHT10(uint8_t address) {
    aht10Addr = address;
    Wire.begin();

    // Send initialization and calibration command
    Wire.beginTransmission(aht10Addr);
    Wire.write(AHT10_CMD_CALIBRATE);
    Wire.write(0x08U);
    Wire.write(0x00U);
    if (Wire.endTransmission() != 0) {
        return false;
    }

    delay(50);
    return true;
}

bool resetAHT10() {
    Wire.beginTransmission(aht10Addr);
    Wire.write(AHT10_CMD_SOFTRESET);
    if (Wire.endTransmission() != 0) {
        return false;
    }
    delay(20);
    return true;
}

float getAHT10Temperature() {
    uint32_t raw = 0UL;
    if (!readAHT10Raw(false, &raw)) {
        return NAN;
    }
    return ((float)raw * 200.0f / 1048576.0f) - 50.0f;
}

float getAHT10Humidity() {
    uint32_t raw = 0UL;
    if (!readAHT10Raw(true, &raw)) {
        return NAN;
    }
    return ((float)raw * 100.0f) / 1048576.0f;
}
