// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      oled_grid
// @title       OLED 2D Grid & Cursor Engine
// @targets     avr, esp32s3
// @bus         none (links against kcomp_oled or kcomp_oled_paged drawFastVLine/HLine)
// @timers      none
// @sram_bytes  ~20 (plus user-allocated GRID_MEM_SIZE array)

#ifndef KCOMP_OLED_GRID_H
#define KCOMP_OLED_GRID_H

#include <stdbool.h>
#include <stdint.h>

// Compile-time memory calculator: 2 cells per byte (4-bit state 0..15 per cell)
#define GRID_MEM_SIZE(rows, cols) ((((uint16_t)(rows) * (uint16_t)(cols)) + 1U) / 2U)

// Callback signatures for custom cell and cursor rendering
typedef void (*GridRenderCallback)(int16_t anchorX, int16_t anchorY, int16_t cellWidth, int16_t cellHeight, uint8_t cellState);
typedef void (*GridCursorCallback)(int16_t anchorX, int16_t anchorY, int16_t cellWidth, int16_t cellHeight);

// Initialization & callback registration
void initGrid(uint8_t rows, uint8_t cols, int16_t cellW, int16_t cellH, int16_t offsetX, int16_t offsetY, uint8_t* memoryPointer);
void attachGridRender(GridRenderCallback callback);
void attachGridCursorRender(GridCursorCallback callback);

// Bit-packed cell state management (4-bit values 0..15)
void clearGrid();
void setGridCell(uint8_t row, uint8_t col, uint8_t state);
uint8_t getGridCell(uint8_t row, uint8_t col);

// Cursor navigation
void setGridCursorEnabled(bool enable);
void setGridCursor(uint8_t row, uint8_t col);
void moveGridCursor(int8_t deltaRow, int8_t deltaCol);
uint8_t getGridCursorRow();
uint8_t getGridCursorCol();

// Rendering (requires either kcomp_oled.h or kcomp_oled_paged.h in the sketch)
void drawGridFramework();
void renderGrid();

#endif
