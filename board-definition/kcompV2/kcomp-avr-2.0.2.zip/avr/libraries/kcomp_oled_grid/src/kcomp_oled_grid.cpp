// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_oled_grid.h"
#include <stddef.h>

// Hardware geometry hooks resolved at link time from kcomp_oled or kcomp_oled_paged
extern void drawFastVLine(int16_t x, int16_t y, int16_t h, uint8_t color);
extern void drawFastHLine(int16_t x, int16_t y, int16_t w, uint8_t color);

static constexpr uint8_t GRID_LINE_COLOR_WHITE = 1U;

// Module-private grid state
static uint8_t gridRows = 0U;
static uint8_t gridCols = 0U;
static int16_t gridCellW = 0;
static int16_t gridCellH = 0;
static int16_t gridOffsetX = 0;
static int16_t gridOffsetY = 0;
static uint8_t* gridData = NULL;

static uint8_t cursorRow = 0U;
static uint8_t cursorCol = 0U;
static bool cursorActive = false;

static GridRenderCallback gridRenderCallback = NULL;
static GridCursorCallback gridCursorCallback = NULL;

void initGrid(uint8_t rows, uint8_t cols, int16_t cellW, int16_t cellH, int16_t offsetX, int16_t offsetY, uint8_t* memoryPointer) {
    gridRows = rows;
    gridCols = cols;
    gridCellW = cellW;
    gridCellH = cellH;
    gridOffsetX = offsetX;
    gridOffsetY = offsetY;
    gridData = memoryPointer;
    cursorRow = 0U;
    cursorCol = 0U;
}

void attachGridRender(GridRenderCallback callback) {
    gridRenderCallback = callback;
}

void attachGridCursorRender(GridCursorCallback callback) {
    gridCursorCallback = callback;
}

void clearGrid() {
    if (gridData == NULL) {
        return;
    }
    const uint16_t totalBytes = GRID_MEM_SIZE(gridRows, gridCols);
    for (uint16_t i = 0U; i < totalBytes; i++) {
        gridData[i] = 0U;
    }
}

void setGridCell(uint8_t row, uint8_t col, uint8_t state) {
    if (gridData == NULL || row >= gridRows || col >= gridCols || state > 15U) {
        return;
    }

    const uint16_t linearIndex = (uint16_t)row * (uint16_t)gridCols + (uint16_t)col;
    const uint16_t byteIndex = linearIndex / 2U;
    const bool isUpperNibble = (linearIndex & 1U) != 0U;

    if (isUpperNibble) {
        gridData[byteIndex] = (uint8_t)((gridData[byteIndex] & 0x0FU) | (uint8_t)(state << 4));
    } else {
        gridData[byteIndex] = (uint8_t)((gridData[byteIndex] & 0xF0U) | (state & 0x0FU));
    }
}

uint8_t getGridCell(uint8_t row, uint8_t col) {
    if (gridData == NULL || row >= gridRows || col >= gridCols) {
        return 0U;
    }

    const uint16_t linearIndex = (uint16_t)row * (uint16_t)gridCols + (uint16_t)col;
    const uint16_t byteIndex = linearIndex / 2U;
    const bool isUpperNibble = (linearIndex & 1U) != 0U;

    if (isUpperNibble) {
        return (uint8_t)((gridData[byteIndex] >> 4) & 0x0FU);
    }
    return (uint8_t)(gridData[byteIndex] & 0x0FU);
}

void setGridCursorEnabled(bool enable) {
    cursorActive = enable;
}

void setGridCursor(uint8_t row, uint8_t col) {
    if (row < gridRows) {
        cursorRow = row;
    }
    if (col < gridCols) {
        cursorCol = col;
    }
}

void moveGridCursor(int8_t deltaRow, int8_t deltaCol) {
    if (gridRows == 0U || gridCols == 0U) {
        return;
    }

    int16_t newRow = (int16_t)cursorRow + deltaRow;
    int16_t newCol = (int16_t)cursorCol + deltaCol;

    if (newRow < 0) newRow = 0;
    if (newRow >= (int16_t)gridRows) newRow = (int16_t)gridRows - 1;

    if (newCol < 0) newCol = 0;
    if (newCol >= (int16_t)gridCols) newCol = (int16_t)gridCols - 1;

    cursorRow = (uint8_t)newRow;
    cursorCol = (uint8_t)newCol;
}

uint8_t getGridCursorRow() {
    return cursorRow;
}

uint8_t getGridCursorCol() {
    return cursorCol;
}

void drawGridFramework() {
    if (gridRows == 0U || gridCols == 0U || gridCellW <= 0 || gridCellH <= 0) {
        return;
    }

    const int16_t totalWidth = (int16_t)gridCols * gridCellW;
    const int16_t totalHeight = (int16_t)gridRows * gridCellH;

    for (uint8_t c = 0U; c <= gridCols; c++) {
        const int16_t lineX = gridOffsetX + ((int16_t)c * gridCellW);
        drawFastVLine(lineX, gridOffsetY, totalHeight + 1, GRID_LINE_COLOR_WHITE);
    }

    for (uint8_t r = 0U; r <= gridRows; r++) {
        const int16_t lineY = gridOffsetY + ((int16_t)r * gridCellH);
        drawFastHLine(gridOffsetX, lineY, totalWidth + 1, GRID_LINE_COLOR_WHITE);
    }
}

void renderGrid() {
    if (gridData == NULL) {
        return;
    }

    drawGridFramework();

    if (gridRenderCallback != NULL) {
        for (uint8_t r = 0U; r < gridRows; r++) {
            for (uint8_t c = 0U; c < gridCols; c++) {
                const uint8_t state = getGridCell(r, c);
                if (state > 0U) {
                    const int16_t anchorX = gridOffsetX + ((int16_t)c * gridCellW);
                    const int16_t anchorY = gridOffsetY + ((int16_t)r * gridCellH);
                    gridRenderCallback(anchorX, anchorY, gridCellW, gridCellH, state);
                }
            }
        }
    }

    if (cursorActive && gridCursorCallback != NULL) {
        const int16_t cursorAnchorX = gridOffsetX + ((int16_t)cursorCol * gridCellW);
        const int16_t cursorAnchorY = gridOffsetY + ((int16_t)cursorRow * gridCellH);
        gridCursorCallback(cursorAnchorX, cursorAnchorY, gridCellW, gridCellH);
    }
}
