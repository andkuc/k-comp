// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      button_start
// @title       Onboard START Button
// @targets     avr
// @bus         digital (D3, DIP S1-4, external 10k pull-down, active HIGH)
// @timers      none (uses millis())
// @sram_bytes  ~26

#ifndef KCOMP_BUTTON_START_H
#define KCOMP_BUTTON_START_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>
#include "kcomp_button.h"

// Hardware pin for the K-Comp V2 START button (switches HIGH when pressed)
#define BUTTON_START_PIN 3

// Configure the START button pin and reset internal event state
void initButtonStart();

// Read the immediate raw button state (true while pressed, false when released)
bool isButtonStartPressed();

// Advance the non-blocking debounce and gesture state machine; call regularly in loop()
void updateButtonStart();

// Register optional event callbacks (pass NULL to detach an existing callback)
void attachButtonStartClick(ButtonCallback callback);
void attachButtonStartDoubleClick(ButtonCallback callback);
void attachButtonStartLongPressed(ButtonCallback callback);
void attachButtonStartLongReleased(ButtonCallback callback);

#endif
