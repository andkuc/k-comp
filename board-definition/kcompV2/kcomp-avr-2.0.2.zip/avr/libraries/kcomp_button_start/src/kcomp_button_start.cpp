// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_button_start.h"

// Internal finite state machine states for gesture detection
enum ButtonFsmState : uint8_t {
    BTN_STATE_IDLE,
    BTN_STATE_DOWN,
    BTN_STATE_UP,
    BTN_STATE_COUNT,
    BTN_STATE_LONG_HELD,
    BTN_STATE_LONG_RELEASED
};

// Registered event callbacks (module-private)
static ButtonCallback onClickCallback = NULL;
static ButtonCallback onDoubleClickCallback = NULL;
static ButtonCallback onLongPressedCallback = NULL;
static ButtonCallback onLongReleasedCallback = NULL;

// Internal debounce and FSM state (module-private, zero heap allocation)
static ButtonFsmState fsmState = BTN_STATE_IDLE;
static bool debouncedLevel = false;
static bool lastRawLevel = false;
static uint32_t lastDebounceMs = 0UL;
static uint32_t stateStartMs = 0UL;
static uint8_t clickCount = 0U;

// Reset the gesture state machine back to idle without touching debouncer state
static void resetFsmState() {
    fsmState = BTN_STATE_IDLE;
    stateStartMs = 0UL;
    clickCount = 0U;
}

// Software debounce filter: accepts a new level only after it stays stable for BUTTON_DEBOUNCE_MS
static bool debounceSample(bool rawPressed, uint32_t nowMs) {
    if (rawPressed == lastRawLevel) {
        if ((nowMs - lastDebounceMs) >= BUTTON_DEBOUNCE_MS) {
            debouncedLevel = rawPressed;
        }
    } else {
        lastRawLevel = rawPressed;
        lastDebounceMs = nowMs;
    }
    return debouncedLevel;
}

// Process one step of the non-blocking click / double-click / long-press state machine
static void stepButtonFsm(bool isPressed, uint32_t nowMs) {
    const uint32_t elapsedMs = nowMs - stateStartMs;

    switch (fsmState) {
        case BTN_STATE_IDLE:
            if (isPressed) {
                fsmState = BTN_STATE_DOWN;
                stateStartMs = nowMs;
                clickCount = 0U;
            }
            break;

        case BTN_STATE_DOWN:
            if (!isPressed) {
                fsmState = BTN_STATE_UP;
                stateStartMs = nowMs;
            } else if (elapsedMs >= BUTTON_LONG_PRESS_MS) {
                // Transition even without a start callback so a long hold never triggers a click on release
                if (onLongPressedCallback != NULL) {
                    onLongPressedCallback();
                }
                fsmState = BTN_STATE_LONG_HELD;
            }
            break;

        case BTN_STATE_UP:
            clickCount++;
            fsmState = BTN_STATE_COUNT;
            break;

        case BTN_STATE_COUNT:
            if (isPressed) {
                fsmState = BTN_STATE_DOWN;
                stateStartMs = nowMs;
            } else if ((elapsedMs >= BUTTON_CLICK_MS) || (clickCount >= 2U)) {
                if (clickCount == 1U) {
                    if (onClickCallback != NULL) {
                        onClickCallback();
                    }
                } else if (clickCount >= 2U) {
                    if (onDoubleClickCallback != NULL) {
                        onDoubleClickCallback();
                    }
                }
                resetFsmState();
            }
            break;

        case BTN_STATE_LONG_HELD:
            if (!isPressed) {
                fsmState = BTN_STATE_LONG_RELEASED;
                stateStartMs = nowMs;
            }
            break;

        case BTN_STATE_LONG_RELEASED:
            if (onLongReleasedCallback != NULL) {
                onLongReleasedCallback();
            }
            resetFsmState();
            break;

        default:
            resetFsmState();
            break;
    }
}

void initButtonStart() {
    // K-Comp V2 buttons have an external 10k pull-down resistor and switch to +5V (HIGH)
    pinMode(BUTTON_START_PIN, INPUT);
    debouncedLevel = false;
    lastRawLevel = false;
    lastDebounceMs = millis();
    resetFsmState();
}

bool isButtonStartPressed() {
    return digitalRead(BUTTON_START_PIN) == HIGH;
}

void updateButtonStart() {
    const uint32_t nowMs = millis();
    const bool stablePressed = debounceSample(isButtonStartPressed(), nowMs);
    stepButtonFsm(stablePressed, nowMs);
}

void attachButtonStartClick(ButtonCallback callback) {
    onClickCallback = callback;
}

void attachButtonStartDoubleClick(ButtonCallback callback) {
    onDoubleClickCallback = callback;
}

void attachButtonStartLongPressed(ButtonCallback callback) {
    onLongPressedCallback = callback;
}

void attachButtonStartLongReleased(ButtonCallback callback) {
    onLongReleasedCallback = callback;
}
