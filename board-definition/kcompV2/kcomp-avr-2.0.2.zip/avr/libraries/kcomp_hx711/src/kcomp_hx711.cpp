// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_hx711.h"

static constexpr uint8_t  HX711_INVALID_PIN = 255U;
static constexpr uint32_t HX711_TIMEOUT_MS  = 500UL;

static uint8_t hxDoutPin   = HX711_INVALID_PIN;
static uint8_t hxSckPin    = HX711_INVALID_PIN;
static int32_t tareOffset  = 0;
static float   scaleFactor = HX711_SCALE_5KG;

static int32_t readSingleRaw() {
    if (hxDoutPin == HX711_INVALID_PIN || hxSckPin == HX711_INVALID_PIN) {
        return 0;
    }

    // Wait for DOUT LOW (data ready) with timeout so disconnected wires never hang
    const uint32_t startMs = millis();
    while (digitalRead(hxDoutPin) == HIGH) {
        if ((millis() - startMs) > HX711_TIMEOUT_MS) {
            return 0;
        }
    }

    uint32_t raw24 = 0UL;
    for (uint8_t i = 0U; i < 24U; i++) {
        // Keep SCK high pulse strictly under 60 us (otherwise HX711 enters power-down)
        noInterrupts();
        digitalWrite(hxSckPin, HIGH);
        delayMicroseconds(1);
        const uint8_t bitVal = (digitalRead(hxDoutPin) == HIGH) ? 1U : 0U;
        digitalWrite(hxSckPin, LOW);
        interrupts();

        raw24 = (raw24 << 1) | (uint32_t)bitVal;
        delayMicroseconds(1);
    }

    // 25th clock pulse selects Channel A with Gain = 128 for the next conversion
    noInterrupts();
    digitalWrite(hxSckPin, HIGH);
    delayMicroseconds(1);
    digitalWrite(hxSckPin, LOW);
    interrupts();

    // Sign-extend 24-bit two's complement to 32-bit signed integer
    if ((raw24 & 0x800000UL) != 0UL) {
        raw24 |= 0xFF000000UL;
    }
    return (int32_t)raw24;
}

bool initHX711(uint8_t doutPin, uint8_t sckPin) {
    hxDoutPin = doutPin;
    hxSckPin = sckPin;
    tareOffset = 0;

    pinMode(hxDoutPin, INPUT_PULLUP);
    pinMode(hxSckPin, OUTPUT);

    // Hold SCK HIGH for > 60 us to reset the HX711 cleanly
    digitalWrite(hxSckPin, HIGH);
    delayMicroseconds(100);
    digitalWrite(hxSckPin, LOW);

    const uint32_t startMs = millis();
    while (digitalRead(hxDoutPin) == HIGH) {
        if ((millis() - startMs) > HX711_TIMEOUT_MS) {
            return false;
        }
    }

    // Perform one dummy read to latch Channel A, Gain 128
    (void)readSingleRaw();
    return true;
}

bool isHX711Ready() {
    if (hxDoutPin == HX711_INVALID_PIN) {
        return false;
    }
    return digitalRead(hxDoutPin) == LOW;
}

int32_t getHX711Raw(uint8_t samples) {
    const uint8_t count = (samples == 0U) ? 1U : samples;
    int64_t sum = 0;
    for (uint8_t i = 0U; i < count; i++) {
        sum += (int64_t)readSingleRaw();
    }
    return (int32_t)(sum / (int64_t)count);
}

void tareHX711(uint8_t samples) {
    tareOffset = getHX711Raw(samples);
}

void setHX711Scale(float factor) {
    if (factor != 0.0f) {
        scaleFactor = factor;
    }
}

void calibrateHX711(float knownWeightGrams, uint8_t samples) {
    if (knownWeightGrams == 0.0f) {
        return;
    }
    const int32_t netRaw = getHX711Raw(samples) - tareOffset;
    if (netRaw != 0) {
        scaleFactor = (float)netRaw / knownWeightGrams;
    }
}

float getHX711Weight_g(uint8_t samples) {
    if (scaleFactor == 0.0f) {
        return 0.0f;
    }
    const int32_t netRaw = getHX711Raw(samples) - tareOffset;
    return (float)netRaw / scaleFactor;
}
