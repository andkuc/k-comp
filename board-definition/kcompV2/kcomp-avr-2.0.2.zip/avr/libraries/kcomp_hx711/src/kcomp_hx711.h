// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      hx711
// @title       HX711 24-Bit Load Cell Amplifier
// @targets     avr, esp32s3
// @bus         digital (2 GPIO pins: DOUT + SCK)
// @timers      none (brief interrupt-guarded 25-clock shift)
// @sram_bytes  ~12

#ifndef KCOMP_HX711_H
#define KCOMP_HX711_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Approximate default calibration scale factors (raw ADC units per gram)
#define HX711_SCALE_1KG  717.5f
#define HX711_SCALE_5KG  420.0f
#define HX711_SCALE_10KG 210.0f
#define HX711_SCALE_20KG 105.0f

// Reset the HX711, select Channel A (Gain 128), and verify responsiveness.
bool initHX711(uint8_t doutPin, uint8_t sckPin);

// Non-blocking check: returns true when a new 24-bit conversion is ready.
bool isHX711Ready();

// Read averaged raw 24-bit signed ADC counts.
int32_t getHX711Raw(uint8_t samples = 1U);

// Store current averaged reading as the zero-weight tare offset.
void tareHX711(uint8_t samples = 10U);

// Manually set the calibration scale factor (raw counts per gram).
void setHX711Scale(float scaleFactor);

// Compute and store the scale factor using a known reference weight in grams.
void calibrateHX711(float knownWeightGrams, uint8_t samples = 10U);

// Return the tared, calibrated net weight in grams.
float getHX711Weight_g(uint8_t samples = 1U);

#endif
