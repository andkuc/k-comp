// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_led.h"

static uint8_t clampBrightness(uint8_t brightness) {
    return (brightness > 100U) ? 100U : brightness;
}

static uint8_t brightnessToPwm(uint8_t brightness) {
    const uint8_t pct = clampBrightness(brightness);
    return (uint8_t)(((uint16_t)pct * 255U + 50U) / 100U);
}

void initLed() {
    pinMode(LED_PIN, OUTPUT);
    digitalWrite(LED_PIN, LOW);
}

void setLed(uint8_t brightness) {
    if (brightness == 0U) {
        digitalWrite(LED_PIN, LOW);
        return;
    }
    analogWrite(LED_PIN, brightnessToPwm(brightness));
}

void setLedOff() {
    digitalWrite(LED_PIN, LOW);
}

void fadeLedInBlocking(uint8_t brightness, uint16_t durationMs) {
    const uint8_t targetPwm = brightnessToPwm(brightness);
    if (durationMs == 0U || targetPwm == 0U) {
        setLed(brightness);
        return;
    }

    const uint32_t startMs = millis();
    uint32_t elapsed = 0U;
    while ((elapsed = millis() - startMs) < durationMs) {
        // Smooth quadratic ease-in (0..255) without floating-point math
        const uint32_t norm = (elapsed * 255UL) / durationMs;
        const uint8_t pwm = (uint8_t)((targetPwm * norm * norm) / 65025UL);
        analogWrite(LED_PIN, pwm);
        delay(5);
    }
    analogWrite(LED_PIN, targetPwm);
}

void fadeLedOutBlocking(uint8_t brightness, uint16_t durationMs) {
    const uint8_t startPwm = brightnessToPwm(brightness);
    if (durationMs == 0U || startPwm == 0U) {
        setLedOff();
        return;
    }

    const uint32_t startMs = millis();
    uint32_t elapsed = 0U;
    while ((elapsed = millis() - startMs) < durationMs) {
        // Smooth quadratic ease-out (startPwm..0) without floating-point math
        const uint32_t remaining = ((uint32_t)(durationMs - elapsed) * 255UL) / durationMs;
        const uint8_t pwm = (uint8_t)((startPwm * remaining * remaining) / 65025UL);
        analogWrite(LED_PIN, pwm);
        delay(5);
    }
    digitalWrite(LED_PIN, LOW);
}
