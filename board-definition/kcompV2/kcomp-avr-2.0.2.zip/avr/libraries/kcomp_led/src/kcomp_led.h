// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      led
// @title       Onboard Red LED (PWM)
// @targets     avr
// @bus         pwm (D5, DIP S1-2)
// @timers      Timer0 (PWM on D5)
// @sram_bytes  0

#ifndef KCOMP_LED_H
#define KCOMP_LED_H

#include <Arduino.h>
#include <stdint.h>

#define LED_PIN 5

void initLed();
void setLed(uint8_t brightness);
void setLedOff();
void fadeLedInBlocking(uint8_t brightness, uint16_t durationMs);
void fadeLedOutBlocking(uint8_t brightness, uint16_t durationMs);

#endif
