// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      gy302
// @title       GY-302 (BH1750) Ambient Light Sensor
// @targets     avr, esp32s3
// @bus         i2c (0x23 default, 0x5C alt)
// @timers      none
// @sram_bytes  ~2

#ifndef KCOMP_GY302_H
#define KCOMP_GY302_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Supported I2C addresses (depends on ADDR pin level)
#define GY302_ADDR_DEFAULT 0x23
#define GY302_ADDR_HIGH    0x5C

// Measurement resolution and speed modes
enum GY302Mode : uint8_t {
    GY302_MODE_NORMAL = 0x10,  // 1.0 lx resolution, ~120 ms conversion
    GY302_MODE_HIGH   = 0x11,  // 0.5 lx resolution, ~120 ms conversion
    GY302_MODE_FAST   = 0x13   // 4.0 lx resolution, ~16 ms conversion
};

// Initialize the GY-302 (BH1750) sensor on the I2C bus.
// Returns true if the sensor acknowledges at the specified address.
bool initGY302(uint8_t address = GY302_ADDR_DEFAULT);

// Read ambient light intensity in Lux (returns -1.0f on I2C read error).
float getGY302Lux();

// Switch the continuous measurement resolution and speed mode.
void setGY302Mode(GY302Mode mode);

#endif
