// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_gy302.h"
#include <Wire.h>

static constexpr uint8_t BH1750_CMD_POWER_ON = 0x01U;
static constexpr uint8_t BH1750_CMD_RESET    = 0x07U;

static uint8_t   gy302Addr = GY302_ADDR_DEFAULT;
static GY302Mode gy302Mode = GY302_MODE_NORMAL;

static bool sendCommand(uint8_t cmd) {
    Wire.beginTransmission(gy302Addr);
    Wire.write(cmd);
    return Wire.endTransmission() == 0;
}

bool initGY302(uint8_t address) {
    gy302Addr = address;
    Wire.begin();

    if (!sendCommand(BH1750_CMD_POWER_ON)) {
        return false;
    }

    sendCommand(BH1750_CMD_RESET);
    setGY302Mode(GY302_MODE_NORMAL);
    return true;
}

float getGY302Lux() {
    if (Wire.requestFrom(gy302Addr, (uint8_t)2U) != 2U) {
        return -1.0f;
    }

    const uint8_t highByte = (uint8_t)Wire.read();
    const uint8_t lowByte  = (uint8_t)Wire.read();
    const uint16_t rawLevel = (uint16_t)(((uint16_t)highByte << 8) | lowByte);

    // Standard BH1750 conversion factor is 1.2 counts per lux
    float lux = (float)rawLevel / 1.2f;
    if (gy302Mode == GY302_MODE_HIGH) {
        lux *= 0.5f;
    }
    return lux;
}

void setGY302Mode(GY302Mode mode) {
    gy302Mode = mode;
    sendCommand((uint8_t)mode);

    // Wait for the first conversion in the selected mode to complete
    if (mode == GY302_MODE_FAST) {
        delay(20);
    } else {
        delay(180);
    }
}
