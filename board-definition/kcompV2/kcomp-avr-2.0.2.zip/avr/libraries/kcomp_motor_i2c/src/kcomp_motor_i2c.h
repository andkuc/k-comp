// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      motor_i2c
// @title       I2C Dual DC Motor Shield (TB6612FNG)
// @targets     avr, esp32s3
// @bus         i2c (0x30 default, 0x2F/0x2E/0x2D alt)
// @timers      none (uses millis())
// @sram_bytes  ~58

#ifndef KCOMP_MOTOR_I2C_H
#define KCOMP_MOTOR_I2C_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Supported I2C addresses (depends on AD0/AD1 jumpers)
#define MOTOR_ADDR_0x2D 0x2DU
#define MOTOR_ADDR_0x2E 0x2EU
#define MOTOR_ADDR_0x2F 0x2FU
#define MOTOR_ADDR_0x30 0x30U

// Motor channel identifiers
enum MotorChannel : uint8_t {
    MOTOR_A = 0U,
    MOTOR_B = 1U,
    MOTOR_C = 2U,
    MOTOR_D = 3U
};

// Initialize primary motor shield (addr1) and optional second shield (addr2).
bool initMotorI2C(uint8_t addr1 = MOTOR_ADDR_0x30, uint8_t addr2 = 0x00U);

// Individual motor speed (-100..+100; 0 = brake), optional duration in ms
void setMotorASpeed(int16_t speed, uint16_t timeMs = 0U);
void setMotorBSpeed(int16_t speed, uint16_t timeMs = 0U);
void setMotorCSpeed(int16_t speed, uint16_t timeMs = 0U);
void setMotorDSpeed(int16_t speed, uint16_t timeMs = 0U);

// Chassis navigation (2WD/4WD skid-steer; optional timeMs > 0 is non-blocking)
void driveMotorForward(int16_t speed, uint16_t timeMs = 0U);
void driveMotorBackward(int16_t speed, uint16_t timeMs = 0U);
void turnMotorLeft(int16_t speed, uint16_t timeMs = 0U);
void turnMotorRight(int16_t speed, uint16_t timeMs = 0U);
void pivotMotorLeft(int16_t speed, uint16_t timeMs = 0U);
void pivotMotorRight(int16_t speed, uint16_t timeMs = 0U);

// Open-loop angle helpers and calibration
void setMotorTurnCalibration(uint16_t msFor90Deg, int16_t refSpeed = 60);
void turnMotorChassisAngle(int16_t degrees, int16_t speed = 60);
void setMotorRPM(uint16_t rpmAtFullSpeed);
void turnMotorShaftAngle(uint8_t motorId, int16_t degrees, int16_t speed = 60);

// Direction inversion, left/right trim (-100..+100), and stop modes
void setMotorInvert(bool invA, bool invB, bool invC = false, bool invD = false);
void setMotorTrim(int8_t trim);
void stopMotors();
void brakeMotors();
void coastMotors();

// Status and non-blocking loop heartbeat
bool isMotorBusy();
int16_t getMotorASpeed();
int16_t getMotorBSpeed();
int16_t getMotorCSpeed();
int16_t getMotorDSpeed();
void updateMotors();

#endif
