// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_motor_i2c.h"
#include <Wire.h>

static constexpr uint8_t CMD_SET_MOTOR  = 0x10U;
static constexpr uint8_t MODE_BRAKE     = 0x00U;
static constexpr uint8_t MODE_CCW       = 0x01U;
static constexpr uint8_t MODE_CW        = 0x02U;
static constexpr uint8_t MODE_COAST     = 0x03U;

static constexpr uint32_t DEFAULT_PWM_FREQ = 1000UL;
static constexpr uint32_t HEARTBEAT_MS     = 2000UL;

static uint8_t  shieldAddr[2]    = { MOTOR_ADDR_0x30, 0x00U };
static int16_t  targetSpeed[4]   = { 0, 0, 0, 0 };
static uint8_t  activeMode[4]    = { MODE_BRAKE, MODE_BRAKE, MODE_BRAKE, MODE_BRAKE };
static bool     motorInvert[4]   = { false, false, false, false };

static bool     timerActive[4]   = { false, false, false, false };
static uint32_t timerStartMs[4]  = { 0UL, 0UL, 0UL, 0UL };
static uint16_t timerDuration[4] = { 0U, 0U, 0U, 0U };

static int8_t   sideTrim        = 0;
static uint16_t turnMsPer90     = 450U;
static int16_t  turnRefSpeed    = 60;
static uint16_t motorFullRpm    = 200U;
static uint32_t lastHeartbeatMs = 0UL;

static int16_t clampSpeed(int16_t speed) {
    if (speed > 100)  return 100;
    if (speed < -100) return -100;
    return speed;
}

static uint16_t abs16(int16_t v) {
    return (v < 0) ? (uint16_t)(-v) : (uint16_t)v;
}

static uint8_t setShieldFreq(uint8_t addr, uint32_t freq) {
    if (addr == 0x00U) {
        return 4U;
    }
    Wire.beginTransmission(addr);
    Wire.write((uint8_t)((freq >> 24) & 0x0FUL));
    Wire.write((uint8_t)((freq >> 16) & 0xFFUL));
    Wire.write((uint8_t)((freq >> 8)  & 0xFFUL));
    Wire.write((uint8_t)(freq & 0xFFUL));
    const uint8_t err = Wire.endTransmission();
    delay(2);
    return err;
}

static void sendMotorPacket(uint8_t motorIdx, uint8_t dir, uint16_t pwmVal) {
    if (motorIdx > 3U) {
        return;
    }
    const uint8_t shieldIdx = (motorIdx < 2U) ? 0U : 1U;
    const uint8_t addr = shieldAddr[shieldIdx];
    if (addr == 0x00U) {
        return;
    }

    const uint8_t channel = (uint8_t)(motorIdx & 0x01U);
    const uint16_t clampedPwm = (pwmVal > 10000U) ? 10000U : pwmVal;

    Wire.beginTransmission(addr);
    Wire.write((uint8_t)(channel | CMD_SET_MOTOR));
    Wire.write(dir);
    Wire.write((uint8_t)(clampedPwm >> 8));
    Wire.write((uint8_t)(clampedPwm & 0xFFU));
    Wire.endTransmission();
    delay(2);
}

static void applyMotor(uint8_t motorIdx, int16_t speed, bool coastIfZero = false) {
    if (motorIdx > 3U) {
        return;
    }
    if (motorIdx >= 2U && shieldAddr[1] == 0x00U) {
        return;
    }

    const int16_t clamped = clampSpeed(speed);
    targetSpeed[motorIdx] = clamped;
    const int16_t hwSpeed = motorInvert[motorIdx] ? (int16_t)(-clamped) : clamped;

    if (hwSpeed > 0) {
        activeMode[motorIdx] = MODE_CW;
        sendMotorPacket(motorIdx, MODE_CW, (uint16_t)hwSpeed * 100U);
    } else if (hwSpeed < 0) {
        activeMode[motorIdx] = MODE_CCW;
        sendMotorPacket(motorIdx, MODE_CCW, (uint16_t)(-hwSpeed) * 100U);
    } else {
        const uint8_t stopMode = coastIfZero ? MODE_COAST : MODE_BRAKE;
        activeMode[motorIdx] = stopMode;
        sendMotorPacket(motorIdx, stopMode, 0U);
    }
}

static void setMotorTimed(uint8_t motorIdx, int16_t speed, uint16_t timeMs) {
    if (motorIdx > 3U) {
        return;
    }
    if (motorIdx >= 2U && shieldAddr[1] == 0x00U) {
        return;
    }

    applyMotor(motorIdx, speed, false);
    if (timeMs > 0U) {
        timerActive[motorIdx] = true;
        timerStartMs[motorIdx] = millis();
        timerDuration[motorIdx] = timeMs;
    } else {
        timerActive[motorIdx] = false;
    }
}

static void setLeftSide(int16_t speed, uint16_t timeMs, bool applyTrim) {
    int16_t s = clampSpeed(speed);
    if (applyTrim && sideTrim < 0) {
        s = (int16_t)(((int32_t)s * (100 + (int32_t)sideTrim)) / 100L);
    }
    setMotorTimed(MOTOR_A, s, timeMs);
    if (shieldAddr[1] != 0x00U) {
        setMotorTimed(MOTOR_C, s, timeMs);
    }
}

static void setRightSide(int16_t speed, uint16_t timeMs, bool applyTrim) {
    int16_t s = clampSpeed(speed);
    if (applyTrim && sideTrim > 0) {
        s = (int16_t)(((int32_t)s * (100 - (int32_t)sideTrim)) / 100L);
    }
    setMotorTimed(MOTOR_B, s, timeMs);
    if (shieldAddr[1] != 0x00U) {
        setMotorTimed(MOTOR_D, s, timeMs);
    }
}

bool initMotorI2C(uint8_t addr1, uint8_t addr2) {
    shieldAddr[0] = addr1;
    shieldAddr[1] = addr2;
    Wire.begin();

#if defined(WIRE_HAS_TIMEOUT)
    Wire.setWireTimeout(25000, true);
#endif

    delay(150);

    if (addr1 == 0x00U || setShieldFreq(addr1, DEFAULT_PWM_FREQ) != 0U) {
        shieldAddr[0] = 0x00U;
        shieldAddr[1] = 0x00U;
        return false;
    }

    if (addr2 != 0x00U && setShieldFreq(addr2, DEFAULT_PWM_FREQ) != 0U) {
        shieldAddr[1] = 0x00U;
        return false;
    }

    delay(50);
    stopMotors();
    lastHeartbeatMs = millis();
    return true;
}

void setMotorASpeed(int16_t speed, uint16_t timeMs) { setMotorTimed(MOTOR_A, speed, timeMs); }
void setMotorBSpeed(int16_t speed, uint16_t timeMs) { setMotorTimed(MOTOR_B, speed, timeMs); }
void setMotorCSpeed(int16_t speed, uint16_t timeMs) { setMotorTimed(MOTOR_C, speed, timeMs); }
void setMotorDSpeed(int16_t speed, uint16_t timeMs) { setMotorTimed(MOTOR_D, speed, timeMs); }

void driveMotorForward(int16_t speed, uint16_t timeMs) {
    const int16_t s = (int16_t)abs16(clampSpeed(speed));
    setLeftSide(s, timeMs, true);
    setRightSide(s, timeMs, true);
}

void driveMotorBackward(int16_t speed, uint16_t timeMs) {
    const int16_t s = (int16_t)(-(int16_t)abs16(clampSpeed(speed)));
    setLeftSide(s, timeMs, true);
    setRightSide(s, timeMs, true);
}

void turnMotorLeft(int16_t speed, uint16_t timeMs) {
    const int16_t s = (int16_t)abs16(clampSpeed(speed));
    setLeftSide(0, timeMs, false);
    setRightSide(s, timeMs, false);
}

void turnMotorRight(int16_t speed, uint16_t timeMs) {
    const int16_t s = (int16_t)abs16(clampSpeed(speed));
    setLeftSide(s, timeMs, false);
    setRightSide(0, timeMs, false);
}

void pivotMotorLeft(int16_t speed, uint16_t timeMs) {
    const int16_t s = (int16_t)abs16(clampSpeed(speed));
    setLeftSide((int16_t)(-s), timeMs, false);
    setRightSide(s, timeMs, false);
}

void pivotMotorRight(int16_t speed, uint16_t timeMs) {
    const int16_t s = (int16_t)abs16(clampSpeed(speed));
    setLeftSide(s, timeMs, false);
    setRightSide((int16_t)(-s), timeMs, false);
}

void setMotorTurnCalibration(uint16_t msFor90Deg, int16_t refSpeed) {
    if (msFor90Deg > 0U) {
        turnMsPer90 = msFor90Deg;
    }
    const int16_t s = (int16_t)abs16(clampSpeed(refSpeed));
    if (s >= 15) {
        turnRefSpeed = s;
    }
}

void turnMotorChassisAngle(int16_t degrees, int16_t speed) {
    if (degrees == 0) {
        stopMotors();
        return;
    }

    int16_t s = (int16_t)abs16(clampSpeed(speed));
    if (s < 15) s = 15;

    const uint32_t absDeg = (degrees < 0) ? (uint32_t)(-degrees) : (uint32_t)degrees;
    uint32_t duration = (absDeg * (uint32_t)turnMsPer90 * (uint32_t)turnRefSpeed) / (90UL * (uint32_t)s);
    if (duration == 0UL)     duration = 1UL;
    if (duration > 65535UL) duration = 65535UL;

    if (degrees > 0) {
        pivotMotorRight(s, (uint16_t)duration);
    } else {
        pivotMotorLeft(s, (uint16_t)duration);
    }
}

void setMotorRPM(uint16_t rpmAtFullSpeed) {
    if (rpmAtFullSpeed > 0U) {
        motorFullRpm = rpmAtFullSpeed;
    }
}

void turnMotorShaftAngle(uint8_t motorId, int16_t degrees, int16_t speed) {
    if (motorId > 3U) {
        return;
    }
    if (degrees == 0) {
        setMotorTimed(motorId, 0, 0U);
        return;
    }

    int16_t s = (int16_t)abs16(clampSpeed(speed));
    if (s < 15) s = 15;

    const uint32_t absDeg = (degrees < 0) ? (uint32_t)(-degrees) : (uint32_t)degrees;
    uint32_t duration = (absDeg * 50000UL) / (3UL * (uint32_t)motorFullRpm * (uint32_t)s);
    if (duration == 0UL)     duration = 1UL;
    if (duration > 65535UL) duration = 65535UL;

    const int16_t dirSpeed = (degrees > 0) ? s : (int16_t)(-s);
    setMotorTimed(motorId, dirSpeed, (uint16_t)duration);
}

void setMotorInvert(bool invA, bool invB, bool invC, bool invD) {
    motorInvert[MOTOR_A] = invA;
    motorInvert[MOTOR_B] = invB;
    motorInvert[MOTOR_C] = invC;
    motorInvert[MOTOR_D] = invD;
}

void setMotorTrim(int8_t trim) {
    if (trim > 100)  trim = 100;
    if (trim < -100) trim = -100;
    sideTrim = trim;
}

void stopMotors() {
    brakeMotors();
}

void brakeMotors() {
    for (uint8_t i = 0U; i < 4U; i++) {
        timerActive[i] = false;
        applyMotor(i, 0, false);
    }
}

void coastMotors() {
    for (uint8_t i = 0U; i < 4U; i++) {
        timerActive[i] = false;
        applyMotor(i, 0, true);
    }
}

bool isMotorBusy() {
    return timerActive[0] || timerActive[1] || timerActive[2] || timerActive[3];
}

int16_t getMotorASpeed() { return targetSpeed[MOTOR_A]; }
int16_t getMotorBSpeed() { return targetSpeed[MOTOR_B]; }
int16_t getMotorCSpeed() { return targetSpeed[MOTOR_C]; }
int16_t getMotorDSpeed() { return targetSpeed[MOTOR_D]; }

void updateMotors() {
    const uint32_t nowMs = millis();

    for (uint8_t i = 0U; i < 4U; i++) {
        if (timerActive[i] && ((nowMs - timerStartMs[i]) >= timerDuration[i])) {
            timerActive[i] = false;
            applyMotor(i, 0, false);
        }
    }

    if ((nowMs - lastHeartbeatMs) >= HEARTBEAT_MS) {
        lastHeartbeatMs = nowMs;
        const uint8_t activeMotors = (shieldAddr[1] != 0x00U) ? 4U : 2U;
        for (uint8_t i = 0U; i < activeMotors; i++) {
            const uint16_t pwm = (uint16_t)(abs16(targetSpeed[i]) * 100U);
            sendMotorPacket(i, activeMode[i], pwm);
        }
    }
}
