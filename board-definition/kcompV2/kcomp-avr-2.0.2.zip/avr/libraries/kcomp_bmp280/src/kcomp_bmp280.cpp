// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_bmp280.h"
#include <Wire.h>
#include <math.h>

// Internal BMP280 register addresses and chip ID
static constexpr uint8_t BMP280_CHIP_ID       = 0x58U;
static constexpr uint8_t BMP280_REG_ID        = 0xD0U;
static constexpr uint8_t BMP280_REG_CTRL_MEAS = 0xF4U;
static constexpr uint8_t BMP280_REG_CONFIG    = 0xF5U;
static constexpr uint8_t BMP280_REG_PRESS_MSB = 0xF7U;
static constexpr uint8_t BMP280_REG_TEMP_MSB  = 0xFAU;

// Module-private active I2C address and factory calibration parameters
static uint8_t  bmp280Addr = BMP280_ADDR_DEFAULT;
static uint16_t dig_T1 = 0U;
static int16_t  dig_T2 = 0, dig_T3 = 0;
static uint16_t dig_P1 = 0U;
static int16_t  dig_P2 = 0, dig_P3 = 0, dig_P4 = 0, dig_P5 = 0;
static int16_t  dig_P6 = 0, dig_P7 = 0, dig_P8 = 0, dig_P9 = 0;
static int32_t  tFine = 0;

static bool writeRegister8(uint8_t reg, uint8_t value) {
    Wire.beginTransmission(bmp280Addr);
    Wire.write(reg);
    Wire.write(value);
    return Wire.endTransmission() == 0;
}

static bool readRegister8(uint8_t reg, uint8_t* outValue) {
    Wire.beginTransmission(bmp280Addr);
    Wire.write(reg);
    if (Wire.endTransmission() != 0) {
        return false;
    }
    if (Wire.requestFrom(bmp280Addr, (uint8_t)1U) != 1U) {
        return false;
    }
    *outValue = (uint8_t)Wire.read();
    return true;
}

// Read a 16-bit little-endian register using sequenced Wire.read() calls
static uint16_t readRegister16LE(uint8_t reg) {
    Wire.beginTransmission(bmp280Addr);
    Wire.write(reg);
    if (Wire.endTransmission() != 0) {
        return 0U;
    }
    if (Wire.requestFrom(bmp280Addr, (uint8_t)2U) != 2U) {
        return 0U;
    }
    const uint8_t lsb = (uint8_t)Wire.read();
    const uint8_t msb = (uint8_t)Wire.read();
    return (uint16_t)(((uint16_t)msb << 8) | lsb);
}

static int16_t readRegisterS16LE(uint8_t reg) {
    return (int16_t)readRegister16LE(reg);
}

static bool readRaw20(uint8_t startReg, int32_t* outRaw) {
    Wire.beginTransmission(bmp280Addr);
    Wire.write(startReg);
    if (Wire.endTransmission() != 0) {
        return false;
    }
    if (Wire.requestFrom(bmp280Addr, (uint8_t)3U) != 3U) {
        return false;
    }
    const int32_t msb  = (int32_t)(uint8_t)Wire.read();
    const int32_t lsb  = (int32_t)(uint8_t)Wire.read();
    const int32_t xlsb = (int32_t)(uint8_t)Wire.read();
    *outRaw = (msb << 12) | (lsb << 4) | (xlsb >> 4);
    return true;
}

static void readCalibrationData() {
    dig_T1 = readRegister16LE(0x88U);
    dig_T2 = readRegisterS16LE(0x8AU);
    dig_T3 = readRegisterS16LE(0x8CU);

    dig_P1 = readRegister16LE(0x8EU);
    dig_P2 = readRegisterS16LE(0x90U);
    dig_P3 = readRegisterS16LE(0x92U);
    dig_P4 = readRegisterS16LE(0x94U);
    dig_P5 = readRegisterS16LE(0x96U);
    dig_P6 = readRegisterS16LE(0x98U);
    dig_P7 = readRegisterS16LE(0x9AU);
    dig_P8 = readRegisterS16LE(0x9CU);
    dig_P9 = readRegisterS16LE(0x9EU);
}

bool initBMP280(uint8_t address) {
    bmp280Addr = address;
    tFine = 0;
    Wire.begin();

    uint8_t chipId = 0U;
    if (!readRegister8(BMP280_REG_ID, &chipId) || chipId != BMP280_CHIP_ID) {
        return false;
    }

    readCalibrationData();

    // Normal mode (11), temperature oversampling x1 (001), pressure oversampling x1 (001)
    if (!writeRegister8(BMP280_REG_CTRL_MEAS, 0x27U)) {
        return false;
    }

    // Standby 0.5 ms (000), IIR filter off (000)
    return writeRegister8(BMP280_REG_CONFIG, 0x00U);
}

float getBMP280Temperature() {
    int32_t adcT = 0;
    if (!readRaw20(BMP280_REG_TEMP_MSB, &adcT)) {
        return NAN;
    }

    // Bosch BMP280 32-bit integer temperature compensation formula
    const int32_t var1 = ((((adcT >> 3) - ((int32_t)dig_T1 << 1))) * ((int32_t)dig_T2)) >> 11;
    const int32_t var2 = (((((adcT >> 4) - ((int32_t)dig_T1)) * ((adcT >> 4) - ((int32_t)dig_T1))) >> 12) * ((int32_t)dig_T3)) >> 14;
    tFine = var1 + var2;

    const int32_t tempC100 = (tFine * 5 + 128) >> 8;
    return (float)tempC100 / 100.0f;
}

float getBMP280Pressure() {
    // Refresh tFine before computing compensated pressure
    if (isnan(getBMP280Temperature())) {
        return NAN;
    }

    int32_t adcP = 0;
    if (!readRaw20(BMP280_REG_PRESS_MSB, &adcP)) {
        return NAN;
    }

    // Bosch BMP280 64-bit integer pressure compensation formula
    int64_t var1 = ((int64_t)tFine) - 128000;
    int64_t var2 = var1 * var1 * (int64_t)dig_P6;
    var2 = var2 + ((var1 * (int64_t)dig_P5) << 17);
    var2 = var2 + (((int64_t)dig_P4) << 35);
    var1 = ((var1 * var1 * (int64_t)dig_P3) >> 8) + ((var1 * (int64_t)dig_P2) << 12);
    var1 = (((((int64_t)1) << 47) + var1)) * ((int64_t)dig_P1) >> 33;

    if (var1 == 0) {
        return 0.0f;
    }

    int64_t p = 1048576 - adcP;
    p = (((p << 31) - var2) * 3125) / var1;
    var1 = (((int64_t)dig_P9) * (p >> 13) * (p >> 13)) >> 25;
    var2 = (((int64_t)dig_P8) * p) >> 19;
    p = ((p + var1 + var2) >> 8) + (((int64_t)dig_P7) << 4);

    return (float)p / 256.0f;
}

float getBMP280Altitude(float seaLevelhPa) {
    if (seaLevelhPa <= 0.0f) {
        return NAN;
    }
    const float pressurePa = getBMP280Pressure();
    if (isnan(pressurePa) || pressurePa <= 0.0f) {
        return NAN;
    }
    const float pressureHpa = pressurePa / 100.0f;
    return 44330.0f * (1.0f - powf(pressureHpa / seaLevelhPa, 0.1903f));
}
