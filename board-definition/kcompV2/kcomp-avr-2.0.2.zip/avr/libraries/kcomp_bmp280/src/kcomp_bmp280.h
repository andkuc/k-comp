// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      bmp280
// @title       BMP280 Temperature & Pressure Sensor
// @targets     avr, esp32s3
// @bus         i2c (0x76 default, 0x77 alt)
// @timers      none
// @sram_bytes  ~30

#ifndef KCOMP_BMP280_H
#define KCOMP_BMP280_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Supported I2C addresses (depends on SDO pin wiring)
#define BMP280_ADDR_DEFAULT 0x76
#define BMP280_ADDR_ALT     0x77

// Initialize the BMP280 sensor, verify its chip ID (0x58), and load calibration data.
// Returns true on success, false if the sensor is missing or reports a different ID.
bool initBMP280(uint8_t address = BMP280_ADDR_DEFAULT);

// Read compensated temperature in degrees Celsius (NAN on I2C read error).
float getBMP280Temperature();

// Read compensated barometric pressure in Pascals (Pa). Divide by 100.0f for hPa.
float getBMP280Pressure();

// Estimate altitude in meters from current pressure and reference sea-level pressure (hPa).
float getBMP280Altitude(float seaLevelhPa = 1013.25f);

#endif
