// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_sps30.h"
#include <Wire.h>

static constexpr uint16_t CMD_START_MEASUREMENT = 0x0010U;
static constexpr uint16_t ARG_START_UINT16      = 0x0500U;
static constexpr uint16_t CMD_READ_DATA_READY   = 0x0202U;
static constexpr uint16_t CMD_READ_VALUES       = 0x0300U;

static uint8_t spsAddr = SPS30_I2C_ADDR;
static SPS30Data latestSpsData = {
    false, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0.0f
};

static uint8_t calcCrc(uint8_t msb, uint8_t lsb) {
    uint8_t crc = 0xFFU;
    const uint8_t pair[2] = {msb, lsb};
    for (uint8_t i = 0U; i < 2U; i++) {
        crc ^= pair[i];
        for (uint8_t bit = 8U; bit > 0U; bit--) {
            if ((crc & 0x80U) != 0U) {
                crc = (uint8_t)((crc << 1) ^ 0x31U);
            } else {
                crc = (uint8_t)(crc << 1);
            }
        }
    }
    return crc;
}

static bool sendCmd(uint16_t cmd) {
    Wire.beginTransmission(spsAddr);
    Wire.write((uint8_t)(cmd >> 8));
    Wire.write((uint8_t)(cmd & 0xFFU));
    return Wire.endTransmission() == 0;
}

static bool sendCmdArg(uint16_t cmd, uint16_t arg) {
    const uint8_t argMsb = (uint8_t)(arg >> 8);
    const uint8_t argLsb = (uint8_t)(arg & 0xFFU);

    Wire.beginTransmission(spsAddr);
    Wire.write((uint8_t)(cmd >> 8));
    Wire.write((uint8_t)(cmd & 0xFFU));
    Wire.write(argMsb);
    Wire.write(argLsb);
    Wire.write(calcCrc(argMsb, argLsb));
    return Wire.endTransmission() == 0;
}

bool initSPS30(uint8_t address) {
    spsAddr = address;
    latestSpsData.isValid = false;
    Wire.begin();

    Wire.beginTransmission(spsAddr);
    if (Wire.endTransmission() != 0) {
        return false;
    }

    if (!sendCmdArg(CMD_START_MEASUREMENT, ARG_START_UINT16)) {
        return false;
    }
    delay(50);
    return true;
}

SPS30Data getSPS30Data() {
    latestSpsData.isValid = false;

    if (!sendCmd(CMD_READ_DATA_READY)) {
        return latestSpsData;
    }
    if (Wire.requestFrom(spsAddr, (uint8_t)3U) != 3U) {
        return latestSpsData;
    }

    (void)Wire.read();
    const uint8_t readyLsb = (uint8_t)Wire.read();
    (void)Wire.read();  // CRC byte

    if (readyLsb == 0x00U) {
        return latestSpsData;
    }

    if (!sendCmd(CMD_READ_VALUES)) {
        return latestSpsData;
    }
    if (Wire.requestFrom(spsAddr, (uint8_t)30U) != 30U) {
        return latestSpsData;
    }

    uint16_t rawVals[10];
    for (uint8_t i = 0U; i < 10U; i++) {
        const uint8_t msb = (uint8_t)Wire.read();
        const uint8_t lsb = (uint8_t)Wire.read();
        (void)Wire.read();  // CRC byte
        rawVals[i] = (uint16_t)(((uint16_t)msb << 8) | lsb);
    }

    latestSpsData.pm1_0 = rawVals[0];
    latestSpsData.pm2_5 = rawVals[1];
    latestSpsData.pm4_0 = rawVals[2];
    latestSpsData.pm10_0 = rawVals[3];
    latestSpsData.nc0_5 = rawVals[4];
    latestSpsData.nc1_0 = rawVals[5];
    latestSpsData.nc2_5 = rawVals[6];
    latestSpsData.nc4_0 = rawVals[7];
    latestSpsData.nc10_0 = rawVals[8];
    latestSpsData.typicalParticleSizeUm = (float)rawVals[9] / 1000.0f;
    latestSpsData.isValid = true;

    return latestSpsData;
}

uint8_t getSPS30AirQualityLevel() {
    if (latestSpsData.pm2_5 <= 12U)  return (uint8_t)SPS30_AQI_GOOD;
    if (latestSpsData.pm2_5 <= 35U)  return (uint8_t)SPS30_AQI_MODERATE;
    if (latestSpsData.pm2_5 <= 55U)  return (uint8_t)SPS30_AQI_UNHEALTHY_SENSITIVE;
    if (latestSpsData.pm2_5 <= 150U) return (uint8_t)SPS30_AQI_UNHEALTHY;
    if (latestSpsData.pm2_5 <= 250U) return (uint8_t)SPS30_AQI_VERY_UNHEALTHY;
    return (uint8_t)SPS30_AQI_HAZARDOUS;
}

uint8_t getSPS30PollutionSource() {
    if (latestSpsData.pm2_5 < 12U || latestSpsData.pm10_0 == 0U) {
        return (uint8_t)SPS30_SOURCE_CLEAN;
    }

    const float ratio = (float)latestSpsData.pm1_0 / (float)latestSpsData.pm10_0;
    if (ratio >= 0.70f) return (uint8_t)SPS30_SOURCE_COMBUSTION;
    if (ratio <= 0.40f) return (uint8_t)SPS30_SOURCE_DUST;
    return (uint8_t)SPS30_SOURCE_MIXED;
}

uint8_t getSPS30AirQualityScore() {
    const int32_t score = 100 - ((int32_t)latestSpsData.pm2_5 * 2);
    if (score < 0)   return 0U;
    if (score > 100) return 100U;
    return (uint8_t)score;
}
