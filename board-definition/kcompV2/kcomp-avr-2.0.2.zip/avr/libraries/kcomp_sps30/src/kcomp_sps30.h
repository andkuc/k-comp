// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      sps30
// @title       SPS30 Particulate Matter Sensor (PM1.0/2.5/4/10)
// @targets     avr, esp32s3
// @bus         i2c (0x69)
// @timers      none
// @sram_bytes  ~34

#ifndef KCOMP_SPS30_H
#define KCOMP_SPS30_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Default I2C address of the SPS30
#define SPS30_I2C_ADDR 0x69U

// Air quality index categories based on PM2.5 (ug/m3)
enum SPS30AirQuality : uint8_t {
    SPS30_AQI_GOOD = 0U,
    SPS30_AQI_MODERATE,
    SPS30_AQI_UNHEALTHY_SENSITIVE,
    SPS30_AQI_UNHEALTHY,
    SPS30_AQI_VERY_UNHEALTHY,
    SPS30_AQI_HAZARDOUS
};

// Heuristic source classification from PM1.0 / PM10 ratio
enum SPS30PollutionSource : uint8_t {
    SPS30_SOURCE_CLEAN = 0U,
    SPS30_SOURCE_COMBUSTION,
    SPS30_SOURCE_DUST,
    SPS30_SOURCE_MIXED
};

// Particulate matter mass (ug/m3), number concentration (#/cm3), and typical size (um)
struct SPS30Data {
    bool isValid;
    uint16_t pm1_0;
    uint16_t pm2_5;
    uint16_t pm4_0;
    uint16_t pm10_0;
    uint16_t nc0_5;
    uint16_t nc1_0;
    uint16_t nc2_5;
    uint16_t nc4_0;
    uint16_t nc10_0;
    float typicalParticleSizeUm;
};

// Start SPS30 measurement in unsigned 16-bit integer output mode.
// Returns true if the sensor acknowledges at the specified I2C address.
bool initSPS30(uint8_t address = SPS30_I2C_ADDR);

// Poll data-ready status and read a fresh measurement frame when available.
SPS30Data getSPS30Data();

// Derived air quality helpers from the most recent valid sample
uint8_t getSPS30AirQualityLevel();
uint8_t getSPS30PollutionSource();
uint8_t getSPS30AirQualityScore();

#endif
