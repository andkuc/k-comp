// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_buzzer.h"

// Internal playback state machine (module-private)
enum BuzzerState : uint8_t {
    BUZZER_IDLE,
    BUZZER_TONE,
    BUZZER_BEEP,
    BUZZER_MELODY
};

static BuzzerState buzzerState = BUZZER_IDLE;

// Non-blocking melody playback pointers and timing state
static const uint16_t* melodyNotes = NULL;
static const uint16_t* melodyDurations = NULL;
static uint8_t melodyLength = 0U;
static uint8_t melodyIndex = 0U;
static bool noteActive = false;

static uint32_t startMs = 0UL;
static uint32_t intervalMs = 0UL;

// Convert musical note divisor (e.g. 4 = quarter note -> 250 ms) safely without division by zero
static uint16_t divisorToDurationMs(uint16_t divisor) {
    if (divisor == 0U) {
        return 0U;
    }
    const uint16_t ms = (uint16_t)(1000U / divisor);
    return (ms == 0U) ? 1U : ms;
}

// Add 30% articulation pause between notes using integer math (1.3x)
static uint32_t computeNoteStepMs(uint16_t noteDurationMs) {
    return ((uint32_t)noteDurationMs * 13UL + 5UL) / 10UL;
}

void initBuzzer() {
    pinMode(BUZZER_PIN, OUTPUT);
    digitalWrite(BUZZER_PIN, LOW);
    stopBuzzer();
}

void stopBuzzer() {
    noTone(BUZZER_PIN);
    digitalWrite(BUZZER_PIN, LOW);
    buzzerState = BUZZER_IDLE;
    melodyNotes = NULL;
    melodyDurations = NULL;
    melodyLength = 0U;
    melodyIndex = 0U;
    noteActive = false;
    intervalMs = 0UL;
}

void playBuzzerTone(uint16_t frequency) {
    if (frequency == NOTE_REST) {
        stopBuzzer();
        return;
    }
    melodyNotes = NULL;
    melodyDurations = NULL;
    noteActive = false;
    buzzerState = BUZZER_TONE;
    tone(BUZZER_PIN, frequency);
}

void playBuzzerBeep(uint16_t frequency, uint16_t durationMs) {
    if (durationMs == 0U || frequency == NOTE_REST) {
        stopBuzzer();
        return;
    }
    melodyNotes = NULL;
    melodyDurations = NULL;
    noteActive = false;
    buzzerState = BUZZER_BEEP;
    startMs = millis();
    intervalMs = durationMs;
    tone(BUZZER_PIN, frequency, durationMs);
}

void playBuzzerBeepBlocking(uint16_t frequency, uint16_t durationMs) {
    stopBuzzer();
    if (durationMs == 0U) {
        return;
    }
    if (frequency != NOTE_REST) {
        tone(BUZZER_PIN, frequency, durationMs);
    }
    delay(durationMs);
    noTone(BUZZER_PIN);
    digitalWrite(BUZZER_PIN, LOW);
}

void playBuzzerMelodyBlocking(const uint16_t* notes, const uint16_t* durations, uint8_t length) {
    stopBuzzer();
    if (notes == NULL || durations == NULL || length == 0U) {
        return;
    }

    for (uint8_t i = 0U; i < length; i++) {
        const uint16_t noteMs = divisorToDurationMs(durations[i]);
        if (noteMs == 0U) {
            continue;
        }
        if (notes[i] != NOTE_REST) {
            tone(BUZZER_PIN, notes[i], noteMs);
        } else {
            noTone(BUZZER_PIN);
        }
        delay(computeNoteStepMs(noteMs));
        noTone(BUZZER_PIN);
    }
    digitalWrite(BUZZER_PIN, LOW);
}

void playBuzzerMelody(const uint16_t* notes, const uint16_t* durations, uint8_t length) {
    stopBuzzer();
    if (notes == NULL || durations == NULL || length == 0U) {
        return;
    }

    melodyNotes = notes;
    melodyDurations = durations;
    melodyLength = length;
    melodyIndex = 0U;
    noteActive = false;
    buzzerState = BUZZER_MELODY;
}

void updateBuzzer() {
    if (buzzerState == BUZZER_BEEP) {
        if ((millis() - startMs) >= intervalMs) {
            noTone(BUZZER_PIN);
            digitalWrite(BUZZER_PIN, LOW);
            buzzerState = BUZZER_IDLE;
        }
        return;
    }

    if (buzzerState != BUZZER_MELODY) {
        return;
    }

    if (melodyIndex >= melodyLength) {
        stopBuzzer();
        return;
    }

    if (!noteActive) {
        const uint16_t noteMs = divisorToDurationMs(melodyDurations[melodyIndex]);
        if (noteMs == 0U) {
            // Skip invalid zero-divisor entries safely
            melodyIndex++;
            if (melodyIndex >= melodyLength) {
                stopBuzzer();
            }
            return;
        }

        if (melodyNotes[melodyIndex] != NOTE_REST) {
            tone(BUZZER_PIN, melodyNotes[melodyIndex], noteMs);
        } else {
            noTone(BUZZER_PIN);
        }
        intervalMs = computeNoteStepMs(noteMs);
        startMs = millis();
        noteActive = true;
    } else if ((millis() - startMs) >= intervalMs) {
        noTone(BUZZER_PIN);
        noteActive = false;
        melodyIndex++;
        if (melodyIndex >= melodyLength) {
            stopBuzzer();
        }
    }
}

bool isBuzzerPlaying() {
    if (buzzerState == BUZZER_BEEP && (millis() - startMs) >= intervalMs) {
        buzzerState = BUZZER_IDLE;
    }
    return buzzerState != BUZZER_IDLE;
}
