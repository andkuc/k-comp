// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_max30102.h"
#include <Wire.h>
#include <math.h>

// MAX30102 register map and part ID
static constexpr uint8_t MAX30102_PART_ID  = 0x15U;
static constexpr uint8_t REG_FIFO_WR_PTR = 0x04U;
static constexpr uint8_t REG_FIFO_RD_PTR = 0x06U;
static constexpr uint8_t REG_FIFO_DATA   = 0x07U;
static constexpr uint8_t REG_FIFO_CONFIG = 0x08U;
static constexpr uint8_t REG_MODE_CONFIG = 0x09U;
static constexpr uint8_t REG_SPO2_CONFIG = 0x0AU;
static constexpr uint8_t REG_LED1_PA     = 0x0CU;
static constexpr uint8_t REG_LED2_PA     = 0x0DU;
static constexpr uint8_t REG_PART_ID     = 0xFFU;

// At 100 Hz output sample rate, each FIFO sample corresponds to 10 ms
static constexpr uint32_t MS_PER_SAMPLE       = 10UL;
static constexpr uint32_t FINGER_IR_THRESHOLD = 50000UL;
static constexpr uint32_t MIN_BEAT_MS         = 300UL;   // 200 BPM upper bound
static constexpr uint32_t MAX_BEAT_MS         = 2000UL;  // 30 BPM lower bound

static uint8_t maxAddr = MAX30102_I2C_ADDR;
static float currentBpm = 0.0f;
static uint8_t currentSpo2 = 0U;

// DC tracking filters for IR and Red channels
static float irDc = 0.0f;
static float redDc = 0.0f;

// Adaptive AC amplitude bounds and beat edge state
static float irAcMax = 20.0f;
static float irAcMin = -20.0f;
static bool beatFallingSeen = false;
static uint32_t samplesSinceLastBeat = 0UL;

// AC power accumulators for RMS ratio (R) SpO2 estimation
static float redAcSqSum = 0.0f;
static float irAcSqSum = 0.0f;
static uint16_t sampleCount = 0U;
static float spo2History[5] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
static uint8_t spo2Index = 0U;

static void resetSignalState() {
    currentBpm = 0.0f;
    currentSpo2 = 0U;
    irDc = 0.0f;
    redDc = 0.0f;
    irAcMax = 20.0f;
    irAcMin = -20.0f;
    beatFallingSeen = false;
    samplesSinceLastBeat = 0UL;
    redAcSqSum = 0.0f;
    irAcSqSum = 0.0f;
    sampleCount = 0U;
    for (uint8_t i = 0U; i < 5U; i++) {
        spo2History[i] = 0.0f;
    }
    spo2Index = 0U;
}

static bool writeReg(uint8_t reg, uint8_t val) {
    Wire.beginTransmission(maxAddr);
    Wire.write(reg);
    Wire.write(val);
    return Wire.endTransmission() == 0;
}

static bool readReg8(uint8_t reg, uint8_t* outVal) {
    Wire.beginTransmission(maxAddr);
    Wire.write(reg);
    if (Wire.endTransmission(false) != 0) {
        return false;
    }
    if (Wire.requestFrom(maxAddr, (uint8_t)1U) != 1U) {
        return false;
    }
    *outVal = (uint8_t)Wire.read();
    return true;
}

// Pop one 6-byte sample (3 bytes Red + 3 bytes IR, 18-bit values) from the FIFO
static bool readNextSample(uint32_t* red, uint32_t* ir) {
    uint8_t rdPtr = 0U;
    uint8_t wrPtr = 0U;
    if (!readReg8(REG_FIFO_RD_PTR, &rdPtr) || !readReg8(REG_FIFO_WR_PTR, &wrPtr)) {
        return false;
    }
    if (rdPtr == wrPtr) {
        return false;
    }

    Wire.beginTransmission(maxAddr);
    Wire.write(REG_FIFO_DATA);
    if (Wire.endTransmission(false) != 0) {
        return false;
    }
    if (Wire.requestFrom(maxAddr, (uint8_t)6U) != 6U) {
        return false;
    }

    uint8_t d[6];
    for (uint8_t i = 0U; i < 6U; i++) {
        d[i] = (uint8_t)Wire.read();
    }

    *red = (((uint32_t)d[0] << 16) | ((uint32_t)d[1] << 8) | (uint32_t)d[2]) & 0x03FFFFUL;
    *ir  = (((uint32_t)d[3] << 16) | ((uint32_t)d[4] << 8) | (uint32_t)d[5]) & 0x03FFFFUL;
    return true;
}

bool initMAX30102(uint8_t address) {
    maxAddr = address;
    resetSignalState();
    Wire.begin();

    uint8_t partId = 0U;
    if (!readReg8(REG_PART_ID, &partId) || partId != MAX30102_PART_ID) {
        return false;
    }

    // Soft reset and allow internal registers to settle
    if (!writeReg(REG_MODE_CONFIG, 0x40U)) {
        return false;
    }
    delay(100);

    // FIFO rollover enabled + 4-sample averaging
    writeReg(REG_FIFO_CONFIG, (uint8_t)(0x10U | 0x02U));
    // SpO2 mode (Red + IR LEDs active)
    writeReg(REG_MODE_CONFIG, 0x03U);
    // 100 Hz sample rate, 411 us pulse width, 4096 nA ADC range
    writeReg(REG_SPO2_CONFIG, 0x27U);

    // Moderate LED current to avoid saturating the photodiode on typical fingertips
    writeReg(REG_LED1_PA, 0x30U);
    writeReg(REG_LED2_PA, 0x30U);

    return true;
}

void resetMAX30102() {
    writeReg(REG_MODE_CONFIG, 0x40U);
    resetSignalState();
}

void updateMAX30102() {
    uint32_t rawRed = 0UL;
    uint32_t rawIr = 0UL;

    // Drain the entire FIFO on each call so loop() delays do not cause beat lag
    while (readNextSample(&rawRed, &rawIr)) {
        samplesSinceLastBeat++;

        if (rawIr < FINGER_IR_THRESHOLD) {
            resetSignalState();
            continue;
        }

        const float irF = (float)rawIr;
        const float redF = (float)rawRed;

        if (irDc <= 0.0f) {
            irDc = irF;
        }
        if (redDc <= 0.0f) {
            redDc = redF;
        }

        // Exponential moving average separates slow DC baseline from pulsatile AC wave
        irDc = (0.95f * irDc) + (0.05f * irF);
        redDc = (0.95f * redDc) + (0.05f * redF);

        const float irAc = irF - irDc;
        const float redAc = redF - redDc;

        redAcSqSum += redAc * redAc;
        irAcSqSum += irAc * irAc;
        sampleCount++;

        irAcMax = (0.98f * irAcMax) + (0.02f * irAc);
        irAcMin = (0.98f * irAcMin) + (0.02f * irAc);

        const float midThreshold = 0.5f * (irAcMax + irAcMin);

        if (irAc < midThreshold && !beatFallingSeen && irAc < -10.0f) {
            beatFallingSeen = true;
        }

        if (irAc > midThreshold && beatFallingSeen) {
            beatFallingSeen = false;

            // Derive beat interval from the sensor's 100 Hz sample clock (1 sample = 10 ms)
            const uint32_t deltaMs = samplesSinceLastBeat * MS_PER_SAMPLE;

            if (deltaMs > MIN_BEAT_MS && deltaMs < MAX_BEAT_MS && sampleCount > 0U) {
                const float instantBpm = 60000.0f / (float)deltaMs;
                if (currentBpm <= 0.0f) {
                    currentBpm = instantBpm;
                } else {
                    currentBpm = (currentBpm * 0.9f) + (instantBpm * 0.1f);
                }

                const float redRms = sqrtf(redAcSqSum / (float)sampleCount);
                const float irRms = sqrtf(irAcSqSum / (float)sampleCount);

                if (irRms > 0.01f && irDc > 0.0f && redDc > 0.0f) {
                    const float ratioR = (redRms / redDc) / (irRms / irDc);
                    float instantSpo2 = (-45.060f * ratioR * ratioR) + (30.354f * ratioR) + 94.845f;
                    if (instantSpo2 > 100.0f) instantSpo2 = 100.0f;
                    if (instantSpo2 < 70.0f)  instantSpo2 = 70.0f;

                    spo2History[spo2Index] = instantSpo2;
                    spo2Index = (uint8_t)((spo2Index + 1U) % 5U);

                    float sumSpo2 = 0.0f;
                    for (uint8_t i = 0U; i < 5U; i++) {
                        sumSpo2 += spo2History[i];
                    }
                    currentSpo2 = (uint8_t)(sumSpo2 / 5.0f);
                }
            }

            redAcSqSum = 0.0f;
            irAcSqSum = 0.0f;
            sampleCount = 0U;
            samplesSinceLastBeat = 0UL;
        }
    }
}

uint16_t getMAX30102HeartRate() {
    if (currentBpm <= 0.0f) {
        return 0U;
    }
    return (uint16_t)(currentBpm + 0.5f);
}

uint8_t getMAX30102SpO2() {
    return currentSpo2;
}
