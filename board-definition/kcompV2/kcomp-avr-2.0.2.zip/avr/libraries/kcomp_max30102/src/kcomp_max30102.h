// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      max30102
// @title       MAX30102 Heart Rate & SpO2 Sensor
// @targets     avr, esp32s3
// @bus         i2c (0x57)
// @timers      none (uses 100 Hz FIFO sample counting)
// @sram_bytes  ~84

#ifndef KCOMP_MAX30102_H
#define KCOMP_MAX30102_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Default I2C address of the MAX30102
#define MAX30102_I2C_ADDR 0x57U

// Initialize the MAX30102 at 100 Hz SpO2 mode (4x FIFO averaging).
// Returns true if part ID 0x15 is detected and configured.
bool initMAX30102(uint8_t address = MAX30102_I2C_ADDR);

// Drain all available FIFO samples and update heart rate (BPM) and SpO2 (%).
// Call as frequently as possible in loop() without blocking delays.
void updateMAX30102();

// Return the smoothed heart rate in beats per minute (0 when no finger is detected).
uint16_t getMAX30102HeartRate();

// Return the smoothed blood oxygen saturation percentage (0..100, or 0 if unavailable).
uint8_t getMAX30102SpO2();

// Reset the MAX30102 chip and clear all filter and beat state.
void resetMAX30102();

#endif
