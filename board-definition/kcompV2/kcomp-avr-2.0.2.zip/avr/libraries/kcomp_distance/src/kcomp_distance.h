// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      distance
// @title       Ultrasonic Distance Sensor (HC-SR04)
// @targets     avr
// @bus         digital (TRIG D11, ECHO D10)
// @timers      none (uses pulseIn with 25 ms timeout)
// @sram_bytes  0

#ifndef KCOMP_DISTANCE_H
#define KCOMP_DISTANCE_H

#include <Arduino.h>
#include <stdint.h>

#define DISTANCE_TRIG_PIN 11
#define DISTANCE_ECHO_PIN 10

void initDistanceSensor();
int16_t getDistanceMM();

#endif
