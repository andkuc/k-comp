// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_distance.h"

// 25 ms timeout covers ~4.25 m round-trip without stalling the MCU for 1 second
static constexpr uint32_t DISTANCE_TIMEOUT_US = 25000UL;

void initDistanceSensor() {
    pinMode(DISTANCE_TRIG_PIN, OUTPUT);
    pinMode(DISTANCE_ECHO_PIN, INPUT);
    digitalWrite(DISTANCE_TRIG_PIN, LOW);
}

int16_t getDistanceMM() {
    digitalWrite(DISTANCE_TRIG_PIN, LOW);
    delayMicroseconds(2);
    digitalWrite(DISTANCE_TRIG_PIN, HIGH);
    delayMicroseconds(10);
    digitalWrite(DISTANCE_TRIG_PIN, LOW);

    const uint32_t durationUs = pulseIn(DISTANCE_ECHO_PIN, HIGH, DISTANCE_TIMEOUT_US);
    if (durationUs == 0UL) {
        return -1;
    }

    // Speed of sound ~343 m/s -> 0.343 mm/us round-trip -> /2 = 0.1715 mm/us
    const uint32_t distanceMm = (durationUs * 343UL + 1000UL) / 2000UL;
    return (distanceMm > 32767UL) ? -1 : (int16_t)distanceMm;
}
