/*
  Program Title: Simple SG90 Servo Demo (Zero Servo.h Dependency)
  Author: Andreas Kucher
  License: MIT

  Demonstrates positional (180-deg) servo control using the built-in AVR Timer1
  or ESP32-S3 LEDC servo engine.
*/

#include <kcomp_servo_sg90.h>

static constexpr uint8_t SERVO0_ID  = 0U;
static constexpr uint8_t SERVO0_PIN = 6U;

void setup() {
  Serial.begin(115200);
  initServo(SERVO0_ID, SERVO0_PIN, SERVO_TYPE_180);
  Serial.println(F("SG90 servo initialized."));
}

void loop() {
  setServoAngle(SERVO0_ID, 0U);
  delay(1000);
  setServoAngle(SERVO0_ID, 90U);
  delay(1000);
  setServoAngle(SERVO0_ID, 180U);
  delay(1000);
}
