/*
  Program Title: Simple I2C Dual DC Motor Shield Demo
  Author: Andreas Kucher
  License: MIT

  Controls a TB6612FNG I2C motor shield at address 0x30 via single-key Serial
  commands at 115200 baud. Call updateMotors() continuously in loop().
*/

#include <kcomp_motor_i2c.h>

bool wasBusy = false;

void setup() {
  Serial.begin(115200);
  delay(200);

  if (!initMotorI2C(MOTOR_ADDR_0x30)) {
    Serial.println(F("Error: Motor shield not found at 0x30!"));
    while (1) {}
  }

  setMotorRPM(200U);
  setMotorTurnCalibration(450U, 60);
  Serial.println(F("Motor shield ready. Keys: [f] Fwd 2s, [b] Back 2s, [r] +90 deg, [s] Stop"));
}

void loop() {
  updateMotors();

  const bool busyNow = isMotorBusy();
  if (wasBusy && !busyNow) {
    Serial.println(F("Motion finished."));
  }
  wasBusy = busyNow;

  if (Serial.available() > 0) {
    const char cmd = (char)Serial.read();
    if (cmd == 'f' || cmd == 'F') {
      driveMotorForward(60, 2000U);
    } else if (cmd == 'b' || cmd == 'B') {
      driveMotorBackward(60, 2000U);
    } else if (cmd == 'r' || cmd == 'R') {
      turnMotorChassisAngle(90, 60);
    } else if (cmd == 's' || cmd == 'S') {
      stopMotors();
    }
  }
}
