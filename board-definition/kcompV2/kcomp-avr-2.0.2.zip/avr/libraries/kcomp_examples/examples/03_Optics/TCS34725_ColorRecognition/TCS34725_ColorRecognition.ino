/*
  Program Title: Simple TCS34725 RGB & HSV Color Sensor Demo
  Author: Andreas Kucher
  License: MIT

  Reads RGBC values, HSV, and classified color names from a TCS34725 sensor
  over I2C (address 0x29) at 115200 baud.
*/

#include <kcomp_tcs34725.h>

uint32_t lastPrintMs = 0UL;

void setup() {
  Serial.begin(115200);

  if (!initColorSensor()) {
    Serial.println(F("Error: TCS34725 not found! Check I2C wiring."));
    while (1) {}
  }

  setColorIntegrationTime(COLOR_TIME_101MS);
  calibrateColorEngine(250U, 10000U);
  Serial.println(F("TCS34725 color sensor initialized."));
}

void loop() {
  updateColorSensor();

  if ((millis() - lastPrintMs) >= 1000UL) {
    lastPrintMs = millis();
    uint8_t code = estimateColor();
    Serial.print(F("RGB: "));
    Serial.print(getColorRed());
    Serial.print(F(", "));
    Serial.print(getColorGreen());
    Serial.print(F(", "));
    Serial.print(getColorBlue());
    Serial.print(F(" | Hue: "));
    Serial.print(getColorHue());
    Serial.print(F(" | Color: "));
    Serial.println(getColorName(code));
  }
}
