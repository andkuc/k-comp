/*
  Program Title: Simple AS7331 UV-A/B/C Sensor Demo
  Author: Andreas Kucher
  License: MIT

  Reads calibrated UV-A, UV-B, and UV-C irradiance (uW/cm2) and raw UV-A counts
  over I2C (address 0x74) at 115200 baud.
*/

#include <kcomp_as7331.h>

void setup() {
  Serial.begin(115200);
  delay(500);

  Serial.println(F("AS7331 UV Sensor Test"));
  if (!initAS7331()) {
    Serial.println(F("Error: AS7331 not found! Check I2C wiring."));
    while (1) {}
  }

  // Higher gain improves sensitivity indoors; lower gain avoids saturation in sunlight
  setAS7331Gain(AS7331_GAIN_256X);
  Serial.println(F("AS7331 initialized."));
}

void loop() {
  float uva = getAS7331_UVA();
  float uvb = getAS7331_UVB();
  float uvc = getAS7331_UVC();

  Serial.print(F("UVA: "));
  Serial.print(uva, 2);
  Serial.print(F(" uW/cm2 | UVB: "));
  Serial.print(uvb, 2);
  Serial.print(F(" uW/cm2 | UVC: "));
  Serial.print(uvc, 2);
  Serial.print(F(" uW/cm2 | Raw UVA: "));
  Serial.println(getAS7331RawUVA());

  delay(1000);
}
