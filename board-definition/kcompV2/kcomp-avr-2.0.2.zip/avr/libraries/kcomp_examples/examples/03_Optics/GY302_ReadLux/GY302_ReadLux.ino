/*
  Program Title: Simple GY-302 (BH1750) Light Sensor Demo
  Author: Andreas Kucher
  License: MIT

  Reads ambient light intensity in Lux over I2C (default address 0x23).
*/

#include <kcomp_gy302.h>

void setup() {
  Serial.begin(115200);
  Serial.println(F("GY-302 (BH1750) Light Sensor Test"));

  if (!initGY302()) {
    Serial.println(F("Error: GY-302 not found! Check I2C wiring."));
    while (1) {}
  }

  setGY302Mode(GY302_MODE_NORMAL);
  Serial.println(F("GY-302 initialized."));
}

void loop() {
  float lux = getGY302Lux();

  if (lux >= 0.0f) {
    Serial.print(F("Light Level: "));
    Serial.print(lux, 1);
    Serial.println(F(" lx"));
  } else {
    Serial.println(F("Error reading sensor."));
  }

  delay(500);
}
