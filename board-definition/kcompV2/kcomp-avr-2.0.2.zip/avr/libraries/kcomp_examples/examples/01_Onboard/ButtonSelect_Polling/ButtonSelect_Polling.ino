/*
  Program Title: Simple Select Button Polling
  Author: Andreas Kucher
  License: MIT

  Demonstrates initializing the K-Comp V2 onboard SELECT button (D4, DIP S1-5)
  and reading its live state directly without callbacks.
*/

#include <kcomp_button_select.h>

void setup() {
  Serial.begin(115200);
  initButtonSelect();
  Serial.println(F("Select button initialized."));
}

void loop() {
  // Read the raw digital button state (true while held down)
  if (isButtonSelectPressed()) {
    Serial.println(F("Select button is pressed!"));
  }

  delay(200);
}
