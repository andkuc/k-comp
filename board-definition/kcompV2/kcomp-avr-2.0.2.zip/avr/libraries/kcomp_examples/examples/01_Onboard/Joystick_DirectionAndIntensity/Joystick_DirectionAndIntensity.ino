/*
  Program Title: Simple Joystick Demo (KY-023)
  Author: Andreas Kucher
  License: MIT

  Continuously reads raw/centered X and Y axes, direction, and intensity
  from the K-Comp V2 onboard analog joystick (X A2, Y A1).
*/

#include <kcomp_joystick.h>

const char* directionNames[] = {
  "CENTER",
  "LEFT",
  "RIGHT",
  "UP",
  "DOWN",
  "UP_LEFT",
  "UP_RIGHT",
  "DOWN_LEFT",
  "DOWN_RIGHT"
};

void setup() {
  Serial.begin(115200);
  initJoystick();
  Serial.println(F("Joystick initialized."));
}

void loop() {
  Serial.print(F("Raw X: "));
  Serial.print(getJoystickXRaw());
  Serial.print(F(" | Centered X: "));
  Serial.print(getJoystickXValue());

  Serial.print(F(" | Raw Y: "));
  Serial.print(getJoystickYRaw());
  Serial.print(F(" | Centered Y: "));
  Serial.print(getJoystickYValue());

  JoystickState state = getJoystickState();
  Serial.print(F(" || Direction: "));
  Serial.print(directionNames[state.direction]);
  Serial.print(F(" | Intensity: "));
  Serial.print(state.intensity);
  Serial.println(F("%"));

  delay(250);
}
