/*
  Program Title: Simple Distance Measurement (HC-SR04)
  Author: Andreas Kucher
  License: MIT

  Reads the distance in millimeters from the K-Comp V2 ultrasonic slot
  (TRIG D11, ECHO D10). Prints an error notice when no echo is detected (-1).
*/

#include <kcomp_distance.h>

void setup() {
  Serial.begin(115200);
  initDistanceSensor();
  Serial.println(F("Distance sensor initialized."));
}

void loop() {
  int16_t distance = getDistanceMM();

  if (distance < 0) {
    Serial.println(F("Out of range / no echo."));
  } else {
    Serial.print(F("Distance: "));
    Serial.print(distance);
    Serial.println(F(" mm"));
  }

  delay(250);
}
