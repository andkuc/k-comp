/*
  Program Title: Simple 3x3 Grid Engine Demo
  Author: Andreas Kucher
  License: MIT

  Demonstrates bit-packed 2D grid memory (kcomp_oled_grid.h) combined with
  low-RAM paged OLED rendering (kcomp_oled_paged.h) and joystick navigation.
*/

#include <kcomp_oled_paged.h>
#include <kcomp_oled_grid.h>
#include <kcomp_joystick.h>

// Allocate static memory for a 3x3 grid (5 bytes total)
uint8_t gameMemory[GRID_MEM_SIZE(3, 3)] = {0};

// Custom renderer for cell states: 1 = 'X', 2 = 'O'
void drawPieces(int16_t anchorX, int16_t anchorY, int16_t w, int16_t h, uint8_t state) {
  if (state == 1) {
    drawLine(anchorX + 3, anchorY + 3, anchorX + w - 3, anchorY + h - 3, OLED_COLOR_WHITE);
    drawLine(anchorX + w - 3, anchorY + 3, anchorX + 3, anchorY + h - 3, OLED_COLOR_WHITE);
  } else if (state == 2) {
    drawCircle(anchorX + (w / 2), anchorY + (h / 2), (w / 2) - 4, OLED_COLOR_WHITE);
  }
}

// Custom renderer for the active selection cursor
void drawMyCursor(int16_t anchorX, int16_t anchorY, int16_t w, int16_t h) {
  drawRect(anchorX + 1, anchorY + 1, w - 2, h - 2, OLED_COLOR_INVERT);
}

void setup() {
  initDisplay();
  initJoystick();

  // Initialize a centered 3x3 grid (20x20 px cells)
  initGrid(3, 3, 20, 20, 34, 2, gameMemory);
  attachGridRender(drawPieces);
  attachGridCursorRender(drawMyCursor);
  setGridCursorEnabled(true);

  // Place sample pieces: 'X' at (0, 0) and 'O' at (1, 1)
  setGridCell(0, 0, 1);
  setGridCell(1, 1, 2);
}

void loop() {
  // Move cursor based on analog joystick deflection
  int16_t joyX = getJoystickXValue();
  int16_t joyY = getJoystickYValue();

  if (joyX > 250)  moveGridCursor(0, 1);   // Right
  if (joyX < -250) moveGridCursor(0, -1);  // Left
  if (joyY > 250)  moveGridCursor(-1, 0);  // Up
  if (joyY < -250) moveGridCursor(1, 0);   // Down

  // Render the grid in 8 low-RAM horizontal bands
  firstPage();
  do {
    renderGrid();
  } while (nextPage());
}
