/*
  Program Title: Select Button Event Callbacks
  Author: Andreas Kucher
  License: MIT

  Demonstrates non-blocking gesture detection on the K-Comp V2 SELECT button
  (D4, DIP S1-5): single click, double click, long press, and long-press release.
*/

#include <kcomp_button_select.h>

// Called once a single click completes without a follow-up press
void onButtonSelectClick() {
  Serial.println(F("Select button clicked"));
}

// Called when two clicks occur within BUTTON_CLICK_MS
void onButtonSelectDoubleClick() {
  Serial.println(F("Select button double-clicked"));
}

// Called as soon as the button has been held for BUTTON_LONG_PRESS_MS
void onButtonSelectLongPress() {
  Serial.println(F("Select button long press started"));
}

// Called when a long press is released
void onButtonSelectLongRelease() {
  Serial.println(F("Select button long press released"));
}

void setup() {
  Serial.begin(115200);
  initButtonSelect();
  Serial.println(F("Select button initialized."));

  // Attach callback functions to each supported gesture event
  attachButtonSelectClick(onButtonSelectClick);
  attachButtonSelectDoubleClick(onButtonSelectDoubleClick);
  attachButtonSelectLongPressed(onButtonSelectLongPress);
  attachButtonSelectLongReleased(onButtonSelectLongRelease);
}

void loop() {
  // Must be called frequently so debounce and gesture timers stay accurate
  updateButtonSelect();
}
