/*
  Program Title: K-Comp OLED Diagnostic (Paged Low-RAM Mode)
  Author: Andreas Kucher
  License: MIT

  Verifies the 8-page rendering loop (firstPage/nextPage), proving that text
  and geometry render seamlessly across 8-pixel band boundaries while saving
  896 bytes of SRAM compared to full-buffer mode.
*/

#include <kcomp_oled_paged.h>

// State variables must be updated outside the firstPage()/nextPage() loop
uint8_t currentTestPhase = 0;
uint32_t lastPhaseChangeMs = 0;
const uint32_t PHASE_DURATION_MS = 3000;
int16_t movingX = 0;

void setup() {
  Serial.begin(115200);
  Serial.println(F("Booting Paged Display Diagnostic..."));

  if (!initDisplay()) {
    Serial.println(F("FATAL: OLED hardware not responding."));
    while (1) {}
  }
}

void loop() {
  // 1. Update logic once per frame
  if ((millis() - lastPhaseChangeMs) >= PHASE_DURATION_MS) {
    currentTestPhase = (currentTestPhase + 1) % 4;
    invertDisplay(false);
    dimDisplay(false);
    lastPhaseChangeMs = millis();
  }

  movingX = (movingX + 1) % 128;

  // 2. Render all 8 horizontal bands
  firstPage();
  do {
    switch (currentTestPhase) {
      case 0:
        setCursor(OLED_ALIGN_CENTER_X(12, 1), 10);
        printText("PAGED SYSTEM", OLED_COLOR_WHITE, OLED_TEXT_NORMAL);

        setCursor(OLED_ALIGN_CENTER_X(10, 2), 30);
        printText("DIAGNOSTIC", OLED_COLOR_WHITE, OLED_TEXT_LARGE);

        drawPixel(movingX, 55, OLED_COLOR_WHITE);
        break;

      case 1:
        setCursor(0, 0);
        printText("PAGE BOUNDARY", OLED_COLOR_WHITE, OLED_TEXT_NORMAL);
        drawLine(0, 15, 127, 15, OLED_COLOR_WHITE);
        drawRect(5, 25, 20, 20, OLED_COLOR_WHITE);
        fillRect(35, 25, 20, 20, OLED_COLOR_WHITE);
        drawCircle(80, 35, 10, OLED_COLOR_WHITE);
        fillTriangle(105, 45, 115, 25, 125, 45, OLED_COLOR_WHITE);
        break;

      case 2:
        setCursor(0, 0);
        printText("FAST LINES", OLED_COLOR_WHITE, OLED_TEXT_NORMAL);
        for (int16_t i = 0; i < 128; i += 8) {
          drawFastVLine(i, 15, 49, OLED_COLOR_WHITE);
        }
        for (int16_t i = 15; i < 64; i += 8) {
          drawFastHLine(0, i, 128, OLED_COLOR_WHITE);
        }
        break;

      case 3:
        setCursor(OLED_ALIGN_CENTER_X(11, 1), OLED_ALIGN_CENTER_Y(1));
        if ((millis() % 1000) < 500) {
          invertDisplay(true);
          printText("INVERT TEST", OLED_COLOR_WHITE, OLED_TEXT_NORMAL);
        } else {
          invertDisplay(false);
          dimDisplay(true);
          printText("DIM TEST", OLED_COLOR_WHITE, OLED_TEXT_NORMAL);
        }
        break;
    }
  } while (nextPage());
}
