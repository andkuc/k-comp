/*
  Program Title: K-Comp OLED Diagnostic (Full Framebuffer)
  Author: Andreas Kucher
  License: MIT

  Verifies SSD1306 initialization, text rendering, geometry primitives,
  layout macros, and hardware invert/dim commands using kcomp_oled.h.
*/

#include <kcomp_oled.h>

uint8_t currentTestPhase = 0;
uint32_t lastPhaseChangeMs = 0;
const uint32_t PHASE_DURATION_MS = 3000;

void setup() {
  Serial.begin(115200);
  Serial.println(F("Booting Standard Display Diagnostic..."));

  if (!initDisplay()) {
    Serial.println(F("FATAL: OLED hardware not responding."));
    while (1) {}
  }
}

void loop() {
  // 1. Update test phase state machine
  if ((millis() - lastPhaseChangeMs) >= PHASE_DURATION_MS) {
    currentTestPhase = (currentTestPhase + 1) % 4;
    invertDisplay(false);
    dimDisplay(false);
    lastPhaseChangeMs = millis();
  }

  // 2. Render current test frame into the 1024-byte shadow buffer
  clearDisplay();

  switch (currentTestPhase) {
    case 0:
      setCursor(OLED_ALIGN_CENTER_X(12, 1), 10);
      printText("K-COMP BOARD", OLED_COLOR_WHITE, OLED_TEXT_NORMAL);

      setCursor(OLED_ALIGN_CENTER_X(10, 2), 30);
      printText("DIAGNOSTIC", OLED_COLOR_WHITE, OLED_TEXT_LARGE);
      break;

    case 1:
      setCursor(0, 0);
      printText("GEOMETRY", OLED_COLOR_WHITE, OLED_TEXT_NORMAL);
      drawLine(0, 15, 127, 15, OLED_COLOR_WHITE);
      drawRect(5, 25, 20, 20, OLED_COLOR_WHITE);
      fillRect(35, 25, 20, 20, OLED_COLOR_WHITE);
      drawCircle(80, 35, 10, OLED_COLOR_WHITE);
      fillTriangle(105, 45, 115, 25, 125, 45, OLED_COLOR_WHITE);
      break;

    case 2:
      setCursor(0, 0);
      printText("FAST LINES", OLED_COLOR_WHITE, OLED_TEXT_NORMAL);
      for (int16_t i = 0; i < 128; i += 8) {
        drawFastVLine(i, 15, 49, OLED_COLOR_WHITE);
      }
      for (int16_t i = 15; i < 64; i += 8) {
        drawFastHLine(0, i, 128, OLED_COLOR_WHITE);
      }
      break;

    case 3:
      setCursor(OLED_ALIGN_CENTER_X(11, 1), OLED_ALIGN_CENTER_Y(1));
      if ((millis() % 1000) < 500) {
        invertDisplay(true);
        printText("INVERT TEST", OLED_COLOR_WHITE, OLED_TEXT_NORMAL);
      } else {
        invertDisplay(false);
        dimDisplay(true);
        printText("DIM TEST", OLED_COLOR_WHITE, OLED_TEXT_NORMAL);
      }
      break;
  }

  updateDisplay();
  delay(20);
}
