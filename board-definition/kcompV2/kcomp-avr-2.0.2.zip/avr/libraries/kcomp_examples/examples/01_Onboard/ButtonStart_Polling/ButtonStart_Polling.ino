/*
  Program Title: Simple Start Button Polling
  Author: Andreas Kucher
  License: MIT

  Demonstrates initializing the K-Comp V2 onboard START button (D3, DIP S1-4)
  and reading its live state directly without callbacks.
*/

#include <kcomp_button_start.h>

void setup() {
  Serial.begin(115200);
  initButtonStart();
  Serial.println(F("Start button initialized."));
}

void loop() {
  // Read the raw digital button state (true while held down)
  if (isButtonStartPressed()) {
    Serial.println(F("Start button is pressed!"));
  }

  delay(200);
}
