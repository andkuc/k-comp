/*
  Program Title: Simple Potentiometer
  Author: Andreas Kucher
  License: MIT

  Reads raw (0-1023) and scaled (0-100%) values from the K-Comp V2
  onboard potentiometer (A0, DIP S1-3).
*/

#include <kcomp_potentiometer.h>

void setup() {
  Serial.begin(115200);
  initPotentiometer();
  Serial.println(F("Potentiometer initialized."));
}

void loop() {
  uint16_t raw = getPotentiometerRaw();
  uint8_t percent = getPotentiometerValue();

  Serial.print(F("Raw: "));
  Serial.print(raw);
  Serial.print(F(" | Value: "));
  Serial.print(percent);
  Serial.println(F("%"));

  delay(250);
}
