/*
  Program Title: Simple LED Control (with Fading)
  Author: Andreas Kucher
  License: MIT

  Demonstrates initializing the K-Comp V2 onboard red LED (D5, DIP S1-2),
  setting brightness levels (0-100%), and running blocking fade animations.
*/

#include <kcomp_led.h>

void setup() {
  Serial.begin(115200);
  initLed();
  Serial.println(F("LED initialized."));

  setLed(50);
  Serial.println(F("LED at 50% for 1s."));
  delay(1000);

  setLed(100);
  Serial.println(F("LED at 100% for 1s."));
  delay(1000);

  setLedOff();
  Serial.println(F("LED switched off."));
  delay(1000);
}

void loop() {
  Serial.println(F("Fading in 0% -> 100% in 1s (blocking)."));
  fadeLedInBlocking(100, 1000);

  Serial.println(F("Fading out 100% -> 0% in 1s (blocking)."));
  fadeLedOutBlocking(100, 1000);
}
