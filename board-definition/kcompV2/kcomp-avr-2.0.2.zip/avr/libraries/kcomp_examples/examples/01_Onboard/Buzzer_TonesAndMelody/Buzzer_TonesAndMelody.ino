/*
  Program Title: Simple Buzzer Demo
  Author: Andreas Kucher
  License: MIT

  Demonstrates continuous tones, timed beeps, and blocking vs. non-blocking
  melodies on the K-Comp V2 onboard passive buzzer (D9, DIP S1-6).
*/

#include <kcomp_buzzer.h>

// Keep melody arrays global or static so non-blocking playback always reads valid memory
const uint16_t MELODY_NOTES[] = {
  NOTE_C4, NOTE_G3, NOTE_G3, NOTE_A3, NOTE_G3, NOTE_REST, NOTE_B3, NOTE_C4
};

// Note duration divisors: 4 = quarter note (250 ms), 8 = eighth note (125 ms)
const uint16_t MELODY_DURATIONS[] = {
  4, 8, 8, 4, 4, 4, 4, 4
};

const uint8_t MELODY_LENGTH = sizeof(MELODY_NOTES) / sizeof(MELODY_NOTES[0]);

void setup() {
  Serial.begin(115200);
  initBuzzer();
  Serial.println(F("Buzzer initialized."));

  // 1. Continuous tone stopped manually
  Serial.println(F("Continuous 175 Hz (F3) tone for 1s..."));
  playBuzzerTone(NOTE_F3);
  delay(1000);
  stopBuzzer();
  delay(500);

  // 2. Blocking timed beep
  Serial.println(F("Blocking beep at 392 Hz (G4) for 500 ms..."));
  playBuzzerBeepBlocking(NOTE_G4, 500);
  delay(500);

  // 3. Non-blocking timed beep (returns immediately)
  Serial.println(F("Non-blocking beep at 523 Hz (C5) for 500 ms..."));
  playBuzzerBeep(NOTE_C5, 500);
  delay(700);

  // 4. Blocking melody
  Serial.println(F("Playing melody (blocking)..."));
  playBuzzerMelodyBlocking(MELODY_NOTES, MELODY_DURATIONS, MELODY_LENGTH);
  delay(1000);

  // 5. Non-blocking melody (driven by updateBuzzer() in loop())
  Serial.println(F("Playing melody (non-blocking)..."));
  playBuzzerMelody(MELODY_NOTES, MELODY_DURATIONS, MELODY_LENGTH);
}

void loop() {
  // Advance non-blocking melody playback without blocking other code
  updateBuzzer();
}
