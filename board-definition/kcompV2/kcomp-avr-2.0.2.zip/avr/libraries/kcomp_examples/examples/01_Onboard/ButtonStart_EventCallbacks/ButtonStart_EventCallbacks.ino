/*
  Program Title: Start Button Event Callbacks
  Author: Andreas Kucher
  License: MIT

  Demonstrates non-blocking gesture detection on the K-Comp V2 START button
  (D3, DIP S1-4): single click, double click, long press, and long-press release.
*/

#include <kcomp_button_start.h>

// Called once a single click completes without a follow-up press
void onButtonStartClick() {
  Serial.println(F("Start button clicked"));
}

// Called when two clicks occur within BUTTON_CLICK_MS
void onButtonStartDoubleClick() {
  Serial.println(F("Start button double-clicked"));
}

// Called as soon as the button has been held for BUTTON_LONG_PRESS_MS
void onButtonStartLongPress() {
  Serial.println(F("Start button long press started"));
}

// Called when a long press is released
void onButtonStartLongRelease() {
  Serial.println(F("Start button long press released"));
}

void setup() {
  Serial.begin(115200);
  initButtonStart();
  Serial.println(F("Start button initialized."));

  // Attach callback functions to each supported gesture event
  attachButtonStartClick(onButtonStartClick);
  attachButtonStartDoubleClick(onButtonStartDoubleClick);
  attachButtonStartLongPressed(onButtonStartLongPress);
  attachButtonStartLongReleased(onButtonStartLongRelease);
}

void loop() {
  // Must be called frequently so debounce and gesture timers stay accurate
  updateButtonStart();
}
