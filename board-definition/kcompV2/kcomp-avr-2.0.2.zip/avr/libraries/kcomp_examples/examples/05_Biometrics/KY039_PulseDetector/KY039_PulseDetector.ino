/*
  Program Title: Simple KY-039 Pulse Sensor Demo
  Author: Andreas Kucher
  License: MIT

  Polls the KY-039 analog pulse detector without blocking delays and prints
  heart rate (BPM) and inter-beat interval delta when a beat is detected.
*/

#include <kcomp_ky039.h>

static constexpr uint8_t PULSE_PIN = A3;

void setup() {
  Serial.begin(115200);
  initKY039(PULSE_PIN);
  Serial.println(F("KY-039 pulse sensor initialized. Place finger lightly on sensor."));
}

void loop() {
  const KY039Data pulse = updateKY039();
  if (pulse.beatDetected) {
    Serial.print(F("Beat | BPM: "));
    Serial.print(pulse.bpm);
    Serial.print(F(" | Delta: "));
    Serial.print(pulse.intervalDiffMs);
    Serial.println(F(" ms"));
  }
}
