/*
  Program Title: Simple AS608 Fingerprint Sensor Demo
  Author: Andreas Kucher
  License: MIT

  Scans fingerprints over UART (SoftwareSerial on AVR, Serial1 on ESP32-S3)
  at 57600 baud and prints matched IDs to Serial Monitor at 115200 baud.
*/

#include <kcomp_as608.h>

static constexpr uint8_t FP_RX_PIN = 6U;
static constexpr uint8_t FP_TX_PIN = 7U;

void setup() {
  Serial.begin(115200);

  if (!initAS608(FP_RX_PIN, FP_TX_PIN, 57600UL)) {
    Serial.println(F("Error: AS608 not found! Check UART wiring."));
    while (1) {}
  }

  Serial.print(F("AS608 ready. Stored templates: "));
  Serial.println(getAS608FingerprintCount());
  setAS608Led(AS608_LED_BREATHING, AS608_LED_BLUE, 100U, 0U);
}

void loop() {
  const int16_t id = scanAS608Fingerprint();
  if (id >= 0) {
    Serial.print(F("Match! ID #"));
    Serial.println(id);
    delay(1000);
  } else if (id == AS608_MATCH_FAIL) {
    Serial.println(F("Unknown finger."));
    delay(500);
  }
  delay(100);
}
