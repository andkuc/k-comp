/*
  Program Title: Simple MAX30102 Heart Rate & SpO2 Demo
  Author: Andreas Kucher
  License: MIT

  Reads heart rate (BPM) and SpO2 (%) from a MAX30102 sensor over I2C
  (address 0x57). Rest your finger gently on the sensor without pressing hard.
*/

#include <kcomp_max30102.h>

uint32_t lastPrintMs = 0UL;

void setup() {
  Serial.begin(115200);
  Serial.println(F("MAX30102 Heart Rate & SpO2 Test"));

  if (!initMAX30102()) {
    Serial.println(F("Error: MAX30102 not found! Check I2C wiring."));
    while (1) {}
  }

  Serial.println(F("Place finger lightly on sensor..."));
}

void loop() {
  // Drain FIFO samples continuously in loop()
  updateMAX30102();

  if ((millis() - lastPrintMs) >= 1000UL) {
    lastPrintMs = millis();

    uint16_t bpm = getMAX30102HeartRate();
    uint8_t spo2 = getMAX30102SpO2();

    if (bpm > 0U) {
      Serial.print(F("Heart Rate: "));
      Serial.print(bpm);
      Serial.print(F(" bpm | SpO2: "));
      Serial.print(spo2);
      Serial.println(F(" %"));
    } else {
      Serial.println(F("No finger detected."));
    }
  }
}
