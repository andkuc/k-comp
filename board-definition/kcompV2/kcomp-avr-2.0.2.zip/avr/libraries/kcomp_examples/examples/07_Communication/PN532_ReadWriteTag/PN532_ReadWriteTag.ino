/*
  Program Title: Simple PN532 NFC Tag Reader & Writer
  Author: Andreas Kucher
  License: MIT

  Scans NFC/RFID tags over I2C (address 0x24) and reads/writes 16 bytes
  in slot 4 when 'r' or 'w' is sent over Serial at 115200 baud.
*/

#include <kcomp_pn532.h>

static constexpr uint8_t TARGET_SLOT = 4U;
uint8_t writePayload[16] = "K-COMP NFC TAG!";
uint8_t readBuffer[16];

void setup() {
  Serial.begin(115200);
  Serial.println(F("PN532 NFC Test (send 'r' to read, 'w' to write slot 4)"));

  if (!initPN532()) {
    Serial.println(F("Error: PN532 not found! Check I2C wiring."));
    while (1) {}
  }
}

void loop() {
  if (Serial.available() > 0) {
    char cmd = (char)Serial.read();
    while (Serial.available() > 0) {
      Serial.read();
    }

    if (cmd == 'r' || cmd == 'R') {
      Serial.println(F("Hold tag near PN532..."));
      while (scanPN532Tag() != PN532_OK) {
        delay(100);
      }
      if (readPN532TagMemory(TARGET_SLOT, readBuffer) == PN532_OK) {
        Serial.print(F("Read: "));
        for (uint8_t i = 0U; i < 16U; i++) {
          Serial.print((readBuffer[i] >= 32U && readBuffer[i] <= 126U) ? (char)readBuffer[i] : '.');
        }
        Serial.println();
      } else {
        Serial.println(F("Read failed."));
      }
    } else if (cmd == 'w' || cmd == 'W') {
      Serial.println(F("Hold tag near PN532..."));
      while (scanPN532Tag() != PN532_OK) {
        delay(100);
      }
      if (writePN532TagMemory(TARGET_SLOT, writePayload) == PN532_OK) {
        Serial.println(F("Write OK."));
      } else {
        Serial.println(F("Write failed."));
      }
    }
  }
}
