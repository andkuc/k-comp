/*
  Program Title: Simple CH9329 USB HID Mouse & Keyboard Demo
  Author: Andreas Kucher
  License: MIT

  Sends basic mouse movement and text typing over UART to a CH9329 USB HID
  bridge at 9600 baud (SoftwareSerial on AVR, Serial1 on ESP32-S3).
*/

#include <kcomp_ch9329_hid.h>

static constexpr uint8_t HID_RX_PIN = 6U;
static constexpr uint8_t HID_TX_PIN = 7U;

void setup() {
  Serial.begin(115200);
  initCH9329(HID_RX_PIN, HID_TX_PIN);
  Serial.println(F("CH9329 HID ready."));
}

void loop() {
  moveCH9329Mouse(10, 0);
  delay(1000);
  moveCH9329Mouse(-10, 0);
  delay(1000);
}
