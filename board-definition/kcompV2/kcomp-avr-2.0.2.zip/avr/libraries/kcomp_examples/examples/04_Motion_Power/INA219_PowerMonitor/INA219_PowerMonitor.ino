/*
  Program Title: Simple INA219 Current & Power Monitor Demo
  Author: Andreas Kucher
  License: MIT

  Measures bus voltage (V), shunt voltage (mV), current (mA), and power (mW)
  over I2C (default address 0x40).
*/

#include <kcomp_ina219.h>

void setup() {
  Serial.begin(115200);

  if (!initINA219()) {
    Serial.println(F("Error: INA219 not found! Check I2C wiring."));
    while (1) {}
  }

  Serial.println(F("INA219 Power Monitor initialized."));
}

void loop() {
  float busVoltage_V = getINA219BusVoltage_V();
  float shuntVolt_mV = getINA219ShuntVoltage_mV();
  float current_mA   = getINA219Current_mA();
  float power_mW     = getINA219Power_mW();

  Serial.print(F("Bus: "));
  Serial.print(busVoltage_V, 2);
  Serial.print(F(" V | Shunt: "));
  Serial.print(shuntVolt_mV, 2);
  Serial.print(F(" mV | Current: "));
  Serial.print(current_mA, 1);
  Serial.print(F(" mA | Power: "));
  Serial.print(power_mW, 1);
  Serial.println(F(" mW"));

  delay(500);
}
