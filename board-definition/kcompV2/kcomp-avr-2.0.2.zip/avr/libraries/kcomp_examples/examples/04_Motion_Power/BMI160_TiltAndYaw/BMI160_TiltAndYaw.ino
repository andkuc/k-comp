/*
  Program Title: Simple GY-BMI160 6-Axis IMU Demo
  Author: Andreas Kucher
  License: MIT

  Reads accelerometer, gyroscope, and computed pitch/roll/yaw angles over I2C
  (default address 0x69). Keep loop delay short (10..50 ms) for accurate yaw integration.
*/

#include <kcomp_bmi160.h>

void setup() {
  Serial.begin(115200);
  Serial.println(F("Initializing GY-BMI160..."));

  if (!initBMI160()) {
    Serial.println(F("Error: BMI160 not found! Check I2C wiring."));
    while (1) {}
  }

  resetBMI160Yaw();
  Serial.println(F("BMI160 ready."));
}

void loop() {
  BMI160Data imu = getBMI160Data();

  Serial.print(F("Pitch(X): "));
  Serial.print(imu.angleX, 1);
  Serial.print(F(" | Roll(Y): "));
  Serial.print(imu.angleY, 1);
  Serial.print(F(" | Yaw(Z): "));
  Serial.println(imu.angleZ, 1);

  delay(50);
}
