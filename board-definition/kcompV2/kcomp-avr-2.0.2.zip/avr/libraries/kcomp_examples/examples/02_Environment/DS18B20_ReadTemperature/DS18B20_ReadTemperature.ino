/*
  Program Title: Simple DS18B20 1-Wire Temperature Sensor Demo
  Author: Andreas Kucher
  License: MIT

  Reads temperature in Celsius from a DS18B20 sensor using the built-in
  zero-dependency 1-Wire engine (requires a 4.7k pull-up resistor to VCC).
*/

#include <kcomp_ds18b20.h>

static constexpr uint8_t DS18B20_PIN = 12U;

void setup() {
  Serial.begin(115200);

  if (!initDS18B20(DS18B20_PIN)) {
    Serial.println(F("Error: DS18B20 not found! Check wiring and 4.7k pull-up."));
    while (1) {}
  }

  Serial.println(F("DS18B20 initialized."));
  requestDS18B20();
}

void loop() {
  const DS18B20Data reading = getDS18B20Data();
  if (reading.isValid) {
    Serial.print(F("Temperature: "));
    Serial.print(reading.temperatureC, 2);
    Serial.println(F(" C"));
    requestDS18B20();
  }
}
