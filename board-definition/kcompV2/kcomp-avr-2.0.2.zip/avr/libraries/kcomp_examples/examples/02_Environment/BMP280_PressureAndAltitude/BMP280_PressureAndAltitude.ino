/*
  Program Title: Simple BMP280 Temperature, Pressure & Altitude Demo
  Author: Andreas Kucher
  License: MIT

  Reads temperature (C), barometric pressure (hPa), and estimated altitude (m)
  from a BMP280 sensor connected to the I2C bus (default address 0x76).
*/

#include <kcomp_bmp280.h>

void setup() {
  Serial.begin(115200);
  Serial.println(F("BMP280 Sensor Test"));

  // Pass BMP280_ADDR_ALT (0x77) if your module has SDO pulled HIGH
  if (!initBMP280()) {
    Serial.println(F("Error: BMP280 not found! Check I2C wiring."));
    while (1) {}
  }

  Serial.println(F("BMP280 initialized."));
}

void loop() {
  float temperature = getBMP280Temperature();
  float pressurePa = getBMP280Pressure();
  float altitude = getBMP280Altitude(1013.25f);

  Serial.print(F("Temp: "));
  Serial.print(temperature, 1);
  Serial.print(F(" C | Press: "));
  Serial.print(pressurePa / 100.0f, 1);
  Serial.print(F(" hPa | Alt: "));
  Serial.print(altitude, 1);
  Serial.println(F(" m"));

  delay(1000);
}
