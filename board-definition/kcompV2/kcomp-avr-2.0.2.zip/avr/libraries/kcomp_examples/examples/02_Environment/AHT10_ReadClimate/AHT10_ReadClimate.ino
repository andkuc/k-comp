/*
  Program Title: Simple AHT10 Temperature & Humidity Demo
  Author: Andreas Kucher
  License: MIT

  Reads temperature (Celsius) and relative humidity (%RH) from an AHT10
  sensor connected to the I2C bus (default address 0x38).
*/

#include <kcomp_aht10.h>

void setup() {
  Serial.begin(115200);
  Serial.println(F("AHT10 Sensor Test"));

  if (!initAHT10()) {
    Serial.println(F("Error: AHT10 not found! Check I2C wiring."));
    while (1) {}
  }

  Serial.println(F("AHT10 initialized."));
}

void loop() {
  float temperature = getAHT10Temperature();
  float humidity = getAHT10Humidity();

  Serial.print(F("Temperature: "));
  Serial.print(temperature, 1);
  Serial.print(F(" C | Humidity: "));
  Serial.print(humidity, 1);
  Serial.println(F(" %"));

  delay(1000);
}
