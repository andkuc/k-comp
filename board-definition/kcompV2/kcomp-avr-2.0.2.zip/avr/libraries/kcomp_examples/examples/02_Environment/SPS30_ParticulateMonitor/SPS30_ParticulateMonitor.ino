/*
  Program Title: Simple SPS30 Particulate Matter Demo
  Author: Andreas Kucher
  License: MIT

  Reads PM2.5 and PM10 concentrations, air quality score, and source hint
  from an SPS30 particulate sensor over I2C (address 0x69) at 115200 baud.
*/

#include <kcomp_sps30.h>

void setup() {
  Serial.begin(115200);
  delay(500);

  Serial.println(F("SPS30 Particulate Matter Test"));
  if (!initSPS30()) {
    Serial.println(F("Error: SPS30 not found! Check I2C wiring."));
    while (1) {}
  }

  Serial.println(F("SPS30 measurement started."));
}

void loop() {
  SPS30Data air = getSPS30Data();
  if (air.isValid) {
    Serial.print(F("PM2.5: "));
    Serial.print(air.pm2_5);
    Serial.print(F(" ug/m3 | PM10: "));
    Serial.print(air.pm10_0);
    Serial.print(F(" ug/m3 | Score: "));
    Serial.println(getSPS30AirQualityScore());
  }

  delay(500);
}
