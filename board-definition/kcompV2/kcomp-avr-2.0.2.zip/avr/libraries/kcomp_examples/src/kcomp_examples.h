// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      examples
// @title       K-Comp Categorized Example Collection
// @targets     avr, esp32s3
// @bus         none (example collection)
// @timers      none
// @sram_bytes  0

#ifndef KCOMP_EXAMPLES_H
#define KCOMP_EXAMPLES_H

// Central example-only library organizing all K-Comp sketches into
// category subfolders (00_Tests through 08_Demos) for the Arduino IDE.

#endif
