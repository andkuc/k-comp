// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_ina219.h"
#include <Wire.h>

// Internal INA219 register addresses
static constexpr uint8_t INA219_REG_CONFIG      = 0x00U;
static constexpr uint8_t INA219_REG_SHUNT_VOLT  = 0x01U;
static constexpr uint8_t INA219_REG_BUS_VOLT    = 0x02U;
static constexpr uint8_t INA219_REG_POWER       = 0x03U;
static constexpr uint8_t INA219_REG_CURRENT     = 0x04U;
static constexpr uint8_t INA219_REG_CALIBRATION = 0x05U;

// Configuration masks (12-bit ADC + 128x hardware averaging, ~68 ms)
static constexpr uint16_t INA219_CFG_RESET     = 0x8000U;
static constexpr uint16_t INA219_CFG_STANDARD  = 0x3FFFU;  // 32V, PGA /8 (+/-3.2A)
static constexpr uint16_t INA219_CFG_HIGH_PREC = 0x07FFU;  // 16V, PGA /1 (+/-400mA)

// Calibration constant for 0.1 Ohm shunt (Current LSB = 0.1 mA)
static constexpr uint16_t INA219_CAL_STANDARD  = 4096U;

static uint8_t  ina219Addr = INA219_ADDR_DEFAULT;
static uint16_t activeConfig = INA219_CFG_STANDARD;
static bool     overflowFlag = false;

static void writeReg16(uint8_t reg, uint16_t value) {
    Wire.beginTransmission(ina219Addr);
    Wire.write(reg);
    Wire.write((uint8_t)(value >> 8));
    Wire.write((uint8_t)(value & 0xFFU));
    Wire.endTransmission();
}

static uint16_t readReg16(uint8_t reg) {
    Wire.beginTransmission(ina219Addr);
    Wire.write(reg);
    if (Wire.endTransmission(false) != 0) {
        return 0U;
    }
    if (Wire.requestFrom(ina219Addr, (uint8_t)2U) != 2U) {
        return 0U;
    }
    const uint8_t msb = (uint8_t)Wire.read();
    const uint8_t lsb = (uint8_t)Wire.read();
    return (uint16_t)(((uint16_t)msb << 8) | lsb);
}

bool initINA219(uint8_t address) {
    ina219Addr = address;
    activeConfig = INA219_CFG_STANDARD;
    overflowFlag = false;
    Wire.begin();

    Wire.beginTransmission(ina219Addr);
    if (Wire.endTransmission() != 0) {
        return false;
    }

    writeReg16(INA219_REG_CONFIG, INA219_CFG_RESET);
    delay(2);

    writeReg16(INA219_REG_CALIBRATION, INA219_CAL_STANDARD);
    writeReg16(INA219_REG_CONFIG, activeConfig);

    // Wait for the first 128-sample hardware average to complete
    delay(70);
    return true;
}

float getINA219BusVoltage_V() {
    const uint16_t raw = readReg16(INA219_REG_BUS_VOLT);
    overflowFlag = (raw & 0x0001U) != 0U;
    const int16_t shifted = (int16_t)(raw >> 3);
    return (float)shifted * 0.004f;
}

float getINA219ShuntVoltage_mV() {
    const int16_t raw = (int16_t)readReg16(INA219_REG_SHUNT_VOLT);
    return (float)raw * 0.01f;
}

float getINA219Current_mA() {
    const int16_t raw = (int16_t)readReg16(INA219_REG_CURRENT);
    return (float)raw * 0.1f;
}

float getINA219Power_mW() {
    const uint16_t raw = readReg16(INA219_REG_POWER);
    return (float)raw * 2.0f;
}

void setINA219HighPrecision(bool enable) {
    activeConfig = enable ? INA219_CFG_HIGH_PREC : INA219_CFG_STANDARD;
    writeReg16(INA219_REG_CALIBRATION, INA219_CAL_STANDARD);
    writeReg16(INA219_REG_CONFIG, activeConfig);
    delay(70);
}

bool isINA219Overflow() {
    const uint16_t raw = readReg16(INA219_REG_BUS_VOLT);
    overflowFlag = (raw & 0x0001U) != 0U;
    return overflowFlag;
}
