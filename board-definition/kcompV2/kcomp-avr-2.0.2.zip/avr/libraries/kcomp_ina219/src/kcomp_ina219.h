// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      ina219
// @title       INA219 Current & Power Monitor
// @targets     avr, esp32s3
// @bus         i2c (0x40 default, 0x41/0x44/0x45 alt)
// @timers      none
// @sram_bytes  ~4

#ifndef KCOMP_INA219_H
#define KCOMP_INA219_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Supported I2C addresses (depends on A0/A1 solder jumpers)
#define INA219_ADDR_DEFAULT 0x40  // A0 = GND, A1 = GND
#define INA219_ADDR_A0      0x41  // A0 = VCC, A1 = GND
#define INA219_ADDR_A1      0x44  // A0 = GND, A1 = VCC
#define INA219_ADDR_A0_A1   0x45  // A0 = VCC, A1 = VCC

// Initialize the INA219 sensor with 32V / 3.2A calibration (0.1 Ohm shunt).
// Returns true if the sensor acknowledges at the specified I2C address.
bool initINA219(uint8_t address = INA219_ADDR_DEFAULT);

// Read bus supply voltage (VIN- to GND) in Volts (V).
float getINA219BusVoltage_V();

// Read voltage drop across the 0.1 Ohm shunt resistor in millivolts (mV).
float getINA219ShuntVoltage_mV();

// Read load current in milliamps (mA).
float getINA219Current_mA();

// Read total load power in milliwatts (mW).
float getINA219Power_mW();

// Switch between Standard Mode (+/-3200 mA, 32V) and High-Precision Mode (+/-400 mA, 16V).
void setINA219HighPrecision(bool enable);

// Return true if the measured current or power exceeded the active hardware range.
bool isINA219Overflow();

#endif
