// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      potentiometer
// @title       Onboard Rotary Potentiometer
// @targets     avr
// @bus         analog (A0, DIP S1-3)
// @timers      none
// @sram_bytes  0

#ifndef KCOMP_POTENTIOMETER_H
#define KCOMP_POTENTIOMETER_H

#include <Arduino.h>
#include <stdint.h>

#define POTENTIOMETER_PIN A0

void initPotentiometer();
uint16_t getPotentiometerRaw();
uint8_t getPotentiometerValue();

#endif
