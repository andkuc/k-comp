// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_potentiometer.h"

static constexpr uint16_t POT_ADC_MAX = 1023U;

void initPotentiometer() {
    pinMode(POTENTIOMETER_PIN, INPUT);
}

uint16_t getPotentiometerRaw() {
    uint16_t sample = (uint16_t)analogRead(POTENTIOMETER_PIN);
    if (sample > POT_ADC_MAX) {
        sample = POT_ADC_MAX;
    }
    // Invert so clockwise rotation increases the value on K-Comp V2 PCB
    return POT_ADC_MAX - sample;
}

uint8_t getPotentiometerValue() {
    const uint16_t raw = getPotentiometerRaw();
    return (uint8_t)(((uint32_t)raw * 100UL + (POT_ADC_MAX / 2U)) / POT_ADC_MAX);
}
