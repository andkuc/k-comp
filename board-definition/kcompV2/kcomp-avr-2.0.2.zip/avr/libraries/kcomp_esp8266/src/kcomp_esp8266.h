// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      esp8266
// @title       ESP8266 (ESP-01) WiFi AT-Command Module
// @targets     avr, esp32s3
// @bus         uart (SoftwareSerial on AVR @ 9600, Serial1 on ESP32-S3; DIP S1-7/S1-8)
// @timers      none (PCINT on AVR SoftwareSerial)
// @sram_bytes  ~140 (stack/static fixed char buffers, zero String heap)

#ifndef KCOMP_ESP8266_H
#define KCOMP_ESP8266_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Default AT-command timeout in milliseconds
#define ESP8266_TIMEOUT_DEFAULT 5000U

// One-time helper to negotiate a factory 115200-baud ESP8266 down to 9600 baud.
// Returns true if the module responds with OK at 9600 baud.
bool setupESP8266BaudRate(uint8_t rxPin, uint8_t txPin);

// Initialize the ESP8266 UART and join a WiFi access point.
// Returns true if the module responds and connects to the network.
bool initESP8266(uint8_t rxPin, uint8_t txPin, const char* ssid, const char* pass, uint32_t baudRate = 9600UL);

// Enable or disable AT debug output on the USB Serial monitor (default: true).
void setESP8266Debug(bool enable);

// Synchronize SNTP time (required for TLS/HTTPS certificate validation).
// timezoneHours: e.g. 1 for CET, 2 for CEST. Returns true once year 202x is reported.
bool syncESP8266Time(int8_t timezoneHours);

// Configure the ESP8266 SSL buffer size (typically 4096, 8192, or 16384 bytes).
bool setESP8266SSLBufferSize(uint16_t size);

// Open a TCP (or SSL when port == 443) connection to a remote host.
bool connectESP8266Server(const char* domain, uint16_t port);

// Send a null-terminated line followed by CRLF to the connected server.
bool printESP8266Line(const char* data);

// Return number of unread bytes waiting in the ESP8266 UART buffer.
int getESP8266Available();

// Read one byte from the ESP8266 UART buffer, or -1 if none is available.
int readESP8266();

// Query and print the module's IP/MAC status (AT+CIFSR) to Serial.
void printESP8266WifiStatus();

// Close the active TCP/SSL connection.
void stopESP8266();

#endif
