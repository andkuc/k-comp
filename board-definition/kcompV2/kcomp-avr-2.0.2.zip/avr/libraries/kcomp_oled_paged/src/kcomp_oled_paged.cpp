// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_oled_paged.h"
#include "kcomp_font5x7.h"
#include <Wire.h>
#include <string.h>

// Single 128-byte horizontal page buffer (1 of 8 bands)
static uint8_t oledBuffer[128];
static uint8_t oledI2cAddr = OLED_I2C_ADDRESS;
static uint8_t currentPage = 0U;
static uint8_t oledRotation = OLED_ROTATION_0;
static int16_t cursorX = 0;
static int16_t cursorY = 0;

static int16_t abs16(int16_t v) {
    return (v < 0) ? (int16_t)(-v) : v;
}

static void sendCommand(uint8_t cmd) {
    Wire.beginTransmission(oledI2cAddr);
    Wire.write(0x00);
    Wire.write(cmd);
    Wire.endTransmission();
}

// ==============================================================================
// System & Picture Loop
// ==============================================================================

bool initDisplay(uint8_t address) {
    oledI2cAddr = address;
    oledRotation = OLED_ROTATION_0;
    currentPage = 0U;
    cursorX = 0;
    cursorY = 0;

    // Allow display power rail to stabilize after cold boot
    delay(100);

    Wire.begin();
    Wire.beginTransmission(oledI2cAddr);
    if (Wire.endTransmission() != 0) {
        return false;
    }

    // Chunk 1: Display off, clock divide, multiplex ratio, display offset
    Wire.beginTransmission(oledI2cAddr);
    Wire.write(0x00); Wire.write(0xAE);
    Wire.write(0xD5); Wire.write(0x80);
    Wire.write(0xA8); Wire.write(0x3F);
    Wire.write(0xD3); Wire.write(0x00);
    Wire.endTransmission();

    // Chunk 2: Start line, charge pump, Page Addressing Mode (0x02), remap
    Wire.beginTransmission(oledI2cAddr);
    Wire.write(0x00); Wire.write(0x40);
    Wire.write(0x8D); Wire.write(0x14);
    Wire.write(0x20); Wire.write(0x02);
    Wire.write(0xA1); Wire.write(0xC8);
    Wire.write(0xDA); Wire.write(0x12);
    Wire.endTransmission();

    // Chunk 3: Contrast, precharge, VCOMH, normal mode, display on
    Wire.beginTransmission(oledI2cAddr);
    Wire.write(0x00); Wire.write(0x81); Wire.write(0xCF);
    Wire.write(0xD9); Wire.write(0xF1);
    Wire.write(0xDB); Wire.write(0x40);
    Wire.write(0xA4); Wire.write(0xA6);
    Wire.write(0x2E); Wire.write(0xAF);
    Wire.endTransmission();

    delay(100);

    // Clear physical GDDRAM across all 8 pages in 16-byte chunks
    for (uint8_t p = 0U; p < OLED_PAGES; p++) {
        Wire.beginTransmission(oledI2cAddr);
        Wire.write(0x00);
        Wire.write((uint8_t)(0xB0U + p));
        Wire.write(0x00);
        Wire.write(0x10);
        Wire.endTransmission();

        for (uint8_t col = 0U; col < 128U; col += 16U) {
            Wire.beginTransmission(oledI2cAddr);
            Wire.write(0x40);
            for (uint8_t i = 0U; i < 16U; i++) {
                Wire.write(0x00);
            }
            Wire.endTransmission();
        }
    }
    return true;
}

void firstPage() {
    currentPage = 0U;
    memset(oledBuffer, 0, sizeof(oledBuffer));
}

bool nextPage() {
    // Select current physical page and column 0
    Wire.beginTransmission(oledI2cAddr);
    Wire.write(0x00);
    Wire.write((uint8_t)(0xB0U + currentPage));
    Wire.write(0x00);
    Wire.write(0x10);
    Wire.endTransmission();

    // Stream the 128-byte band in 16-byte chunks
    for (uint8_t col = 0U; col < 128U; col += 16U) {
        Wire.beginTransmission(oledI2cAddr);
        Wire.write(0x40);
        for (uint8_t i = 0U; i < 16U; i++) {
            Wire.write(oledBuffer[col + i]);
        }
        Wire.endTransmission();
    }

    currentPage++;
    if (currentPage >= OLED_PAGES) {
        return false;
    }

    memset(oledBuffer, 0, sizeof(oledBuffer));
    return true;
}

uint8_t getDisplayRotation() {
    return oledRotation;
}

void setDisplayRotation(uint8_t rotation) {
    oledRotation = rotation & 3U;
}

void invertDisplay(bool invert) {
    sendCommand(invert ? 0xA7 : 0xA6);
}

void dimDisplay(bool dim) {
    sendCommand(0x81);
    sendCommand(dim ? 0x00 : 0xCF);
}

// ==============================================================================
// Core Geometry Primitives
// ==============================================================================

void drawPixel(int16_t x, int16_t y, uint8_t color) {
    if ((x < 0) || (x >= CURRENT_WIDTH) || (y < 0) || (y >= CURRENT_HEIGHT)) {
        return;
    }

    int16_t t;
    switch (oledRotation) {
        case OLED_ROTATION_90:  t = x; x = OLED_WIDTH - 1 - y; y = t; break;
        case OLED_ROTATION_180: x = OLED_WIDTH - 1 - x; y = OLED_HEIGHT - 1 - y; break;
        case OLED_ROTATION_270: t = x; x = y; y = OLED_HEIGHT - 1 - t; break;
        default: break;
    }

    // Physical page gatekeeper: only write pixels belonging to the active 8-row band
    if ((uint8_t)(y / 8) != currentPage) {
        return;
    }

    const uint8_t mask = (uint8_t)(1U << (y & 7));
    switch (color) {
        case OLED_COLOR_WHITE:  oledBuffer[x] |= mask;  break;
        case OLED_COLOR_BLACK:  oledBuffer[x] &= (uint8_t)(~mask); break;
        case OLED_COLOR_INVERT: oledBuffer[x] ^= mask;  break;
        default: break;
    }
}

void drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint8_t color) {
    const bool steep = abs16(y1 - y0) > abs16(x1 - x0);
    if (steep) {
        int16_t t = x0; x0 = y0; y0 = t;
        t = x1; x1 = y1; y1 = t;
    }
    if (x0 > x1) {
        int16_t t = x0; x0 = x1; x1 = t;
        t = y0; y0 = y1; y1 = t;
    }

    const int16_t dx = x1 - x0;
    const int16_t dy = abs16(y1 - y0);
    int16_t err = dx / 2;
    const int16_t ystep = (y0 < y1) ? 1 : -1;

    for (; x0 <= x1; x0++) {
        if (steep) {
            drawPixel(y0, x0, color);
        } else {
            drawPixel(x0, y0, color);
        }
        err -= dy;
        if (err < 0) {
            y0 += ystep;
            err += dx;
        }
    }
}

void drawFastVLine(int16_t x, int16_t y, int16_t h, uint8_t color) {
    if (h <= 0 || x < 0 || x >= CURRENT_WIDTH || y >= CURRENT_HEIGHT) {
        return;
    }

    int16_t y0 = (y < 0) ? 0 : y;
    int16_t y1 = y + h - 1;
    if (y1 >= CURRENT_HEIGHT) {
        y1 = CURRENT_HEIGHT - 1;
    }

    // Fast Y-page clipping is valid only when logical Y aligns with physical Y (rotation 0)
    if (oledRotation == OLED_ROTATION_0) {
        const int16_t pageTop = (int16_t)currentPage * 8;
        const int16_t pageBottom = pageTop + 7;
        if (y1 < pageTop || y0 > pageBottom) {
            return;
        }
        if (y0 < pageTop) y0 = pageTop;
        if (y1 > pageBottom) y1 = pageBottom;
    }

    for (int16_t i = y0; i <= y1; i++) {
        drawPixel(x, i, color);
    }
}

void drawFastHLine(int16_t x, int16_t y, int16_t w, uint8_t color) {
    if (w <= 0 || y < 0 || y >= CURRENT_HEIGHT || x >= CURRENT_WIDTH) {
        return;
    }

    // Fast Y-page clipping is valid only when logical Y aligns with physical Y (rotation 0)
    if (oledRotation == OLED_ROTATION_0) {
        if ((uint8_t)(y / 8) != currentPage) {
            return;
        }
    }

    int16_t x0 = (x < 0) ? 0 : x;
    int16_t x1 = x + w - 1;
    if (x1 >= CURRENT_WIDTH) {
        x1 = CURRENT_WIDTH - 1;
    }

    for (int16_t i = x0; i <= x1; i++) {
        drawPixel(i, y, color);
    }
}

void drawRect(int16_t x, int16_t y, int16_t w, int16_t h, uint8_t color) {
    if (w <= 0 || h <= 0) {
        return;
    }
    const int16_t rectBottom = y + h - 1;
    if (oledRotation == OLED_ROTATION_0) {
        const int16_t pageTop = (int16_t)currentPage * 8;
        const int16_t pageBottom = pageTop + 7;
        if (rectBottom < pageTop || y > pageBottom) {
            return;
        }
    }

    drawFastHLine(x, y, w, color);
    drawFastHLine(x, rectBottom, w, color);
    drawFastVLine(x, y, h, color);
    drawFastVLine(x + w - 1, y, h, color);
}

void fillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint8_t color) {
    if (w <= 0 || h <= 0) {
        return;
    }

    int16_t startX = (x > 0) ? x : 0;
    int16_t endX = x + w - 1;
    if (endX >= CURRENT_WIDTH) {
        endX = CURRENT_WIDTH - 1;
    }

    int16_t startY = (y > 0) ? y : 0;
    int16_t endY = y + h - 1;
    if (endY >= CURRENT_HEIGHT) {
        endY = CURRENT_HEIGHT - 1;
    }

    if (oledRotation == OLED_ROTATION_0) {
        const int16_t pageTop = (int16_t)currentPage * 8;
        const int16_t pageBottom = pageTop + 7;
        if (endY < pageTop || startY > pageBottom) {
            return;
        }
        if (startY < pageTop) startY = pageTop;
        if (endY > pageBottom) endY = pageBottom;
    }

    for (int16_t i = startX; i <= endX; i++) {
        for (int16_t j = startY; j <= endY; j++) {
            drawPixel(i, j, color);
        }
    }
}

void drawCircle(int16_t x0, int16_t y0, int16_t r, uint8_t color) {
    if (r < 0) {
        return;
    }
    int16_t f = 1 - r;
    int16_t ddF_x = 1;
    int16_t ddF_y = -2 * r;
    int16_t x = 0;
    int16_t y = r;

    drawPixel(x0, y0 + r, color);
    drawPixel(x0, y0 - r, color);
    drawPixel(x0 + r, y0, color);
    drawPixel(x0 - r, y0, color);

    while (x < y) {
        if (f >= 0) {
            y--;
            ddF_y += 2;
            f += ddF_y;
        }
        x++;
        ddF_x += 2;
        f += ddF_x;
        drawPixel(x0 + x, y0 + y, color);
        drawPixel(x0 - x, y0 + y, color);
        drawPixel(x0 + x, y0 - y, color);
        drawPixel(x0 - x, y0 - y, color);
        drawPixel(x0 + y, y0 + x, color);
        drawPixel(x0 - y, y0 + x, color);
        drawPixel(x0 + y, y0 - x, color);
        drawPixel(x0 - y, y0 - x, color);
    }
}

void fillCircle(int16_t x0, int16_t y0, int16_t r, uint8_t color) {
    if (r < 0) {
        return;
    }
    drawFastVLine(x0, y0 - r, 2 * r + 1, color);
    int16_t f = 1 - r;
    int16_t ddF_x = 1;
    int16_t ddF_y = -2 * r;
    int16_t x = 0;
    int16_t y = r;

    while (x < y) {
        if (f >= 0) {
            y--;
            ddF_y += 2;
            f += ddF_y;
        }
        x++;
        ddF_x += 2;
        f += ddF_x;
        drawFastVLine(x0 + x, y0 - y, 2 * y + 1, color);
        drawFastVLine(x0 - x, y0 - y, 2 * y + 1, color);
        drawFastVLine(x0 + y, y0 - x, 2 * x + 1, color);
        drawFastVLine(x0 - y, y0 - x, 2 * x + 1, color);
    }
}

void drawTriangle(int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2, int16_t y2, uint8_t color) {
    drawLine(x0, y0, x1, y1, color);
    drawLine(x1, y1, x2, y2, color);
    drawLine(x2, y2, x0, y0, color);
}

void fillTriangle(int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2, int16_t y2, uint8_t color) {
    int16_t a, b, y, last;

    if (y0 > y1) { int16_t t = y0; y0 = y1; y1 = t; t = x0; x0 = x1; x1 = t; }
    if (y1 > y2) { int16_t t = y2; y2 = y1; y1 = t; t = x2; x2 = x1; x1 = t; }
    if (y0 > y1) { int16_t t = y0; y0 = y1; y1 = t; t = x0; x0 = x1; x1 = t; }

    if (y0 == y2) {
        a = b = x0;
        if (x1 < a) a = x1; else if (x1 > b) b = x1;
        if (x2 < a) a = x2; else if (x2 > b) b = x2;
        drawFastHLine(a, y0, b - a + 1, color);
        return;
    }

    const int16_t dx01 = x1 - x0;
    const int16_t dy01 = y1 - y0;
    const int16_t dx02 = x2 - x0;
    const int16_t dy02 = y2 - y0;
    const int16_t dx12 = x2 - x1;
    const int16_t dy12 = y2 - y1;
    int32_t sa = 0;
    int32_t sb = 0;

    last = (y1 == y2) ? y1 : (y1 - 1);
    for (y = y0; y <= last; y++) {
        a = x0 + (int16_t)(sa / dy01);
        b = x0 + (int16_t)(sb / dy02);
        sa += dx01;
        sb += dx02;
        if (a > b) { int16_t t = a; a = b; b = t; }
        drawFastHLine(a, y, b - a + 1, color);
    }

    sa = (int32_t)dx12 * (y - y1);
    sb = (int32_t)dx02 * (y - y0);
    for (; y <= y2; y++) {
        a = x1 + (int16_t)(sa / dy12);
        b = x0 + (int16_t)(sb / dy02);
        sa += dx12;
        sb += dx02;
        if (a > b) { int16_t t = a; a = b; b = t; }
        drawFastHLine(a, y, b - a + 1, color);
    }
}

// ==============================================================================
// Text Engine & Bitmaps
// ==============================================================================

void setCursor(int16_t x, int16_t y) {
    cursorX = x;
    cursorY = y;
}

void printChar(char c, uint8_t color, uint8_t size) {
    if (size == 0U) {
        return;
    }

    uint8_t code = (uint8_t)c;
    if (code < KCOMP_FONT_FIRST_CHAR || code > KCOMP_FONT_LAST_CHAR) {
        code = (uint8_t)'?';
    }

    if ((cursorX >= CURRENT_WIDTH) || (cursorY >= CURRENT_HEIGHT) ||
        ((cursorX + 5 * (int16_t)size - 1) < 0) || ((cursorY + 8 * (int16_t)size - 1) < 0)) {
        cursorX += 6 * (int16_t)size;
        return;
    }

    // Fast Y-page skip is valid only at rotation 0
    if (oledRotation == OLED_ROTATION_0) {
        const int16_t charTop = cursorY;
        const int16_t charBottom = cursorY + (8 * (int16_t)size) - 1;
        const int16_t pageTop = (int16_t)currentPage * 8;
        const int16_t pageBottom = pageTop + 7;
        if (charBottom < pageTop || charTop > pageBottom) {
            cursorX += 6 * (int16_t)size;
            return;
        }
    }

    const uint16_t glyphOffset = (uint16_t)(code - KCOMP_FONT_FIRST_CHAR) * 5U;
    for (int8_t i = 0; i < 5; i++) {
        uint8_t line = KCOMP_READ_BYTE(&KCOMP_FONT_5X7[glyphOffset + (uint16_t)i]);
        for (int8_t j = 0; j < 7; j++, line >>= 1) {
            if (line & 1U) {
                if (size == 1U) {
                    drawPixel(cursorX + i, cursorY + j, color);
                } else {
                    fillRect(cursorX + (i * (int16_t)size), cursorY + (j * (int16_t)size), size, size, color);
                }
            }
        }
    }

    cursorX += 6 * (int16_t)size;
}

void printText(const char* text, uint8_t color, uint8_t size) {
    if (text == NULL || size == 0U) {
        return;
    }
    const int16_t startX = cursorX;
    while (*text != '\0') {
        if (*text == '\n') {
            cursorX = startX;
            cursorY += 8 * (int16_t)size;
        } else {
            if (cursorX + (5 * (int16_t)size) > CURRENT_WIDTH) {
                cursorX = startX;
                cursorY += 8 * (int16_t)size;
            }
            printChar(*text, color, size);
        }
        text++;
    }
}

void drawBitmap(int16_t x, int16_t y, const uint8_t* bitmap, int16_t w, int16_t h, uint8_t color) {
    if (bitmap == NULL || w <= 0 || h <= 0) {
        return;
    }

    const int16_t pageTop = (int16_t)currentPage * 8;
    const int16_t pageBottom = pageTop + 7;
    if (oledRotation == OLED_ROTATION_0) {
        if ((y + h - 1) < pageTop || y > pageBottom) {
            return;
        }
    }

    const int16_t byteWidth = (w + 7) / 8;
    uint8_t b = 0U;

    for (int16_t j = 0; j < h; j++, y++) {
        if (oledRotation == OLED_ROTATION_0 && (y < pageTop || y > pageBottom)) {
            continue;
        }
        for (int16_t i = 0; i < w; i++) {
            if (i & 7) {
                b <<= 1;
            } else {
                b = KCOMP_READ_BYTE(&bitmap[j * byteWidth + i / 8]);
            }
            if (b & 0x80U) {
                drawPixel(x + i, y, color);
            }
        }
    }
}

// ==============================================================================
// Hardware Scrolling
// ==============================================================================

void startScrollRight(uint8_t startPage, uint8_t endPage) {
    Wire.beginTransmission(oledI2cAddr);
    Wire.write(0x00);
    Wire.write(0x26); Wire.write(0x00); Wire.write(startPage);
    Wire.write(0x00); Wire.write(endPage); Wire.write(0x00);
    Wire.write(0xFF); Wire.write(0x2F);
    Wire.endTransmission();
}

void startScrollLeft(uint8_t startPage, uint8_t endPage) {
    Wire.beginTransmission(oledI2cAddr);
    Wire.write(0x00);
    Wire.write(0x27); Wire.write(0x00); Wire.write(startPage);
    Wire.write(0x00); Wire.write(endPage); Wire.write(0x00);
    Wire.write(0xFF); Wire.write(0x2F);
    Wire.endTransmission();
}

void stopScroll() {
    sendCommand(0x2E);
}
