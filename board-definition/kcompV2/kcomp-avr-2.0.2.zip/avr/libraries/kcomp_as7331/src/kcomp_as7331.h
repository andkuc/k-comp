// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      as7331
// @title       AS7331 UV-A/B/C Irradiance Sensor
// @targets     avr, esp32s3
// @bus         i2c (0x74)
// @timers      none
// @sram_bytes  ~2

#ifndef KCOMP_AS7331_H
#define KCOMP_AS7331_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Default I2C address of the AS7331
#define AS7331_I2C_ADDR 0x74U

// Gain settings for CREG1 (0x00 = highest gain 2048x, 0x0B = lowest gain 1x)
enum AS7331Gain : uint8_t {
    AS7331_GAIN_2048X = 0x00U,
    AS7331_GAIN_1024X = 0x01U,
    AS7331_GAIN_512X  = 0x02U,
    AS7331_GAIN_256X  = 0x03U,
    AS7331_GAIN_128X  = 0x04U,
    AS7331_GAIN_64X   = 0x05U,
    AS7331_GAIN_32X   = 0x06U,
    AS7331_GAIN_16X   = 0x07U,
    AS7331_GAIN_8X    = 0x08U,
    AS7331_GAIN_4X    = 0x09U,
    AS7331_GAIN_2X    = 0x0AU,
    AS7331_GAIN_1X    = 0x0BU
};

// Initialize the AS7331 over I2C and configure continuous UV measurement.
// Returns true if the sensor responds at the given address.
bool initAS7331(uint8_t address = AS7331_I2C_ADDR);

// Update gain setting (clamped to AS7331_GAIN_2048X..AS7331_GAIN_1X).
void setAS7331Gain(uint8_t gainReg);

// Read calculated irradiance in uW/cm2
float getAS7331_UVA();
float getAS7331_UVB();
float getAS7331_UVC();

// Read raw 16-bit ADC counts per UV channel
uint16_t getAS7331RawUVA();
uint16_t getAS7331RawUVB();
uint16_t getAS7331RawUVC();

#endif
