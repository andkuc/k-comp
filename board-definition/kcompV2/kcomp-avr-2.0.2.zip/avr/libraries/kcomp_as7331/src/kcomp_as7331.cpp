// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_as7331.h"
#include <Wire.h>

// Internal AS7331 register addresses
static constexpr uint8_t AS7331_REG_OSR   = 0x00U;
static constexpr uint8_t AS7331_REG_UVA   = 0x02U;
static constexpr uint8_t AS7331_REG_UVB   = 0x03U;
static constexpr uint8_t AS7331_REG_UVC   = 0x04U;
static constexpr uint8_t AS7331_REG_CREG1 = 0x06U;
static constexpr uint8_t AS7331_REG_CREG3 = 0x08U;

// Full-scale baseline constants (uW/cm2)
static constexpr float FSR_UVA_BASE = 340.0f;
static constexpr float FSR_UVB_BASE = 378.0f;
static constexpr float FSR_UVC_BASE = 166.0f;

static uint8_t as7331Addr = AS7331_I2C_ADDR;
static uint8_t currentGainReg = (uint8_t)AS7331_GAIN_64X;
static uint8_t currentTimeReg = 6U;

static bool writeRegister8(uint8_t reg, uint8_t value) {
    Wire.beginTransmission(as7331Addr);
    Wire.write(reg);
    Wire.write(value);
    return Wire.endTransmission() == 0;
}

static uint16_t readRegister16LE(uint8_t reg) {
    Wire.beginTransmission(as7331Addr);
    Wire.write(reg);
    if (Wire.endTransmission(false) != 0) {
        return 0U;
    }
    if (Wire.requestFrom(as7331Addr, (uint8_t)2U) != 2U) {
        return 0U;
    }
    const uint8_t lsb = (uint8_t)Wire.read();
    const uint8_t msb = (uint8_t)Wire.read();
    return (uint16_t)(((uint16_t)msb << 8) | lsb);
}

static float calculateConversionFactor() {
    const uint8_t maxGain = (uint8_t)AS7331_GAIN_1X;
    const uint8_t gainShift = (currentGainReg <= maxGain) ? (uint8_t)(maxGain - currentGainReg) : 0U;
    const uint8_t timeShift = (currentTimeReg <= 15U) ? currentTimeReg : 6U;
    const uint32_t denom = (1UL << gainShift) * (1UL << timeShift);
    return (denom > 0UL) ? (1.0f / (float)denom) : 1.0f;
}

bool initAS7331(uint8_t address) {
    as7331Addr = address;
    Wire.begin();

    Wire.beginTransmission(as7331Addr);
    if (Wire.endTransmission() != 0) {
        return false;
    }

    // Soft reset, then enter configuration mode (OSR = 0x02)
    writeRegister8(AS7331_REG_OSR, 0x0AU);
    delay(10);
    writeRegister8(AS7331_REG_OSR, 0x02U);
    delay(10);

    currentGainReg = (uint8_t)AS7331_GAIN_64X;
    currentTimeReg = 0x06U;
    const uint8_t creg1Val = (uint8_t)((currentGainReg << 4) | (currentTimeReg & 0x0FU));
    writeRegister8(AS7331_REG_CREG1, creg1Val);

    // Continuous measurement mode and default internal clock
    writeRegister8(AS7331_REG_CREG3, 0x00U);

    // Enter measurement mode and start continuous conversion
    writeRegister8(AS7331_REG_OSR, 0x03U);
    delay(10);
    writeRegister8(AS7331_REG_OSR, 0x83U);
    delay(10);

    return true;
}

void setAS7331Gain(uint8_t gainReg) {
    const uint8_t maxGain = (uint8_t)AS7331_GAIN_1X;
    currentGainReg = (gainReg > maxGain) ? maxGain : gainReg;

    writeRegister8(AS7331_REG_OSR, 0x02U);
    delay(10);

    const uint8_t creg1Val = (uint8_t)((currentGainReg << 4) | (currentTimeReg & 0x0FU));
    writeRegister8(AS7331_REG_CREG1, creg1Val);

    writeRegister8(AS7331_REG_OSR, 0x03U);
    delay(10);
    writeRegister8(AS7331_REG_OSR, 0x83U);
    delay(10);
}

float getAS7331_UVA() {
    return (float)getAS7331RawUVA() * FSR_UVA_BASE * calculateConversionFactor();
}

float getAS7331_UVB() {
    return (float)getAS7331RawUVB() * FSR_UVB_BASE * calculateConversionFactor();
}

float getAS7331_UVC() {
    return (float)getAS7331RawUVC() * FSR_UVC_BASE * calculateConversionFactor();
}

uint16_t getAS7331RawUVA() {
    return readRegister16LE(AS7331_REG_UVA);
}

uint16_t getAS7331RawUVB() {
    return readRegister16LE(AS7331_REG_UVB);
}

uint16_t getAS7331RawUVC() {
    return readRegister16LE(AS7331_REG_UVC);
}
