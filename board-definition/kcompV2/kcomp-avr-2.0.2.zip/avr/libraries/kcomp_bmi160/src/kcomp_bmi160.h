// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      bmi160
// @title       GY-BMI160 6-Axis IMU (Accel + Gyro)
// @targets     avr, esp32s3
// @bus         i2c (0x69 default, 0x68 alt)
// @timers      none (uses micros())
// @sram_bytes  ~12

#ifndef KCOMP_BMI160_H
#define KCOMP_BMI160_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Supported I2C addresses (0x69 when SDO is floating/HIGH, 0x68 when pulled LOW)
#define BMI160_ADDR_DEFAULT 0x69U
#define BMI160_ADDR_ALT     0x68U

// Sensor measurement and computed orientation angles
struct BMI160Data {
    float accelX;       // Linear acceleration X (m/s2)
    float accelY;       // Linear acceleration Y (m/s2)
    float accelZ;       // Linear acceleration Z (m/s2)
    float gyroX;        // Angular velocity X (deg/s)
    float gyroY;        // Angular velocity Y (deg/s)
    float gyroZ;        // Angular velocity Z (deg/s)
    float angleX;       // Pitch tilt angle (deg, gravity-referenced)
    float angleY;       // Roll tilt angle (deg, gravity-referenced)
    float angleZ;       // Yaw angle (deg, gyro-integrated; subject to drift)
    float temperature;  // Die temperature (deg C)
};

// Initialize the BMI160 (+/-2g accelerometer, +/-2000 deg/s gyroscope).
// Returns true if chip ID 0xD1 is verified.
bool initBMI160(uint8_t address = BMI160_ADDR_DEFAULT);

// Sample accelerometer, gyroscope, and temperature and update orientation angles.
BMI160Data getBMI160Data();

// Reset the integrated Z-axis (yaw) angle accumulator back to 0.0 degrees.
void resetBMI160Yaw();

#endif
