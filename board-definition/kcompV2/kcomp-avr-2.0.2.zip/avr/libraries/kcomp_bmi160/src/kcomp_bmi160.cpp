// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_bmi160.h"
#include <Wire.h>
#include <math.h>

// BMI160 registers, expected chip ID, and power commands
static constexpr uint8_t BMI160_EXPECTED_ID    = 0xD1U;
static constexpr uint8_t BMI160_REG_CHIP_ID    = 0x00U;
static constexpr uint8_t BMI160_REG_GYRO_DATA  = 0x0CU;
static constexpr uint8_t BMI160_REG_TEMP       = 0x20U;
static constexpr uint8_t BMI160_REG_CMD        = 0x7EU;

static constexpr uint8_t CMD_ACC_NORMAL = 0x11U;
static constexpr uint8_t CMD_GYR_NORMAL = 0x15U;
static constexpr uint8_t CMD_SOFT_RESET = 0xB6U;

// Scale factors for +/-2g (16384 LSB/g) and +/-2000 deg/s (16.4 LSB/dps)
static constexpr float ACC_LSB_PER_G   = 16384.0f;
static constexpr float GYR_LSB_PER_DPS = 16.4f;
static constexpr float GRAVITY_MPS2    = 9.81f;
static constexpr float RAD_TO_DEG_F    = 57.2957795f;
static constexpr float GYRO_DEADZONE   = 1.0f;

static uint8_t  bmi160Addr = BMI160_ADDR_DEFAULT;
static float    globalAngleZ = 0.0f;
static uint32_t lastTimeMicros = 0UL;

static float absFloat(float v) {
    return (v < 0.0f) ? -v : v;
}

static void writeReg(uint8_t reg, uint8_t val) {
    Wire.beginTransmission(bmi160Addr);
    Wire.write(reg);
    Wire.write(val);
    Wire.endTransmission();
}

static uint8_t readReg(uint8_t reg) {
    Wire.beginTransmission(bmi160Addr);
    Wire.write(reg);
    if (Wire.endTransmission(false) != 0) {
        return 0U;
    }
    if (Wire.requestFrom(bmi160Addr, (uint8_t)1U) != 1U) {
        return 0U;
    }
    return (uint8_t)Wire.read();
}

static void readBytes(uint8_t reg, uint8_t* buffer, uint8_t len) {
    Wire.beginTransmission(bmi160Addr);
    Wire.write(reg);
    if (Wire.endTransmission(false) != 0) {
        return;
    }
    const uint8_t received = Wire.requestFrom(bmi160Addr, len);
    for (uint8_t i = 0U; i < len; i++) {
        buffer[i] = (i < received) ? (uint8_t)Wire.read() : 0U;
    }
}

bool initBMI160(uint8_t address) {
    bmi160Addr = address;
    Wire.begin();
    delay(10);

    if (readReg(BMI160_REG_CHIP_ID) != BMI160_EXPECTED_ID) {
        writeReg(BMI160_REG_CMD, CMD_SOFT_RESET);
        delay(100);
        if (readReg(BMI160_REG_CHIP_ID) != BMI160_EXPECTED_ID) {
            return false;
        }
    }

    // Wake accelerometer and gyroscope from suspend mode
    writeReg(BMI160_REG_CMD, CMD_ACC_NORMAL);
    delay(50);
    writeReg(BMI160_REG_CMD, CMD_GYR_NORMAL);
    delay(100);

    globalAngleZ = 0.0f;
    lastTimeMicros = micros();
    return true;
}

void resetBMI160Yaw() {
    globalAngleZ = 0.0f;
}

BMI160Data getBMI160Data() {
    BMI160Data d = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
    uint8_t buffer[12] = {0U};

    const uint32_t nowMicros = micros();
    const float dt = (float)(nowMicros - lastTimeMicros) / 1000000.0f;
    lastTimeMicros = nowMicros;

    // Burst-read 12 bytes: Gyro X,Y,Z (6 bytes) followed by Accel X,Y,Z (6 bytes)
    readBytes(BMI160_REG_GYRO_DATA, buffer, 12U);

    const int16_t gx = (int16_t)(((uint16_t)buffer[1] << 8) | buffer[0]);
    const int16_t gy = (int16_t)(((uint16_t)buffer[3] << 8) | buffer[2]);
    const int16_t gz = (int16_t)(((uint16_t)buffer[5] << 8) | buffer[4]);
    d.gyroX = (float)gx / GYR_LSB_PER_DPS;
    d.gyroY = (float)gy / GYR_LSB_PER_DPS;
    d.gyroZ = (float)gz / GYR_LSB_PER_DPS;

    const int16_t ax = (int16_t)(((uint16_t)buffer[7] << 8) | buffer[6]);
    const int16_t ay = (int16_t)(((uint16_t)buffer[9] << 8) | buffer[8]);
    const int16_t az = (int16_t)(((uint16_t)buffer[11] << 8) | buffer[10]);
    d.accelX = ((float)ax / ACC_LSB_PER_G) * GRAVITY_MPS2;
    d.accelY = ((float)ay / ACC_LSB_PER_G) * GRAVITY_MPS2;
    d.accelZ = ((float)az / ACC_LSB_PER_G) * GRAVITY_MPS2;

    // Compute gravity-based pitch (angleX) and roll (angleY)
    d.angleX = atan2f(d.accelY, d.accelZ) * RAD_TO_DEG_F;
    d.angleY = atan2f(-d.accelX, sqrtf(d.accelY * d.accelY + d.accelZ * d.accelZ)) * RAD_TO_DEG_F;

    // Integrate Z rotation rate with a small deadzone to reduce stationary drift
    if (absFloat(d.gyroZ) > GYRO_DEADZONE && dt > 0.0f && dt < 5.0f) {
        globalAngleZ += d.gyroZ * dt;
    }
    d.angleZ = globalAngleZ;

    uint8_t tempBuf[2] = {0U, 0U};
    readBytes(BMI160_REG_TEMP, tempBuf, 2U);
    const int16_t rawTemp = (int16_t)(((uint16_t)tempBuf[1] << 8) | tempBuf[0]);
    d.temperature = 23.0f + ((float)rawTemp / 512.0f);

    return d;
}
