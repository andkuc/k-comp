// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      mq_sensors
// @title       MQ-Series Gas & Air Quality Sensors (MQ-2/3/7/135)
// @targets     avr, esp32s3
// @bus         analog (up to 4 ADC channels)
// @timers      none
// @sram_bytes  ~76

#ifndef KCOMP_MQ_SENSORS_H
#define KCOMP_MQ_SENSORS_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// Supported MQ sensor identifiers
enum MQSensorType : uint8_t {
    MQ_SENSOR_MQ2   = 2U,    // Combustible gas & smoke
    MQ_SENSOR_MQ3   = 3U,    // Alcohol vapor
    MQ_SENSOR_MQ7   = 7U,    // Carbon monoxide (CO)
    MQ_SENSOR_MQ135 = 135U   // Air quality / VOCs
};

// Normalized air/gas status categories derived from the 0..100% score
enum MQStatus : uint8_t {
    MQ_STATUS_CLEAN    = 0U,
    MQ_STATUS_MODERATE = 1U,
    MQ_STATUS_HIGH     = 2U
};

// Default clean-air Rs/R0 baseline ratios
#define MQ_RATIO_MQ2_DEFAULT   5.0f
#define MQ_RATIO_MQ3_DEFAULT   5.0f
#define MQ_RATIO_MQ7_DEFAULT   4.5f
#define MQ_RATIO_MQ135_DEFAULT 3.6f

// Register an MQ sensor on an analog input pin (returns false if slot table is full).
bool initMQSensor(uint8_t pin, uint8_t sensorType);

// Override the clean-air Rs/R0 sensitivity ratio before calling calibrateMQSensor().
void setMQSensorRatio(uint8_t pin, float customRatio);

// Sample clean air to establish baseline R0 using the active sensitivity ratio.
void calibrateMQSensor(uint8_t pin);

// Return normalized gas/air-quality intensity score (0..100%).
uint8_t getMQSensorScore(uint8_t pin);

// Return categorical status (MQ_STATUS_CLEAN, MQ_STATUS_MODERATE, or MQ_STATUS_HIGH).
uint8_t getMQSensorStatus(uint8_t pin);

#endif
