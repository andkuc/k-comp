// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_mq_sensors.h"

static constexpr uint8_t  MAX_MQ_SENSORS = 4U;
static constexpr uint8_t  MQ_NO_INDEX    = 255U;
static constexpr float    ADC_MAX_F      = 1023.0f;

struct MQChannelState {
    uint8_t pin;
    uint8_t type;
    float   r0;
    float   ratio;
    bool    active;
};

static MQChannelState mqSlots[MAX_MQ_SENSORS] = {
    {0U, 0U, 1.0f, MQ_RATIO_MQ2_DEFAULT, false},
    {0U, 0U, 1.0f, MQ_RATIO_MQ2_DEFAULT, false},
    {0U, 0U, 1.0f, MQ_RATIO_MQ2_DEFAULT, false},
    {0U, 0U, 1.0f, MQ_RATIO_MQ2_DEFAULT, false}
};

static uint8_t findMQSlot(uint8_t pin) {
    for (uint8_t i = 0U; i < MAX_MQ_SENSORS; i++) {
        if (mqSlots[i].active && mqSlots[i].pin == pin) {
            return i;
        }
    }
    return MQ_NO_INDEX;
}

static float defaultRatioForType(uint8_t sensorType) {
    switch (sensorType) {
        case MQ_SENSOR_MQ3:   return MQ_RATIO_MQ3_DEFAULT;
        case MQ_SENSOR_MQ7:   return MQ_RATIO_MQ7_DEFAULT;
        case MQ_SENSOR_MQ135: return MQ_RATIO_MQ135_DEFAULT;
        case MQ_SENSOR_MQ2:
        default:              return MQ_RATIO_MQ2_DEFAULT;
    }
}

static float readRsNormalized(uint8_t pin) {
    const int rawAdc = analogRead(pin);
    if (rawAdc <= 0) {
        return 999999.0f;
    }
    if (rawAdc >= 1023) {
        return 0.001f;
    }
    return (ADC_MAX_F / (float)rawAdc) - 1.0f;
}

bool initMQSensor(uint8_t pin, uint8_t sensorType) {
    const uint8_t existing = findMQSlot(pin);
    if (existing != MQ_NO_INDEX) {
        mqSlots[existing].type = sensorType;
        mqSlots[existing].ratio = defaultRatioForType(sensorType);
        mqSlots[existing].r0 = 1.0f;
        pinMode(pin, INPUT);
        return true;
    }

    for (uint8_t i = 0U; i < MAX_MQ_SENSORS; i++) {
        if (!mqSlots[i].active) {
            mqSlots[i].pin = pin;
            mqSlots[i].type = sensorType;
            mqSlots[i].r0 = 1.0f;
            mqSlots[i].ratio = defaultRatioForType(sensorType);
            mqSlots[i].active = true;
            pinMode(pin, INPUT);
            return true;
        }
    }
    return false;
}

void setMQSensorRatio(uint8_t pin, float customRatio) {
    const uint8_t idx = findMQSlot(pin);
    if (idx == MQ_NO_INDEX) {
        return;
    }
    // Keep ratio strictly above 1.0f to prevent division by zero in score mapping
    mqSlots[idx].ratio = (customRatio <= 1.01f) ? 1.01f : customRatio;
}

void calibrateMQSensor(uint8_t pin) {
    const uint8_t idx = findMQSlot(pin);
    if (idx == MQ_NO_INDEX) {
        return;
    }

    float sumRs = 0.0f;
    for (uint8_t i = 0U; i < 50U; i++) {
        sumRs += readRsNormalized(pin);
        delay(10);
    }
    const float avgRs = sumRs / 50.0f;
    mqSlots[idx].r0 = avgRs / mqSlots[idx].ratio;
}

uint8_t getMQSensorScore(uint8_t pin) {
    const uint8_t idx = findMQSlot(pin);
    if (idx == MQ_NO_INDEX || mqSlots[idx].r0 <= 0.00001f) {
        return 0U;
    }

    const float rs = readRsNormalized(pin);
    const float ratio = rs / mqSlots[idx].r0;
    const float baseline = mqSlots[idx].ratio;
    const float denom = baseline - 1.0f;
    if (denom <= 0.0001f) {
        return 0U;
    }

    const float rawScore = ((baseline - ratio) / denom) * 100.0f;
    if (rawScore <= 0.0f)   return 0U;
    if (rawScore >= 100.0f) return 100U;
    return (uint8_t)(rawScore + 0.5f);
}

uint8_t getMQSensorStatus(uint8_t pin) {
    const uint8_t score = getMQSensorScore(pin);
    if (score < 33U) return (uint8_t)MQ_STATUS_CLEAN;
    if (score < 66U) return (uint8_t)MQ_STATUS_MODERATE;
    return (uint8_t)MQ_STATUS_HIGH;
}
