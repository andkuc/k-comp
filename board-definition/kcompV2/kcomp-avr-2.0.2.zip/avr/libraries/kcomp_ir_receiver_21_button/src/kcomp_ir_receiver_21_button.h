// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      ir_receiver_21_button
// @title       21-Button Infrared Receiver (NEC Protocol)
// @targets     avr, esp32s3
// @bus         digital interrupt (D2 or D3 on AVR; any GPIO on ESP32-S3)
// @timers      none (uses micros() + external falling-edge interrupt)
// @sram_bytes  ~14

#ifndef KCOMP_IR_RECEIVER_21_BUTTON_H
#define KCOMP_IR_RECEIVER_21_BUTTON_H

#include <Arduino.h>
#include <stdbool.h>
#include <stdint.h>

// 21-button NEC remote command dictionary
#define IR_BTN_POWER    0xFFA25DUL
#define IR_BTN_MODE     0xFF629DUL
#define IR_BTN_MUTE     0xFFE21DUL
#define IR_BTN_PLAY     0xFF22DDUL
#define IR_BTN_PREV     0xFF02FDUL
#define IR_BTN_NEXT     0xFFC23DUL
#define IR_BTN_EQ       0xFFE01FUL
#define IR_BTN_VOL_DOWN 0xFFA857UL
#define IR_BTN_VOL_UP   0xFF906FUL
#define IR_BTN_0        0xFF6897UL
#define IR_BTN_RPT      0xFF9867UL
#define IR_BTN_USD      0xFFB04FUL
#define IR_BTN_1        0xFF30CFUL
#define IR_BTN_2        0xFF18E7UL
#define IR_BTN_3        0xFF7A85UL
#define IR_BTN_4        0xFF10EFUL
#define IR_BTN_5        0xFF38C7UL
#define IR_BTN_6        0xFF5AA5UL
#define IR_BTN_7        0xFF42BDUL
#define IR_BTN_8        0xFF4AB5UL
#define IR_BTN_9        0xFF52ADUL

// Attach the NEC decoder to an interrupt-capable pin (D2 or D3 on K-Comp V2).
void initIRReceiver(uint8_t interruptPin);

// Return true once when a complete 32-bit NEC command has been received.
bool isIRAvailable();

// Return the 32-bit NEC code captured by the most recent isIRAvailable() call.
uint32_t getIRCommand();

#endif
