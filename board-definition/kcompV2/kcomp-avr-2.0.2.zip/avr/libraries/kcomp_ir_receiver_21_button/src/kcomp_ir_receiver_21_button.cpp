// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_ir_receiver_21_button.h"

#if defined(ESP32)
  #define KCOMP_IR_ISR_ATTR IRAM_ATTR
#else
  #define KCOMP_IR_ISR_ATTR
#endif

static volatile uint32_t irRawData = 0UL;
static volatile bool     irReady = false;
static volatile uint8_t  irBitCount = 0U;
static volatile uint32_t lastEdgeUs = 0UL;

static uint32_t cachedCommand = 0UL;

static void KCOMP_IR_ISR_ATTR onIrFallingEdge() {
    const uint32_t nowUs = micros();
    const uint32_t deltaUs = nowUs - lastEdgeUs;
    lastEdgeUs = nowUs;

    if (deltaUs > 13000UL && deltaUs < 14000UL) {
        // NEC 9 ms mark + 4.5 ms space start header
        irRawData = 0UL;
        irBitCount = 0U;
        irReady = false;
    } else if (deltaUs > 2000UL && deltaUs < 2500UL) {
        // Logic '1' (~2.25 ms)
        irRawData = (irRawData << 1) | 1UL;
        irBitCount++;
    } else if (deltaUs > 800UL && deltaUs < 1500UL) {
        // Logic '0' (~1.125 ms)
        irRawData = (irRawData << 1);
        irBitCount++;
    } else {
        // Noise or repeat frame: reset bit collector
        irRawData = 0UL;
        irBitCount = 0U;
        irReady = false;
    }

    if (irBitCount == 32U) {
        irReady = true;
        irBitCount = 0U;
    }
}

void initIRReceiver(uint8_t interruptPin) {
    noInterrupts();
    irRawData = 0UL;
    irBitCount = 0U;
    irReady = false;
    lastEdgeUs = micros();
    cachedCommand = 0UL;
    interrupts();

    pinMode(interruptPin, INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(interruptPin), onIrFallingEdge, FALLING);
}

bool isIRAvailable() {
    if (!irReady) {
        return false;
    }
    noInterrupts();
    cachedCommand = irRawData;
    irReady = false;
    irRawData = 0UL;
    interrupts();
    return true;
}

uint32_t getIRCommand() {
    return cachedCommand;
}
