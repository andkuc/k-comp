@echo off
echo Initializing reset sequence
rem "C:\Program Files (x86)\Microchip\MCP2221CLI\MCP2221CLI.exe" -gpioW=-,-,-,low > nul
%~dp0\MCP2221CLI.exe -gpioW=-,-,-,low > nul
rem timeout /t 1
ping 127.0.0.1 -n 2 > nul
rem "C:\Program Files (x86)\Microchip\MCP2221CLI\MCP2221CLI.exe" -gpioW=-,-,-,high > nul
%~dp0\MCP2221CLI.exe -gpioW=-,-,-,high > nul
echo Reset sequence complete.
exit /b 0