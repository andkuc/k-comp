#ifndef _KCOMP_IR_TRANSMITTER_H
#define _KCOMP_IR_TRANSMITTER_H

#include <Arduino.h>

// ==============================================================================
// 🎛️ 1. GENERIC 21-BUTTON REMOTE (NEC Protocol)
// ==============================================================================
#define IR_BTN_POWER    0xFFA25D // ON/OFF
#define IR_BTN_MODE     0xFF629D
#define IR_BTN_MUTE     0xFFE21D
#define IR_BTN_PLAY     0xFF22DD // PLAY / PAUSE
#define IR_BTN_PREV     0xFF02FD // FAST BACKWARD
#define IR_BTN_NEXT     0xFFC23D // FAST FORWARD
#define IR_BTN_EQ       0xFFE01F
#define IR_BTN_VOL_DOWN 0xFFA857 // MINUS
#define IR_BTN_VOL_UP   0xFF906F // PLUS
#define IR_BTN_0        0xFF6897
#define IR_BTN_RPT      0xFF9867 // REPEAT / 100+
#define IR_BTN_USD      0xFFB04F // U/SD / 200+
#define IR_BTN_1        0xFF30CF
#define IR_BTN_2        0xFF18E7
#define IR_BTN_3        0xFF7A85
#define IR_BTN_4        0xFF10EF
#define IR_BTN_5        0xFF38C7
#define IR_BTN_6        0xFF5AA5
#define IR_BTN_7        0xFF42BD
#define IR_BTN_8        0xFF4AB5
#define IR_BTN_9        0xFF52AD

// ==============================================================================
// 📺 2. SONY TELEVISIONS (12-Bit SIRC Protocol)
// ==============================================================================
#define SONY_BTN_POWER    0xA90
#define SONY_BTN_MUTE     0x290
#define SONY_BTN_VOL_UP   0x490
#define SONY_BTN_VOL_DOWN 0xC90
#define SONY_BTN_CH_UP    0x090
#define SONY_BTN_CH_DOWN  0x890
#define SONY_BTN_INPUT    0xA50 // TV / Video Source
#define SONY_BTN_MENU     0x070
#define SONY_BTN_ENTER    0xA70
#define SONY_BTN_UP       0x2F0
#define SONY_BTN_DOWN     0xAF0
#define SONY_BTN_LEFT     0x2D0
#define SONY_BTN_RIGHT    0xCD0
#define SONY_BTN_1        0x010
#define SONY_BTN_2        0x810
#define SONY_BTN_3        0x410
#define SONY_BTN_4        0xC10
#define SONY_BTN_5        0x210
#define SONY_BTN_6        0xA10
#define SONY_BTN_7        0x610
#define SONY_BTN_8        0xE10
#define SONY_BTN_9        0x110
#define SONY_BTN_0        0x910

// ==============================================================================
// 🖥️ 3. SAMSUNG TELEVISIONS (32-Bit Protocol)
// ==============================================================================
#define SAMSUNG_BTN_POWER    0xE0E040BF
#define SAMSUNG_BTN_SOURCE   0xE0E0807F
#define SAMSUNG_BTN_MUTE     0xE0E0F00F
#define SAMSUNG_BTN_VOL_UP   0xE0E0E01F
#define SAMSUNG_BTN_VOL_DOWN 0xE0E0D02F
#define SAMSUNG_BTN_CH_UP    0xE0E048B7
#define SAMSUNG_BTN_CH_DOWN  0xE0E008F7
#define SAMSUNG_BTN_MENU     0xE0E058A7
#define SAMSUNG_BTN_RETURN   0xE0E01AE5
#define SAMSUNG_BTN_INFO     0xE0E0F807
#define SAMSUNG_BTN_UP       0xE0E006F9
#define SAMSUNG_BTN_DOWN     0xE0E08679
#define SAMSUNG_BTN_LEFT     0xE0E0A659
#define SAMSUNG_BTN_RIGHT    0xE0E046B9
#define SAMSUNG_BTN_ENTER    0xE0E016E9
#define SAMSUNG_BTN_PLAY     0xE0E0E21D
#define SAMSUNG_BTN_PAUSE    0xE0E052AD
#define SAMSUNG_BTN_STOP     0xE0E0629D
#define SAMSUNG_BTN_1        0xE0E020DF
#define SAMSUNG_BTN_2        0xE0E0A05F
#define SAMSUNG_BTN_3        0xE0E0609F
#define SAMSUNG_BTN_4        0xE0E010EF
#define SAMSUNG_BTN_5        0xE0E0906F
#define SAMSUNG_BTN_6        0xE0E050AF
#define SAMSUNG_BTN_7        0xE0E030CF
#define SAMSUNG_BTN_8        0xE0E0B04F
#define SAMSUNG_BTN_9        0xE0E0708F
#define SAMSUNG_BTN_0        0xE0E08877

// ==============================================================================
// 📽️ 4. ACER BEAMERS (NEC Extended Protocol)
// ==============================================================================
// Note: Acer codes can vary slightly between product lines, but this set 
// covers the foundational commands for most standard classroom/office models.
#define ACER_BTN_POWER       0x1CB920DF
#define ACER_BTN_SOURCE      0x1CB9A05F
#define ACER_BTN_MENU        0x1CB950AF
#define ACER_BTN_UP          0x1CB9807F
#define ACER_BTN_DOWN        0x1CB940BF
#define ACER_BTN_LEFT        0x1CB9C03F
#define ACER_BTN_RIGHT       0x1CB928D7
#define ACER_BTN_ENTER       0x1CB9A857
#define ACER_BTN_RESYNC      0x1CB9B14E
#define ACER_BTN_ASPECT      0x1CB906F9
#define ACER_BTN_HIDE        0x1CB9F10E


// ==============================================================================
// 🛠️ CORE FUNCTIONS
// ==============================================================================

// Setup the transmission pin
void initIRTransmitter(uint8_t pin);

// Emulation Functions
void send21Button(uint32_t hexCode);   // Standard 32-bit NEC protocol
void sendSonyTV(uint32_t hexCode);     // 12-bit SIRC protocol (repeats 3x automatically)
void sendSamsungTV(uint32_t hexCode);  // 32-bit Samsung protocol
void sendAcerBeamer(uint32_t hexCode); // 32-bit NEC (Extended)

#endif