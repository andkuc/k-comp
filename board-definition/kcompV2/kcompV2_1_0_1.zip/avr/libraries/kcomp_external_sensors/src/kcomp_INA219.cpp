#include "kcomp_INA219.h"
#include <Wire.h>

// --- INA219 Internal Register Map ---
#define INA219_REG_CONFIG      0x00
#define INA219_REG_SHUNT_VOLT  0x01
#define INA219_REG_BUS_VOLT    0x02
#define INA219_REG_POWER       0x03
#define INA219_REG_CURRENT     0x04
#define INA219_REG_CALIBRATION 0x05

// --- Configuration Masks (12-bit ADC + 128x Hardware Averaging Filter) ---
#define INA219_CFG_RESET       0x8000
#define INA219_CFG_STANDARD    0x3FFF // 32V Range, PGA /8 (+/-3.2A), 128x Averaging (~68ms)
#define INA219_CFG_HIGH_PREC   0x07FF // 16V Range, PGA /1 (+/-400mA), 128x Averaging (~68ms)

// --- Calibration Constant for 0.1 Ohm Shunt (Current LSB = 0.1 mA) ---
#define INA219_CAL_STANDARD    4096

// --- Encapsulated Module State (3 Bytes SRAM) ---
static uint8_t  _i2c_addr = INA219_ADDR_DEFAULT;
static uint16_t _active_config = INA219_CFG_STANDARD;
static bool     _overflow_flag = false;

// ==============================================================================
// INTERNAL I2C HELPERS (16-BIT BIG-ENDIAN)
// ==============================================================================
static void _writeReg16(uint8_t reg, uint16_t val) {
    Wire.beginTransmission(_i2c_addr);
    Wire.write(reg);
    Wire.write((uint8_t)(val >> 8));   // MSB first
    Wire.write((uint8_t)(val & 0xFF)); // LSB second
    Wire.endTransmission();
}

static uint16_t _readReg16(uint8_t reg) {
    Wire.beginTransmission(_i2c_addr);
    Wire.write(reg);
    if (Wire.endTransmission(false) != 0) {
        return 0;
    }
    if (Wire.requestFrom(_i2c_addr, (uint8_t)2) == 2) {
        uint16_t msb = Wire.read();
        uint16_t lsb = Wire.read();
        return (msb << 8) | lsb;
    }
    return 0;
}

// ==============================================================================
//  PUBLIC API
// ==============================================================================
bool initINA219(uint8_t address) {
    _i2c_addr = address;
    _active_config = INA219_CFG_STANDARD;
    Wire.begin();

    // 1. Check if the INA219 acknowledges on the I2C bus
    Wire.beginTransmission(_i2c_addr);
    if (Wire.endTransmission() != 0) {
        return false;
    }

    // 2. Perform a clean software reset
    _writeReg16(INA219_REG_CONFIG, INA219_CFG_RESET);
    delay(2);

    // 3. Load calibration for the standard 0.1 Ohm shunt (R100)
    _writeReg16(INA219_REG_CALIBRATION, INA219_CAL_STANDARD);

    // 4. Configure for 32V / 3.2A continuous measurement with 128x averaging
    _writeReg16(INA219_REG_CONFIG, _active_config);

    // Wait 70ms for the first 128-sample hardware average to complete
    delay(70);

    return true;
}

float getINA219BusVoltage_V(void) {
    uint16_t raw = _readReg16(INA219_REG_BUS_VOLT);

    // Bit 0 is the Math Overflow Flag (OVF)
    _overflow_flag = (raw & 0x0001) != 0;

    // Shift right by 3 bits to align the 13-bit voltage value (1 LSB = 4 mV)
    int16_t shifted = (int16_t)(raw >> 3);
    return (float)shifted * 0.004f;
}

float getINA219ShuntVoltage_mV(void) {
    int16_t raw = (int16_t)_readReg16(INA219_REG_SHUNT_VOLT);
    // 1 LSB = 10 uV = 0.01 mV
    return (float)raw * 0.01f;
}

float getINA219Current_mA(void) {
    int16_t raw = (int16_t)_readReg16(INA219_REG_CURRENT);
    // With Cal = 4096 and R = 0.1 Ohm, 1 LSB = 0.1 mA
    return (float)raw * 0.1f;
}

float getINA219Power_mW(void) {
    uint16_t raw = _readReg16(INA219_REG_POWER);
    // Power LSB = 20 * Current LSB = 2.0 mW
    return (float)raw * 2.0f;
}

void setINA219HighPrecision(bool enable) {
    _active_config = enable ? INA219_CFG_HIGH_PREC : INA219_CFG_STANDARD;
    _writeReg16(INA219_REG_CALIBRATION, INA219_CAL_STANDARD);
    _writeReg16(INA219_REG_CONFIG, _active_config);
    delay(70); // Allow first averaged conversion in new PGA mode to finish
}

bool isINA219Overflow(void) {
    uint16_t raw = _readReg16(INA219_REG_BUS_VOLT);
    _overflow_flag = (raw & 0x0001) != 0;
    return _overflow_flag;
}