#ifndef KCOMP_MOTOR_I2C_H
#define KCOMP_MOTOR_I2C_H

#include <Arduino.h>
#include <Wire.h>

// ==============================================================================
// HARDWARE CONSTANTS & ADDRESS DICTIONARY (Wemos TB6612FNG Shield)
// ==============================================================================
#define MOTOR_ADDR_0x2D  0x2D  // AD1: Bridged, AD0: Bridged
#define MOTOR_ADDR_0x2E  0x2E  // AD1: Bridged, AD0: Open
#define MOTOR_ADDR_0x2F  0x2F  // AD1: Open,    AD0: Bridged
#define MOTOR_ADDR_0x30  0x30  // AD1: Open,    AD0: Open (Factory Default)

// Motor Channel IDs (used for turnMotorAngle)
#define MOTOR_A  0  // Module 1, Left
#define MOTOR_B  1  // Module 1, Right
#define MOTOR_C  2  // Module 2, Left  (4WD)
#define MOTOR_D  3  // Module 2, Right (4WD)

// ==============================================================================
// INITIALIZATION & DIAGNOSTICS
// ==============================================================================

// Initializes the I2C bus for up to TWO motor modules (4 motors max).
// addr1: Primary module address (default 0x30) for Motors A & B.
// addr2: Secondary module address (e.g. 0x2D) for Motors C & D.
//        Leave at 0x00 for 2-motor mode.
// Returns true if all specified modules acknowledge on the I2C bus.
bool initMotorI2C(uint8_t addr1 = MOTOR_ADDR_0x30, uint8_t addr2 = 0x00);

// ==============================================================================
// BASIC MOTOR CONTROL (RAW LEVEL: -100 to +100, 0 = Short Brake)
// ==============================================================================

// Module 1 (Primary)
void setMotorA(int16_t speed);
void setMotorA(int16_t speed, uint16_t time_ms);

void setMotorB(int16_t speed);
void setMotorB(int16_t speed, uint16_t time_ms);

// Module 2 (Secondary) - Safely ignored if addr2 == 0x00
void setMotorC(int16_t speed);
void setMotorC(int16_t speed, uint16_t time_ms);

void setMotorD(int16_t speed);
void setMotorD(int16_t speed, uint16_t time_ms);

// Stops ALL initialized motors (A to D) immediately using Short Brake.
void stopMotors();

// ==============================================================================
// CHASSIS NAVIGATION (AUTO-SCALES 2WD / 4WD SKID-STEERING)
// ==============================================================================
// Left Side = Motor A (& C), Right Side = Motor B (& D).

// Endless movement
void driveForward(int16_t speed);
void driveBackward(int16_t speed);
void turnLeft(int16_t speed);   // Arc turn: Left stopped, Right forward
void turnRight(int16_t speed);  // Arc turn: Left forward, Right stopped
void pivotLeft(int16_t speed);  // Spin in place counter-clockwise
void pivotRight(int16_t speed); // Spin in place clockwise

// Time-limited movement (NON-BLOCKING; stopped automatically by motorUpdate())
void driveForward(int16_t speed, uint16_t time_ms);
void driveBackward(int16_t speed, uint16_t time_ms);
void turnLeft(int16_t speed, uint16_t time_ms);
void turnRight(int16_t speed, uint16_t time_ms);
void pivotLeft(int16_t speed, uint16_t time_ms);
void pivotRight(int16_t speed, uint16_t time_ms);

// ==============================================================================
// ANGLE-BASED CONTROL (OPEN-LOOP TIME ESTIMATION, NON-BLOCKING)
// ==============================================================================

// Calibrates chassis pivot timing: measure how many milliseconds your robot
// needs for one 90-degree pivot at 'ref_speed' (default: 450 ms at speed 60).
void setTurnCalibration(uint16_t ms_for_90_deg, int16_t ref_speed = 60);

// Pivots the chassis in place by an estimated angle in degrees (NON-BLOCKING).
// Positive degrees = turn RIGHT (CW), negative degrees = turn LEFT (CCW).
// Example: turnAngle(90); or turnAngle(-180, 70);
void turnAngle(int16_t degrees, int16_t speed = 60);

// Sets the no-load shaft RPM of your DC gearmotors at 100% speed (default: 200 RPM).
void setMotorRPM(uint16_t rpm_at_full_speed);

// Rotates a single motor shaft (MOTOR_A..MOTOR_D) by an estimated angle (NON-BLOCKING).
// Positive degrees = forward, negative degrees = reverse.
void turnMotorAngle(uint8_t motor_id, int16_t degrees, int16_t speed = 60);

// ==============================================================================
// HARDWARE COMPENSATION & BRAKING MODES
// ==============================================================================

// Flips the logical direction of individual motors in software (e.g., for mirrored
// chassis mounting so driveForward() moves straight without rewiring).
void setMotorInvert(bool invA, bool invB, bool invC = false, bool invD = false);

// Trims Left side (A/C) against Right side (B/D) during chassis navigation.
// Negative value throttles Left side; positive value throttles Right side (-100..+100).
void setMotorTrim(int8_t trim);

// Short-circuit brake (abrupt electronic stop).
void brakeMotors();

// Disconnects motors from power (smooth free-spin coasting).
void coastMotors();

// ==============================================================================
// SYSTEM MONITORING (STATUS & GETTERS)
// ==============================================================================

// Returns true if any timed or angle-based command is still running.
bool isMotorBusy();

// Returns current target speeds (-100 to +100).
int16_t getMotorASpeed();
int16_t getMotorBSpeed();
int16_t getMotorCSpeed();
int16_t getMotorDSpeed();

// ==============================================================================
// ASYNCHRONOUS MAINTENANCE (THE HEARTBEAT)
// ==============================================================================

// MUST be called continuously inside loop()!
// 1. Monitors non-blocking timers & angle turns and brakes motors when finished.
// 2. Periodically refreshes all initialized shields to prevent the Wemos standby bug.
void motorUpdate();

#endif