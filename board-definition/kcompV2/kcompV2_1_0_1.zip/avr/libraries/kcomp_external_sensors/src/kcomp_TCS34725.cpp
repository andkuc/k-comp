#include "kcomp_TCS34725_new.h"
#include <Wire.h>
#include <math.h>
#include <avr/pgmspace.h>

#define TCS34725_ADDRESS 0x29
#define COMMAND_BIT      0x80
#define AUTOINC_BIT      0x20 // Auto-Increment block read for 16-bit registers

#define REG_ENABLE       0x00
#define REG_ATIME        0x01
#define REG_CONTROL      0x0F
#define REG_ID           0x12
#define REG_STATUS       0x13
#define REG_CDATAL       0x14

// --- Internal Raw Channel State ---
static uint16_t _red   = 0;
static uint16_t _green = 0;
static uint16_t _blue  = 0;
static uint16_t _clear = 0;
static bool     _hasValidReading = false;

// --- Computed Perceptual HSV State ---
static uint16_t _hue        = 0; // 0..359 degrees
static uint8_t  _saturation = 0; // 0..100 %
static uint8_t  _brightness = 0; // 0..100 %

// --- Calibration & White-Balance State ---
static uint16_t _threshBlack = 250;
static uint16_t _threshWhite = 10000;

// Dark stray-light offsets (0 by default unless calibrateBlackLevel() is called)
static uint16_t _darkR = 0;
static uint16_t _darkG = 0;
static uint16_t _darkB = 0;

// Neutral gray/white channel ratios under the TCS34725 onboard LED (sum = 1000)
// Matches neutral metal/gray reflectance (~36.5% R, 37.0% G, 26.5% B) so gray stays achromatic.
static uint16_t _wbR = 365;
static uint16_t _wbG = 370;
static uint16_t _wbB = 265;

// ==============================================================================
// ⚡ LOW LEVEL HARDWARE I2C
// ==============================================================================
static void write8(uint8_t reg, uint8_t value) {
    Wire.beginTransmission(TCS34725_ADDRESS);
    Wire.write(COMMAND_BIT | reg);
    Wire.write(value);
    Wire.endTransmission();
}

static uint8_t read8(uint8_t reg) {
    Wire.beginTransmission(TCS34725_ADDRESS);
    Wire.write(COMMAND_BIT | reg);
    Wire.endTransmission(false);
    if (Wire.requestFrom((uint8_t)TCS34725_ADDRESS, (uint8_t)1) == 1) {
        return Wire.read();
    }
    return 0;
}

static void readRawChannels() {
    Wire.beginTransmission(TCS34725_ADDRESS);
    Wire.write(COMMAND_BIT | AUTOINC_BIT | REG_CDATAL);
    if (Wire.endTransmission(false) != 0) return;

    if (Wire.requestFrom((uint8_t)TCS34725_ADDRESS, (uint8_t)8) == 8) {
        uint16_t c = Wire.read() | ((uint16_t)Wire.read() << 8);
        uint16_t r = Wire.read() | ((uint16_t)Wire.read() << 8);
        uint16_t g = Wire.read() | ((uint16_t)Wire.read() << 8);
        uint16_t b = Wire.read() | ((uint16_t)Wire.read() << 8);

        if (!_hasValidReading) {
            _clear = c; _red = r; _green = g; _blue = b;
            _hasValidReading = true;
        } else {
            // 2-sample smoothing to prevent jitter
            _clear = (uint16_t)(((uint32_t)_clear + c) >> 1);
            _red   = (uint16_t)(((uint32_t)_red   + r) >> 1);
            _green = (uint16_t)(((uint32_t)_green + g) >> 1);
            _blue  = (uint16_t)(((uint32_t)_blue  + b) >> 1);
        }
    }
}

// ==============================================================================
// 🧠 PERCEPTUAL HSV TRANSFORMATION ENGINE
// ==============================================================================
static void updatePerceptualHSV() {
    // 1. Subtract optional calibrated dark offset
    int32_t rClean = (int32_t)_red   - _darkR; if (rClean < 0) rClean = 0;
    int32_t gClean = (int32_t)_green - _darkG; if (gClean < 0) gClean = 0;
    int32_t bClean = (int32_t)_blue  - _darkB; if (bClean < 0) bClean = 0;

    // 2. White-balance channel normalization
    int32_t rW = (rClean * 1000L) / _wbR;
    int32_t gW = (gClean * 1000L) / _wbG;
    int32_t bW = (bClean * 1000L) / _wbB;

    // 3. Find Max, Min, and Chroma Delta
    int32_t cMax = rW;
    if (gW > cMax) cMax = gW;
    if (bW > cMax) cMax = bW;

    int32_t cMin = rW;
    if (gW < cMin) cMin = gW;
    if (bW < cMin) cMin = bW;

    int32_t delta = cMax - cMin;

    // 4. Calculate Diffuse Surface Brightness / Value (0..100%)
    uint32_t diffuseWhite = (uint32_t)_threshBlack * 10UL;
    if (diffuseWhite > _threshWhite) diffuseWhite = _threshWhite;
    if (diffuseWhite <= _threshBlack) diffuseWhite = _threshBlack + 1000UL;

    if (_clear <= _threshBlack) {
        _brightness = 0;
    } else if (_clear >= diffuseWhite) {
        _brightness = 100;
    } else {
        uint32_t span = diffuseWhite - _threshBlack;
        uint32_t norm = ((uint32_t)(_clear - _threshBlack) * 100UL) / span;
        float vLin = (float)norm / 100.0f;
        uint8_t vGamma = (uint8_t)(sqrt(vLin) * 100.0f + 0.5f);
        _brightness = (vGamma > 100) ? 100 : vGamma;
    }

    // 5. Calculate True White-Balanced Saturation (0..100%)
    if (cMax <= 10 || delta <= 0) {
        _saturation = 0;
        _hue = 0;
        return;
    }

    int32_t satPct = (delta * 100L) / cMax;
    if (satPct < 0)   satPct = 0;
    if (satPct > 100) satPct = 100;
    _saturation = (uint8_t)satPct;

    // 6. Calculate Hue Angle (0..359 degrees)
    int32_t h = 0;
    if (cMax == rW) {
        h = (60L * (gW - bW)) / delta;
        if (h < 0) h += 360;
    } else if (cMax == gW) {
        h = 120L + (60L * (bW - rW)) / delta;
    } else {
        h = 240L + (60L * (rW - gW)) / delta;
    }
    if (h < 0)    h += 360;
    if (h >= 360) h -= 360;
    _hue = (uint16_t)h;
}

// ==============================================================================
// 🛠️ CORE PUBLIC FUNCTIONS
// ==============================================================================
bool initColorSensor() {
    Wire.begin();
    uint8_t id = read8(REG_ID);
    if (id != 0x44 && id != 0x4D) return false;

    write8(REG_ATIME, COLOR_TIME_101MS);
    write8(REG_CONTROL, COLOR_GAIN_4X);
    write8(REG_ENABLE, 0x01);
    delay(3);
    write8(REG_ENABLE, 0x03);
    return true;
}

void setColorIntegrationTime(uint8_t timeSetting) {
    write8(REG_ATIME, timeSetting);
    _hasValidReading = false;
}

void setColorGain(uint8_t gainSetting) {
    write8(REG_CONTROL, gainSetting & 0x03);
    _hasValidReading = false;
}

void calibrateColorEngine(uint16_t blackThreshold, uint16_t whiteThreshold) {
    _threshBlack = blackThreshold;
    _threshWhite = (whiteThreshold > blackThreshold) ? whiteThreshold : (blackThreshold + 1000);
}

void calibrateBlackLevel() {
    _hasValidReading = false;
    pollColorSensor();
    uint32_t sumR = _red, sumG = _green, sumB = _blue, sumC = _clear;
    for (uint8_t i = 0; i < 3; i++) {
        delay(30);
        readRawChannels();
        sumR += _red; sumG += _green; sumB += _blue; sumC += _clear;
    }
    _darkR = (uint16_t)(sumR >> 2);
    _darkG = (uint16_t)(sumG >> 2);
    _darkB = (uint16_t)(sumB >> 2);
    uint16_t avgC = (uint16_t)(sumC >> 2);
    _threshBlack = avgC + (avgC >> 1) + 40;
}

void calibrateWhiteBalance() {
    _hasValidReading = false;
    pollColorSensor();
    uint32_t sumR = _red, sumG = _green, sumB = _blue, sumC = _clear;
    for (uint8_t i = 0; i < 3; i++) {
        delay(30);
        readRawChannels();
        sumR += _red; sumG += _green; sumB += _blue; sumC += _clear;
    }
    uint32_t r = sumR >> 2;
    uint32_t g = sumG >> 2;
    uint32_t b = sumB >> 2;
    uint32_t c = sumC >> 2;
    uint32_t rgbSum = r + g + b;

    if (rgbSum > 100) {
        _wbR = (uint16_t)((r * 1000UL) / rgbSum);
        _wbG = (uint16_t)((g * 1000UL) / rgbSum);
        _wbB = (uint16_t)((b * 1000UL) / rgbSum);
    }
    if (c > _threshBlack + 500) {
        _threshWhite = (uint16_t)((c * 85UL) / 100UL);
    }
}

void pollColorSensor() {
    if (!_hasValidReading) {
        unsigned long start = millis();
        while (!(read8(REG_STATUS) & 0x01)) {
            if (millis() - start > 160) break;
        }
        readRawChannels();
        updatePerceptualHSV();
        return;
    }

    if (read8(REG_STATUS) & 0x01) {
        readRawChannels();
        updatePerceptualHSV();
    }
}

// ==============================================================================
// 📊 GETTERS
// ==============================================================================
uint16_t getRed()        { return _red; }
uint16_t getGreen()      { return _green; }
uint16_t getBlue()       { return _blue; }
uint16_t getClear()      { return _clear; }
uint16_t getHue()        { return _hue; }
uint8_t  getSaturation() { return _saturation; }
uint8_t  getBrightness() { return _brightness; }

uint16_t getLux() {
    float lux = (-0.32466F * _red) + (1.57837F * _green) + (-0.73191F * _blue);
    return (lux > 0.0F) ? (uint16_t)lux : 0;
}

uint16_t getColorTemperature() {
    float X = -0.14282F * _red + 1.54924F * _green - 0.95641F * _blue;
    float Y = -0.32466F * _red + 1.57837F * _green - 0.73191F * _blue;
    float Z = -0.68202F * _red + 0.77073F * _green + 0.56332F * _blue;
    float sum = X + Y + Z;
    if (sum <= 0.001F) return 0;
    float xc = X / sum;
    float yc = Y / sum;
    float denom = 0.1858F - yc;
    if (fabs(denom) < 0.0001F) return 0;
    float n = (xc - 0.3320F) / denom;
    float cct = 449.0F * (n * n * n) + 3525.0F * (n * n) + 6823.3F * n + 5520.33F;
    return (cct > 0.0F) ? (uint16_t)cct : 0;
}

// ==============================================================================
// 🎯 HUMAN-PERCEPTUAL COLOR CLASSIFIER (HSV + Silicon Channel Ratios)
// ==============================================================================
uint8_t estimateColor() {
    if (!_hasValidReading) {
        pollColorSensor();
    }

    // 1. PURE BLACK / NO OBJECT
    if (_clear < _threshBlack) {
        return COLOR_BLACK;
    }

    uint16_t h = _hue;        // 0..359 deg
    uint8_t  s = _saturation; // 0..100 % (true white-balanced saturation)
    uint8_t  v = _brightness; // 0..100 % (diffuse reflectance)

    // Raw channel percentages (sum = 100%)
    uint32_t rgbSum = (uint32_t)_red + _green + _blue;
    if (rgbSum == 0) return COLOR_BLACK;
    uint8_t rPct = (uint8_t)(((uint32_t)_red   * 100UL) / rgbSum);
    uint8_t gPct = (uint8_t)(((uint32_t)_green * 100UL) / rgbSum);
    uint8_t bPct = (uint8_t)(((uint32_t)_blue  * 100UL) / rgbSum);

    // 2. ACHROMATIC CHECK (White vs. Grey / Metal)
    //    Catches low-saturation surfaces AND neutral metallic/gray surfaces
    //    where no single RGB channel strongly dominates.
    bool isNeutralGrayBalance = (rPct >= 30 && rPct <= 42 &&
                                 gPct >= 31 && gPct <= 43 &&
                                 bPct >= 21 && bPct <= 34 &&
                                 s < 30);

    if (s < 24 || isNeutralGrayBalance || (_clear >= _threshWhite && s < 28)) {
        if (_clear >= _threshWhite || (v >= 85 && s < 18)) {
            return COLOR_WHITE;
        }
        return COLOR_GREY;
    }

    // 3. CHROMATIC CLASSIFICATION
    // --------------------------------------------------------------------------
    // A. RED / DARK RED / PINK SECTOR (295°..360° and 0°..15°)
    // --------------------------------------------------------------------------
    if (h >= 295 || h < 15) {
        // Very dark reflectance with strong red dominance -> Dark Red
        if (v < 30 && rPct >= 50 && bPct <= 19) {
            return COLOR_DARK_RED;
        }

        // PINK vs. RED separation:
        // Pure Red on the TCS34725 has extreme Red dominance (rPct >= 62%, s >= 70%),
        // sits strictly at h = 0°..12° (Green >= Blue), and strongly absorbs Blue (bPct <= 16%).
        // Any rose/magenta shift (h >= 295°), elevated Blue/Green reflection (bPct >= 17%),
        // or moderate Red saturation (rPct < 62% or s < 70%) is Pink!
        if (h >= 295 || bPct >= gPct || bPct >= 17 || rPct < 62 || s < 70) {
            return COLOR_PINK;
        }

        if (v < 36) {
            return COLOR_DARK_RED;
        }
        return COLOR_RED;
    }

    // --------------------------------------------------------------------------
    // B. ORANGE / BROWN / CORAL-PINK SECTOR (15°..34°)
    // --------------------------------------------------------------------------
    if (h >= 15 && h < 34) {
        // Warm Pink / Coral / Salmon (high white dilution or elevated blue floor)
        if (h < 25 && (bPct >= 18 || (s < 58 && v >= 58))) {
            return COLOR_PINK;
        }

        // Warm golden yellow where Green is already strong (gPct >= 36%) -> Yellow
        if (h >= 27 && gPct >= 36 && bPct <= 16 && v >= 45) {
            return COLOR_YELLOW;
        }

        // True Brown requires a genuine warm red-orange shift (rPct >= 44%)
        // and absorbed blue (bPct <= 20%) at lower brightness or saturation.
        if (rPct >= 44 && bPct <= 20 && (v < 52 || s < 60)) {
            return COLOR_BROWN;
        }

        // If a muted surface landed here without strong red dominance, it is Grey/Metal
        if (rPct < 44 || s < 32) {
            return COLOR_GREY;
        }

        return COLOR_ORANGE;
    }

    // --------------------------------------------------------------------------
    // C. YELLOW / LIGHT YELLOW / LIGHT GREEN BOUNDARY (34°..65°)
    // --------------------------------------------------------------------------
    if (h >= 34 && h < 65) {
        // If Green count is >= Red count, it is Light/Lime Green
        if (_green >= _red || h >= 60) {
            return COLOR_LIME_GREEN;
        }

        // Pale / Pastel Yellow has lower saturation
        if (s < 52 && bPct >= 16) {
            return COLOR_LIGHT_YELLOW;
        }

        return COLOR_YELLOW;
    }

    // --------------------------------------------------------------------------
    // D. LIME (LIGHT) GREEN / GREEN / FOREST GREEN SECTOR (65°..168°)
    // --------------------------------------------------------------------------
    if (h >= 65 && h < 168) {
        if (v < 32) {
            return COLOR_FOREST_GREEN;
        }

        // Yellow-Green (65°..118°) OR bright/pastel Light Green -> Lime Green
        if (h < 118 || s < 52 || v >= 75) {
            return COLOR_LIME_GREEN;
        }

        if (v < 42 && s < 56) {
            return COLOR_FOREST_GREEN;
        }

        return COLOR_GREEN;
    }

    // --------------------------------------------------------------------------
    // E. CYAN / LIGHT BLUE / BLUE / NAVY BLUE SECTOR (168°..252°)
    // --------------------------------------------------------------------------
    if (h >= 168 && h < 252) {
        if (v < 32) {
            return COLOR_NAVY_BLUE;
        }

        if (h < 208) {
            if (h < 186 && s >= 58) return COLOR_CYAN;
            return COLOR_LIGHT_BLUE;
        }

        if (s < 52 || v >= 78) {
            return COLOR_LIGHT_BLUE;
        }
        if (v < 40 && s < 58) {
            return COLOR_NAVY_BLUE;
        }
        return COLOR_BLUE;
    }

    // --------------------------------------------------------------------------
    // F. PURPLE / VIOLET SECTOR (252°..295°)
    // --------------------------------------------------------------------------
    if (h >= 252 && h < 295) {
        if (v < 30 && h < 272) {
            return COLOR_NAVY_BLUE;
        }
        if (h >= 282 && rPct > bPct) {
            return COLOR_PINK;
        }
        return COLOR_PURPLE;
    }

    return COLOR_UNKNOWN;
}

const char* getColorName(uint8_t colorCode) {
    switch(colorCode) {
        case COLOR_BLACK:        return "Black";
        case COLOR_WHITE:        return "White";
        case COLOR_GREY:         return "Grey";
        case COLOR_RED:          return "Red";
        case COLOR_DARK_RED:     return "Dark Red";
        case COLOR_GREEN:        return "Green";
        case COLOR_FOREST_GREEN: return "Forest Green";
        case COLOR_LIME_GREEN:   return "Lime Green";
        case COLOR_BLUE:         return "Blue";
        case COLOR_NAVY_BLUE:    return "Navy Blue";
        case COLOR_LIGHT_BLUE:   return "Light Blue";
        case COLOR_YELLOW:       return "Yellow";
        case COLOR_LIGHT_YELLOW: return "Light Yellow";
        case COLOR_ORANGE:       return "Orange";
        case COLOR_PINK:         return "Pink";
        case COLOR_BROWN:        return "Brown";
        case COLOR_PURPLE:       return "Purple";
        case COLOR_CYAN:         return "Cyan";
        default:                 return "Unknown";
    }
}