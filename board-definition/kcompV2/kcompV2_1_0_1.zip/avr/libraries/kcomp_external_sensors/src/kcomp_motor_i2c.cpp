#include "kcomp_motor_i2c.h"

// --- Wemos D1 Mini Motor Shield V1.0.0 Protocol Constants ---
#define WEMOS_MOTOR_A       0x00
#define WEMOS_MOTOR_B       0x01
#define WEMOS_CMD_SET_MOTOR 0x10

#define WEMOS_SHORT_BRAKE   0x00
#define WEMOS_CCW           0x01
#define WEMOS_CW            0x02
#define WEMOS_STOP_COAST    0x03
#define WEMOS_STANDBY       0x04

#define WEMOS_DEFAULT_FREQ  1000UL  // 1 kHz PWM frequency
#define WEMOS_HEARTBEAT_MS  2000UL  // Keep-alive interval (< 10s Wemos timeout)

// --- Encapsulated Module State (57 Bytes SRAM total) ---
static uint8_t  _addr[2]         = { MOTOR_ADDR_0x30, 0x00 };
static int16_t  _speed[4]        = { 0, 0, 0, 0 };
static uint8_t  _mode[4]         = { WEMOS_SHORT_BRAKE, WEMOS_SHORT_BRAKE,
                                     WEMOS_SHORT_BRAKE, WEMOS_SHORT_BRAKE };
static bool     _invert[4]       = { false, false, false, false };

static bool     _timer_active[4] = { false, false, false, false };
static uint32_t _timer_start[4]  = { 0, 0, 0, 0 };
static uint16_t _timer_dur[4]    = { 0, 0, 0, 0 };

static int8_t   _trim            = 0;
static uint16_t _turn_ms_per_90  = 450; // Default: 450 ms for 90 deg at speed 60
static int16_t  _turn_ref_speed  = 60;
static uint16_t _motor_rpm       = 200; // Default: 200 RPM (yellow TT gearmotor)
static uint32_t _last_heartbeat  = 0;

// ==============================================================================
// LOW-LEVEL I2C TRANSPORT (Wemos TB6612FNG V1.0.0 4-Byte Protocol)
// ==============================================================================
static bool _pingAddress(uint8_t addr) {
    Wire.beginTransmission(addr);
    return (Wire.endTransmission() == 0);
}

// ==============================================================================
// LOW-LEVEL I2C TRANSPORT (Wemos TB6612FNG V1.0.0 4-Byte Protocol)
// ==============================================================================
static uint8_t _setShieldFreq(uint8_t addr, uint32_t freq) {
    if (addr == 0x00) return 4;
    Wire.beginTransmission(addr);
    Wire.write((uint8_t)((freq >> 24) & 0x0F)); // High nibble 0x0 = Set Freq
    Wire.write((uint8_t)((freq >> 16) & 0xFF));
    Wire.write((uint8_t)((freq >> 8)  & 0xFF));
    Wire.write((uint8_t)(freq & 0xFF));
    uint8_t err = Wire.endTransmission();       // Returns 0 on ACK
    delay(2);                                   // Pacing for STM32 I2C state machine
    return err;
}

static void _sendPacket(uint8_t motor_idx, uint8_t dir, uint16_t pwm_val) {
    uint8_t shield_idx = (motor_idx < 2) ? 0 : 1;
    uint8_t addr = _addr[shield_idx];
    if (addr == 0x00) return;

    uint8_t channel = (motor_idx & 0x01); // 0 = A/C, 1 = B/D
    if (pwm_val > 10000) pwm_val = 10000;

    Wire.beginTransmission(addr);
    Wire.write((uint8_t)(channel | WEMOS_CMD_SET_MOTOR));
    Wire.write(dir);
    Wire.write((uint8_t)(pwm_val >> 8));
    Wire.write((uint8_t)(pwm_val & 0xFF));
    Wire.endTransmission();
    delay(2); // Prevent STM32 lockup on back-to-back Motor A + B packets
}
// ==============================================================================
// INTERNAL HELPERS
// ==============================================================================
static int16_t _clampSpeed(int16_t speed) {
    if (speed > 100)  return 100;
    if (speed < -100) return -100;
    return speed;
}

static void _applyMotor(uint8_t motor_idx, int16_t speed, bool coast_if_zero = false) {
    if (motor_idx > 3) return;
    if (motor_idx >= 2 && _addr[1] == 0x00) return;

    speed = _clampSpeed(speed);
    _speed[motor_idx] = speed;

    int16_t hw_speed = _invert[motor_idx] ? -speed : speed;

    if (hw_speed > 0) {
        _mode[motor_idx] = WEMOS_CW;
        _sendPacket(motor_idx, WEMOS_CW, (uint16_t)hw_speed * 100U);
    } else if (hw_speed < 0) {
        _mode[motor_idx] = WEMOS_CCW;
        _sendPacket(motor_idx, WEMOS_CCW, (uint16_t)(-hw_speed) * 100U);
    } else {
        uint8_t stop_mode = coast_if_zero ? WEMOS_STOP_COAST : WEMOS_SHORT_BRAKE;
        _mode[motor_idx] = stop_mode;
        _sendPacket(motor_idx, stop_mode, 0);
    }
}

static void _setMotorTimed(uint8_t motor_idx, int16_t speed, uint16_t time_ms) {
    if (motor_idx > 3) return;
    if (motor_idx >= 2 && _addr[1] == 0x00) return;

    _applyMotor(motor_idx, speed);
    if (time_ms > 0) {
        _timer_active[motor_idx] = true;
        _timer_start[motor_idx]  = millis();
        _timer_dur[motor_idx]    = time_ms;
    } else {
        _timer_active[motor_idx] = false;
    }
}

static void _setLeftSide(int16_t speed, uint16_t time_ms, bool apply_trim) {
    int16_t s = _clampSpeed(speed);
    if (apply_trim && _trim < 0) {
        s = (int16_t)(((int32_t)s * (100 + _trim)) / 100L);
    }
    _setMotorTimed(MOTOR_A, s, time_ms);
    if (_addr[1] != 0x00) {
        _setMotorTimed(MOTOR_C, s, time_ms);
    }
}

static void _setRightSide(int16_t speed, uint16_t time_ms, bool apply_trim) {
    int16_t s = _clampSpeed(speed);
    if (apply_trim && _trim > 0) {
        s = (int16_t)(((int32_t)s * (100 - _trim)) / 100L);
    }
    _setMotorTimed(MOTOR_B, s, time_ms);
    if (_addr[1] != 0x00) {
        _setMotorTimed(MOTOR_D, s, time_ms);
    }
}

// ==============================================================================
// INITIALIZATION
// ==============================================================================
bool initMotorI2C(uint8_t addr1, uint8_t addr2) {
    _addr[0] = addr1;
    _addr[1] = addr2;

    Wire.begin();
    #if defined(WIRE_HAS_TIMEOUT)
        Wire.setWireTimeout(25000, true); // Auto-reset TWI hardware if bus locks LOW
    #endif

    delay(150); // Allow STM32 on shield to complete power-on boot

    // Probe using a valid 4-byte Set-Frequency packet (NEVER a 0-byte ping!)
    if (addr1 == 0x00 || _setShieldFreq(addr1, WEMOS_DEFAULT_FREQ) != 0) {
        _addr[0] = 0x00;
        _addr[1] = 0x00;
        return false;
    }

    if (addr2 != 0x00 && _setShieldFreq(addr2, WEMOS_DEFAULT_FREQ) != 0) {
        _addr[1] = 0x00;
        return false;
    }

    delay(50); // Factory STM32 firmware needs ~50ms after freq config
    stopMotors();
    _last_heartbeat = millis();
    return true;
}

// ==============================================================================
// BASIC MOTOR CONTROL
// ==============================================================================
void setMotorA(int16_t speed)                   { _setMotorTimed(MOTOR_A, speed, 0); }
void setMotorA(int16_t speed, uint16_t time_ms) { _setMotorTimed(MOTOR_A, speed, time_ms); }

void setMotorB(int16_t speed)                   { _setMotorTimed(MOTOR_B, speed, 0); }
void setMotorB(int16_t speed, uint16_t time_ms) { _setMotorTimed(MOTOR_B, speed, time_ms); }

void setMotorC(int16_t speed)                   { _setMotorTimed(MOTOR_C, speed, 0); }
void setMotorC(int16_t speed, uint16_t time_ms) { _setMotorTimed(MOTOR_C, speed, time_ms); }

void setMotorD(int16_t speed)                   { _setMotorTimed(MOTOR_D, speed, 0); }
void setMotorD(int16_t speed, uint16_t time_ms) { _setMotorTimed(MOTOR_D, speed, time_ms); }

void stopMotors() {
    brakeMotors();
}

// ==============================================================================
// CHASSIS NAVIGATION (AUTO-SCALING 2WD / 4WD)
// ==============================================================================
void driveForward(int16_t speed) {
    int16_t s = abs(_clampSpeed(speed));
    _setLeftSide(s, 0, true);
    _setRightSide(s, 0, true);
}

void driveBackward(int16_t speed) {
    int16_t s = -abs(_clampSpeed(speed));
    _setLeftSide(s, 0, true);
    _setRightSide(s, 0, true);
}

void turnLeft(int16_t speed) {
    int16_t s = abs(_clampSpeed(speed));
    _setLeftSide(0, 0, false);
    _setRightSide(s, 0, false);
}

void turnRight(int16_t speed) {
    int16_t s = abs(_clampSpeed(speed));
    _setLeftSide(s, 0, false);
    _setRightSide(0, 0, false);
}

void pivotLeft(int16_t speed) {
    int16_t s = abs(_clampSpeed(speed));
    _setLeftSide(-s, 0, false);
    _setRightSide(s, 0, false);
}

void pivotRight(int16_t speed) {
    int16_t s = abs(_clampSpeed(speed));
    _setLeftSide(s, 0, false);
    _setRightSide(-s, 0, false);
}

// Non-blocking timed variants
void driveForward(int16_t speed, uint16_t time_ms) {
    int16_t s = abs(_clampSpeed(speed));
    _setLeftSide(s, time_ms, true);
    _setRightSide(s, time_ms, true);
}

void driveBackward(int16_t speed, uint16_t time_ms) {
    int16_t s = -abs(_clampSpeed(speed));
    _setLeftSide(s, time_ms, true);
    _setRightSide(s, time_ms, true);
}

void turnLeft(int16_t speed, uint16_t time_ms) {
    int16_t s = abs(_clampSpeed(speed));
    _setLeftSide(0, time_ms, false);
    _setRightSide(s, time_ms, false);
}

void turnRight(int16_t speed, uint16_t time_ms) {
    int16_t s = abs(_clampSpeed(speed));
    _setLeftSide(s, time_ms, false);
    _setRightSide(0, time_ms, false);
}

void pivotLeft(int16_t speed, uint16_t time_ms) {
    int16_t s = abs(_clampSpeed(speed));
    _setLeftSide(-s, time_ms, false);
    _setRightSide(s, time_ms, false);
}

void pivotRight(int16_t speed, uint16_t time_ms) {
    int16_t s = abs(_clampSpeed(speed));
    _setLeftSide(s, time_ms, false);
    _setRightSide(-s, time_ms, false);
}

// ==============================================================================
// ANGLE-BASED CONTROL (OPEN-LOOP CALIBRATED TIMING)
// ==============================================================================
void setTurnCalibration(uint16_t ms_for_90_deg, int16_t ref_speed) {
    if (ms_for_90_deg > 0) {
        _turn_ms_per_90 = ms_for_90_deg;
    }
    int16_t s = abs(_clampSpeed(ref_speed));
    if (s >= 15) {
        _turn_ref_speed = s;
    }
}

void turnAngle(int16_t degrees, int16_t speed) {
    if (degrees == 0) {
        stopMotors();
        return;
    }

    int16_t s = abs(_clampSpeed(speed));
    if (s < 15) s = 15; // Minimum torque floor to overcome static friction

    uint32_t absDeg = (degrees < 0) ? (uint32_t)(-degrees) : (uint32_t)degrees;
    uint32_t duration = (absDeg * (uint32_t)_turn_ms_per_90 * (uint32_t)_turn_ref_speed)
                        / (90UL * (uint32_t)s);

    if (duration == 0)     duration = 1;
    if (duration > 65535U) duration = 65535U;

    if (degrees > 0) {
        pivotRight(s, (uint16_t)duration);
    } else {
        pivotLeft(s, (uint16_t)duration);
    }
}

void setMotorRPM(uint16_t rpm_at_full_speed) {
    if (rpm_at_full_speed > 0) {
        _motor_rpm = rpm_at_full_speed;
    }
}

void turnMotorAngle(uint8_t motor_id, int16_t degrees, int16_t speed) {
    if (motor_id > 3) return;
    if (degrees == 0) {
        _setMotorTimed(motor_id, 0, 0);
        return;
    }

    int16_t s = abs(_clampSpeed(speed));
    if (s < 15) s = 15;

    uint32_t absDeg = (degrees < 0) ? (uint32_t)(-degrees) : (uint32_t)degrees;
    // ms = (deg / 360) * (60000 / rpm) * (100 / speed) = (deg * 50000) / (3 * rpm * speed)
    uint32_t duration = (absDeg * 50000UL) / (3UL * (uint32_t)_motor_rpm * (uint32_t)s);

    if (duration == 0)     duration = 1;
    if (duration > 65535U) duration = 65535U;

    int16_t dirSpeed = (degrees > 0) ? s : -s;
    _setMotorTimed(motor_id, dirSpeed, (uint16_t)duration);
}

// ==============================================================================
// HARDWARE COMPENSATION & BRAKING
// ==============================================================================
void setMotorInvert(bool invA, bool invB, bool invC, bool invD) {
    _invert[MOTOR_A] = invA;
    _invert[MOTOR_B] = invB;
    _invert[MOTOR_C] = invC;
    _invert[MOTOR_D] = invD;
}

void setMotorTrim(int8_t trim) {
    if (trim > 100)  trim = 100;
    if (trim < -100) trim = -100;
    _trim = trim;
}

void brakeMotors() {
    for (uint8_t i = 0; i < 4; i++) {
        _timer_active[i] = false;
        _applyMotor(i, 0, false);
    }
}

void coastMotors() {
    for (uint8_t i = 0; i < 4; i++) {
        _timer_active[i] = false;
        _applyMotor(i, 0, true);
    }
}

// ==============================================================================
// SYSTEM MONITORING
// ==============================================================================
bool isMotorBusy() {
    return _timer_active[0] || _timer_active[1] || _timer_active[2] || _timer_active[3];
}

int16_t getMotorASpeed() { return _speed[MOTOR_A]; }
int16_t getMotorBSpeed() { return _speed[MOTOR_B]; }
int16_t getMotorCSpeed() { return _speed[MOTOR_C]; }
int16_t getMotorDSpeed() { return _speed[MOTOR_D]; }

// ==============================================================================
// ASYNCHRONOUS MAINTENANCE (HEARTBEAT & NON-BLOCKING TIMERS)
// ==============================================================================
void motorUpdate() {
    uint32_t now = millis();

    // 1. Check independent non-blocking timers for all 4 motors
    for (uint8_t i = 0; i < 4; i++) {
        if (_timer_active[i] && (now - _timer_start[i] >= _timer_dur[i])) {
            _timer_active[i] = false;
            _applyMotor(i, 0, false); // Crisp Short Brake when duration ends
        }
    }

    // 2. Periodic keep-alive refresh to prevent the Wemos STM32 standby lockup
    if (now - _last_heartbeat >= WEMOS_HEARTBEAT_MS) {
        _last_heartbeat = now;
        uint8_t active_motors = (_addr[1] != 0x00) ? 4 : 2;
        for (uint8_t i = 0; i < active_motors; i++) {
            uint16_t pwm = (uint16_t)abs(_speed[i]) * 100U;
            _sendPacket(i, _mode[i], pwm);
        }
    }
}