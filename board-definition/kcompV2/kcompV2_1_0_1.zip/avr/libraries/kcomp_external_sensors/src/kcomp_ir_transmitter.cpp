#include "kcomp_ir_transmitter.h"

static uint8_t _tx_pin = 3;

// ==============================================================================
// ⚡ RAW HARDWARE GENERATION (BIT-BANGING)
// ==============================================================================
// Generates the carrier wave by manually toggling the pin
static void _mark(uint16_t time_us, uint8_t khz) {
    // Calculate the half-period of the wave in microseconds
    // For 38kHz: 1000 / 38 = 26us period -> 13us half-period
    // For 40kHz: 1000 / 40 = 25us period -> 12us half-period (Sony)
    uint16_t half_period = (khz == 40) ? 12 : 13; 
    
    unsigned long start = micros();
    while (micros() - start < time_us) {
        digitalWrite(_tx_pin, HIGH);
        delayMicroseconds(half_period);
        digitalWrite(_tx_pin, LOW);
        delayMicroseconds(half_period);
    }
}

// Generates the silence between pulses
static void _space(uint16_t time_us) {
    digitalWrite(_tx_pin, LOW);
    delayMicroseconds(time_us);
}

// ==============================================================================
// 🛠️ PUBLIC API
// ==============================================================================

void initIRTransmitter(uint8_t pin) {
    _tx_pin = pin;
    pinMode(_tx_pin, OUTPUT);
    digitalWrite(_tx_pin, LOW);
}

void send21Button(uint32_t hexCode) {
    // Protocol: NEC (38 kHz)
    _mark(9000, 38); 
    _space(4500);
    
    for (int8_t i = 31; i >= 0; i--) {
        _mark(560, 38);
        if (hexCode & (1UL << i)) {
            _space(1690); // Logic 1
        } else {
            _space(560);  // Logic 0
        }
    }
    _mark(560, 38); // Stop bit
}

void sendSonyTV(uint32_t hexCode) {
    // Protocol: SIRC 12-bit (40 kHz) - MUST repeat 3 times
    for (uint8_t repeat = 0; repeat < 3; repeat++) {
        _mark(2400, 40); 
        _space(600);
        
        for (int8_t i = 0; i < 12; i++) {
            if (hexCode & (1UL << i)) {
                _mark(1200, 40); // Logic 1
                _space(600);
            } else {
                _mark(600, 40);  // Logic 0
                _space(600);
            }
        }
        // Sony mandates a 45ms silence between repeats
        delay(45); 
    }
}

void sendSamsungTV(uint32_t hexCode) {
    // Protocol: Samsung 32-bit (38 kHz)
    _mark(4500, 38); 
    _space(4500);
    
    for (int8_t i = 31; i >= 0; i--) {
        _mark(560, 38);
        if (hexCode & (1UL << i)) {
            _space(1690); // Logic 1
        } else {
            _space(560);  // Logic 0
        }
    }
    _mark(560, 38); // Stop bit
}

void sendAcerBeamer(uint32_t hexCode) {
    // Acer Beamers typically use a strict NEC Extended format (38 kHz).
    // The timing is identical to the 21-Button remote, but semantically 
    // separating it in the library keeps the students' code highly readable!
    send21Button(hexCode); 
}