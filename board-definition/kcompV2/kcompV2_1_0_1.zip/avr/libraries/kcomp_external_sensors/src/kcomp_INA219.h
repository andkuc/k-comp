#ifndef _KCOMP_INA219_H
#define _KCOMP_INA219_H

#include <Arduino.h>

// ==============================================================================
// INA219 HARDWARE ADDRESS DICTIONARY
// ==============================================================================
#define INA219_ADDR_DEFAULT 0x40 // A0 = GND, A1 = GND
#define INA219_ADDR_A0      0x41 // A0 = VCC, A1 = GND
#define INA219_ADDR_A1      0x44 // A0 = GND, A1 = VCC
#define INA219_ADDR_A0_A1   0x45 // A0 = VCC, A1 = VCC

// ==============================================================================
// CORE FUNCTIONS
// ==============================================================================

// Initializes the INA219 sensor on the I2C bus and loads the 32V / 3.2A calibration.
// Returns true if the sensor responds at the specified I2C address.
bool initINA219(uint8_t address = INA219_ADDR_DEFAULT);

// Reads the main supply voltage (VIN- to GND) in Volts (V).
float getINA219BusVoltage_V(void);

// Reads the voltage drop across the 0.1 Ohm shunt resistor in millivolts (mV).
float getINA219ShuntVoltage_mV(void);

// Reads the current flowing through the load in milliamps (mA).
float getINA219Current_mA(void);

// Reads the total power consumed by the load in milliwatts (mW).
float getINA219Power_mW(void);

// Switches between Standard Mode (+/- 3200 mA, 32V) and High-Precision Mode (+/- 400 mA, 16V).
void setINA219HighPrecision(bool enable);

// Returns true if the measured current or power exceeded the active hardware range.
bool isINA219Overflow(void);

#endif