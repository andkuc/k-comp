#include "kcomp_ir_receiver_21_button.h"

// --- Background Interrupt Variables ---
// 'volatile' is required so the compiler does not delete these during optimization
static volatile uint32_t _ir_raw_data = 0;
static volatile bool _ir_ready = false;
static volatile uint8_t _ir_bit_count = 0;
static unsigned long _last_time = 0;

// --- User-Facing Cache ---
static uint32_t _cached_command = 0;

// ==============================================================================
// ⚡ THE HARDWARE INTERRUPT (NEC ISR)
// ==============================================================================
void _ir_isr() {
    unsigned long now = micros();
    unsigned long delta = now - _last_time;
    _last_time = now;

    // 1. Sync Mark detected? (~13.5ms)
    if (delta > 13000 && delta < 14000) {
        _ir_raw_data = 0;
        _ir_bit_count = 0;
        _ir_ready = false;
    }
    // 2. Binary '1' detected? (~2.25ms)
    else if (delta > 2000 && delta < 2500) {
        _ir_raw_data = (_ir_raw_data << 1) | 1;
        _ir_bit_count++;
    }
    // 3. Binary '0' detected? (~1.12ms)
    else if (delta > 800 && delta < 1500) {
        _ir_raw_data = (_ir_raw_data << 1) | 0;
        _ir_bit_count++;
    }
    // 4. Invalid pulse / Noise? Reset the buffer.
    else {
        _ir_raw_data = 0;
        _ir_bit_count = 0;
        _ir_ready = false;
    }

    // 5. Have we collected all 32 bits for the 21-Button remote?
    if (_ir_bit_count == 32) {
        _ir_ready = true;
        _ir_bit_count = 0; 
    }
}

// ==============================================================================
// 🛠️ PUBLIC API
// ==============================================================================
void initIRReceiver(uint8_t interrupt_pin) {
    pinMode(interrupt_pin, INPUT_PULLUP);
    
    // The NEC protocol has a stop bit, so a simple FALLING edge trigger works perfectly.
    attachInterrupt(digitalPinToInterrupt(interrupt_pin), _ir_isr, FALLING);
}

bool isIRAvailable(void) {
    if (_ir_ready) {
        // Pause interrupts for 1 microsecond to safely copy volatile data
        noInterrupts(); 
        _cached_command = _ir_raw_data;
        _ir_ready = false;
        
        // Wipe the raw buffer so holding down a button doesn't rapidly stack inputs 
        _ir_raw_data = 0; 
        
        interrupts();
        return true;
    }
    return false;
}

uint32_t getIRCommand(void) {
    return _cached_command;
}