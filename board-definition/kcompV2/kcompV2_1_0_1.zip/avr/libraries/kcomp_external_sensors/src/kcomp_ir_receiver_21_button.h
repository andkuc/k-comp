#ifndef _KCOM_IR_RECEIVER_21_BUTTON_H
#define _KCOM_IR_RECEIVER_21_BUTTON_H

#include "Arduino.h"

// ==============================================================================
// 🎛️ CORRECTED 21-BUTTON REMOTE DICTIONARY (NEC Protocol)
// ==============================================================================
#define IR_BTN_POWER    0xFFA25D // ON/OFF
#define IR_BTN_MODE     0xFF629D
#define IR_BTN_MUTE     0xFFE21D

#define IR_BTN_PLAY     0xFF22DD // PLAY / PAUSE
#define IR_BTN_PREV     0xFF02FD // FAST BACKWARD
#define IR_BTN_NEXT     0xFFC23D // FAST FORWARD

#define IR_BTN_EQ       0xFFE01F
#define IR_BTN_VOL_DOWN 0xFFA857 // MINUS
#define IR_BTN_VOL_UP   0xFF906F // PLUS

#define IR_BTN_0        0xFF6897
#define IR_BTN_RPT      0xFF9867 // REPEAT / 100+
#define IR_BTN_USD      0xFFB04F // U/SD / 200+

#define IR_BTN_1        0xFF30CF
#define IR_BTN_2        0xFF18E7
#define IR_BTN_3        0xFF7A85
#define IR_BTN_4        0xFF10EF
#define IR_BTN_5        0xFF38C7
#define IR_BTN_6        0xFF5AA5
#define IR_BTN_7        0xFF42BD
#define IR_BTN_8        0xFF4AB5
#define IR_BTN_9        0xFF52AD

// ==============================================================================
// 🛠️ CORE FUNCTIONS
// ==============================================================================

// Setup the IR Receiver. 
// WARNING: Pin MUST be an interrupt-capable pin (Pin 2 or 3 on the K-Comp).
void initIRReceiver(uint8_t interrupt_pin);

// Checks if a new 32-bit command has been received in the background.
// Returns true ONLY once per button press.
bool isIRAvailable(void);

// Retrieves the raw 32-bit hex code of the last pressed button.
uint32_t getIRCommand(void);

#endif