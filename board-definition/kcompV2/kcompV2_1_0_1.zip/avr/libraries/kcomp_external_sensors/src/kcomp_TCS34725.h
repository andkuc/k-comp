#ifndef _KCOMP_COLOR_H
#define _KCOMP_COLOR_H

#include "Arduino.h"

// ==============================================================================
// ⏱️ INTEGRATION TIME SETTINGS (Shutter Speed)
// ==============================================================================
#define COLOR_TIME_2_4MS  0xFF
#define COLOR_TIME_24MS   0xF6
#define COLOR_TIME_50MS   0xEB
#define COLOR_TIME_101MS  0xD5
#define COLOR_TIME_154MS  0xC0
#define COLOR_TIME_700MS  0x00

// ==============================================================================
// 🎚️ GAIN SETTINGS (Sensitivity Multiplier)
// ==============================================================================
#define COLOR_GAIN_1X     0x00
#define COLOR_GAIN_4X     0x01
#define COLOR_GAIN_16X    0x02
#define COLOR_GAIN_60X    0x03

// ==============================================================================
// 🎨 MEMORY-OPTIMIZED COLOR DEFINITIONS (1 Byte IDs)
// ==============================================================================
#define COLOR_UNKNOWN      0
#define COLOR_BLACK        1
#define COLOR_WHITE        2
#define COLOR_GREY         3
#define COLOR_RED          4
#define COLOR_DARK_RED     5
#define COLOR_GREEN        6
#define COLOR_FOREST_GREEN 7
#define COLOR_LIME_GREEN   8
#define COLOR_BLUE         9
#define COLOR_NAVY_BLUE    10
#define COLOR_LIGHT_BLUE   11
#define COLOR_YELLOW       12
#define COLOR_LIGHT_YELLOW 13
#define COLOR_ORANGE       14
#define COLOR_PINK         15
#define COLOR_BROWN        16
#define COLOR_PURPLE       17
#define COLOR_CYAN         18

// ==============================================================================
// 🛠️ SETUP & CONFIGURATION ROUTINES
// ==============================================================================
bool initColorSensor();
void setColorIntegrationTime(uint8_t timeSetting);
void setColorGain(uint8_t gainSetting);

// ==============================================================================
// ⚙️ STATE MACHINE & CALIBRATION
// ==============================================================================
void pollColorSensor();

// Sets the raw Clear channel limits for pure black (darkness) and pure white (reference).
void calibrateColorEngine(uint16_t blackThreshold, uint16_t whiteThreshold);

// Optional live calibration: Hold sensor over a white surface (8-10mm) and call once.
void calibrateWhiteBalance();

// Optional live calibration: Point sensor into empty space / black surface and call once.
void calibrateBlackLevel();

// ==============================================================================
// 📊 RAW & PERCEPTUAL GETTERS + COLOR ENGINE
// ==============================================================================
uint16_t getRed();
uint16_t getGreen();
uint16_t getBlue();
uint16_t getClear();

uint16_t getLux();
uint16_t getColorTemperature();

// Perceptual HSV getters (matches human eye color perception)
uint16_t getHue();        // Color wheel angle: 0 to 359 degrees
uint8_t  getSaturation(); // Color purity: 0 to 100 %
uint8_t  getBrightness(); // Surface reflectance (Value): 0 to 100 %

// Classifies the current reading into a 1-byte COLOR_... constant.
uint8_t estimateColor();

// Translates the 1-byte COLOR_... constant into a human-readable English string.
const char* getColorName(uint8_t colorCode);

#endif