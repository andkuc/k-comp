#include "kcomp_ir_receiver_21_button.h"
#include "kcomp_led.h"
#include "kcomp_buzzer.h"

// The IR Receiver MUST be connected to an interrupt pin.
// On the K-Comp (ATmega328P), these are Digital Pins 2 or 3.
#define IR_PIN 2 

void setup() {
    Serial.begin(115200);
    
    // 1. Initialize K-Comp onboard peripherals
    initLed();
    initBuzzer();
    
    // 2. Initialize the background IR Engine
    initIRReceiver(IR_PIN);
    
    Serial.println("==================================");
    Serial.println("  21-Button IR Receiver Online!   ");
    Serial.println("==================================");
    Serial.println("Press buttons on your Remote...");
}

void loop() {
    // ---------------------------------------------------------
    // 1. ASYNCHRONOUS SERVICES
    // ---------------------------------------------------------
    // Polling this command keeps the non-blocking audio engine 
    // running smoothly in the background.
    updateMelody(); 
    
    // ---------------------------------------------------------
    // 2. INPUT & LOGIC LAYER
    // ---------------------------------------------------------
    // Check if the background interrupt caught a complete 32-bit command
    if (isIRAvailable()) {
        
        uint32_t irCommand = getIRCommand();
        
        Serial.print("Raw Hex Received: 0x");
        Serial.println(irCommand, HEX);
        
        // Evaluate the command using our built-in 21-Button dictionary
        switch(irCommand) {
            
            case IR_BTN_PLAY:
                Serial.println("Action: PLAY / PAUSE -> Double Tone");
                ledOff();
                buzzerBeepNonBlocking(800, 200);
                break;
                
            case IR_BTN_VOL_UP:
                Serial.println("Action: VOLUME UP -> Bright Flash, High Beep");
                ledOn(100);                       
                buzzerBeepNonBlocking(1000, 100); 
                break;
                
            case IR_BTN_VOL_DOWN:
                Serial.println("Action: VOLUME DOWN -> Dim Flash, Low Beep");
                ledOn(10);                        
                buzzerBeepNonBlocking(400, 100);  
                break;
                
            case IR_BTN_EQ:
                Serial.println("Action: EQ -> Long Warning Tone");
                ledOff();
                buzzerBeepNonBlocking(200, 1000); 
                break;
                
            default:
                // Ignores button hold-repeats or unknown buttons so they 
                // don't trigger the buzzer accidentally.
                ledOff(); 
                break;
        }
    }
    
    // ---------------------------------------------------------
    // 3. RENDERING LAYER
    // ---------------------------------------------------------
    // Because we used attachInterrupt() in the library, we can do heavy tasks
    // here (like drawing to the OLED) and we will NEVER miss a button press!
}