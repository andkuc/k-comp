#include <Arduino.h>
#include "  "
#include "kcomp_oled.h"
#include "kcomp_led.h"
#include "kcomp_buzzer.h"

#define IR_PIN 2 

// ==============================================================================
// 1. MEMORY & VARIABLES (The State Machine)
// ==============================================================================
// State Machine: 0 = STANDBY, 1 = SYNTHESIZER ACTIVE
uint8_t systemState = 0; 

// Synthesizer Data
int currentFrequency = 440; // Starts at A4 (440 Hz)
bool isMuted = false;
unsigned long lastDroneTime = 0; // Non-blocking timer for the continuous tone

// ==============================================================================
// 2. SYSTEM SETUP
// ==============================================================================
void setup() {
    Serial.begin(115200);
    
    initDisplay();
    initLed();
    initBuzzer();
    initIRReceiver(IR_PIN);
    
    // Start in STANDBY mode
    systemState = 0;
}

// ==============================================================================
// 3. MAIN LOOP (The Heartbeat)
// ==============================================================================
void loop() {
    // ---------------------------------------------------------
    // A. ASYNCHRONOUS SERVICES
    // ---------------------------------------------------------
    updateMelody(); // Critical: Keeps the audio engine running
    
    // ---------------------------------------------------------
    // B. INPUT LAYER (Read the Remote)
    // ---------------------------------------------------------
    if (isIRAvailable()) {
        uint32_t irCommand = getIRCommand();
        
        switch(irCommand) {
            
            // --- GLOBAL STATE CONTROLS ---
            case IR_BTN_POWER:
            case IR_BTN_MODE:
                // Toggle between Standby and Active
                if (systemState == 0) {
                    systemState = 1;
                    isMuted = false;
                } else {
                    systemState = 0;
                    ledOff();
                }
                break;
                
            // --- SYNTHESIZER CONTROLS (Only process if ACTIVE) ---
            case IR_BTN_VOL_UP:
                if (systemState == 1) currentFrequency += 20; // Fine tune up
                break;
                
            case IR_BTN_VOL_DOWN:
                if (systemState == 1 && currentFrequency > 50) currentFrequency -= 20; // Fine tune down
                break;
                
            case IR_BTN_NEXT:
                if (systemState == 1) currentFrequency *= 2; // Octave Up
                break;
                
            case IR_BTN_PREV:
                if (systemState == 1 && currentFrequency > 50) currentFrequency /= 2; // Octave Down
                break;
                
            case IR_BTN_MUTE:
            case IR_BTN_PLAY:
                if (systemState == 1) isMuted = !isMuted; // Toggle sound
                break;

            case IR_BTN_EQ:
                // Randomize frequency for a chaotic sci-fi effect
                if (systemState == 1) currentFrequency = random(100, 2000);
                break;
                
            // --- MUSICAL NOTES (Numbers 1-8 play a C-Major Scale) ---
            case IR_BTN_1: if (systemState == 1) currentFrequency = 261; break; // C4
            case IR_BTN_2: if (systemState == 1) currentFrequency = 293; break; // D4
            case IR_BTN_3: if (systemState == 1) currentFrequency = 329; break; // E4
            case IR_BTN_4: if (systemState == 1) currentFrequency = 349; break; // F4
            case IR_BTN_5: if (systemState == 1) currentFrequency = 392; break; // G4
            case IR_BTN_6: if (systemState == 1) currentFrequency = 440; break; // A4
            case IR_BTN_7: if (systemState == 1) currentFrequency = 493; break; // B4
            case IR_BTN_8: if (systemState == 1) currentFrequency = 523; break; // C5
        }
    }
    
    // ---------------------------------------------------------
    // C. UPDATE LAYER (Logic & Continuous Audio)
    // ---------------------------------------------------------
    // If the synth is active and not muted, keep the buzzer singing!
    if (systemState == 1 && !isMuted) {
        ledOn(50); // Keep LED dimly lit while broadcasting sound
        
        // Non-blocking timer: re-trigger the tone every 100ms to keep it continuous
        if (millis() - lastDroneTime > 100) {
            buzzerBeepNonBlocking(currentFrequency, 150); 
            lastDroneTime = millis();
        }
    } else {
        ledOff(); // Turn off LED if muted or in standby
    }
    
    // ---------------------------------------------------------
    // D. RENDERING LAYER (OLED Graphics)
    // ---------------------------------------------------------
    clearDisplay();
    
    if (systemState == 0) {
        // STATE 0: STANDBY
        setCursor(35, 20);
        printText("STANDBY", OLED_COLOR_WHITE, 1);
        setCursor(10, 40);
        printText("Press [POWER]", OLED_COLOR_WHITE, 1);
    } 
    else if (systemState == 1) {
        // STATE 1: ACTIVE SYNTHESIZER
        
        // 1. Draw Title
        setCursor(25, 0);
        printText("SYNTH ACTIVE", OLED_COLOR_WHITE, 1);
        
        // 2. Draw Mute Status
        if (isMuted) {
            setCursor(45, 25);
            printText("MUTED", OLED_COLOR_WHITE, 1);
        } else {
            // Draw the current frequency 
            setCursor(20, 25);
            printText("FREQ: ", OLED_COLOR_WHITE, 1);
            
            // Assuming the library has the printInt function we designed previously
            setCursor(60, 25);
            printInt(currentFrequency, OLED_COLOR_WHITE, 1);
            setCursor(95, 25);
            printText("Hz", OLED_COLOR_WHITE, 1);
            
            // 3. Draw a dynamic visualizer bar based on pitch
            // Map the frequency (roughly 100Hz to 2000Hz) to the 128-pixel screen width
            int barWidth = map(currentFrequency, 100, 2000, 5, 120);
            
            // Constrain it so it doesn't draw off the screen
            if (barWidth > 128) barWidth = 128;
            if (barWidth < 0) barWidth = 0;
            
            drawRect(4, 45, 120, 10, OLED_COLOR_WHITE);
            fillRect(4, 47, barWidth, 6, OLED_COLOR_WHITE);
        }
    }
    
    updateDisplay();
}