#include "kcomp_INA219.h"

void setup() {
    Serial.begin(115200);

    if (!initINA219()) {
        Serial.println("Error: INA219 not found! Check I2C wiring at H1-H3.");
        while (1);
    }

    Serial.println("INA219 Power Monitor Online!");
}

void loop() {
    float busVoltage_V  = getINA219BusVoltage_V();
    float shuntVolt_mV  = getINA219ShuntVoltage_mV();
    float current_mA    = getINA219Current_mA();
    float power_mW      = getINA219Power_mW();

    Serial.print("Bus: ");
    Serial.print(busVoltage_V, 2);
    Serial.print(" V | Shunt: ");
    Serial.print(shuntVolt_mV, 2);
    Serial.print(" mV | Current: ");
    Serial.print(current_mA, 1);
    Serial.print(" mA | Power: ");
    Serial.print(power_mW, 1);
    Serial.println(" mW");

    delay(500);
}