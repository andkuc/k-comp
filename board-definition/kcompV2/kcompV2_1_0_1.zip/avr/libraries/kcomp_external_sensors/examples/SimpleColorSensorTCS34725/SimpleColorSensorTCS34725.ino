#include "kcomp_TCS34725.h"

void setup() {
    Serial.begin(115200);

    if (!initColorSensor()) {
        Serial.println("Hardware Error: TCS34725 not found. Check I2C wiring!");
        while (1);
    }

    setColorIntegrationTime(COLOR_TIME_101MS);
    calibrateColorEngine(250, 10000);

    Serial.println("--- TCS34725 HSV Color Engine Ready ---");
}

void loop() {
    // 1. Keep the internal sensor and HSV engine updated
    pollColorSensor();

    // 2. Print telemetry every 1000 milliseconds
    static unsigned long lastScan = 0;
    if (millis() - lastScan >= 1000) {
        lastScan = millis();

        Serial.print("RGB: ");
        Serial.print(getRed());   Serial.print(", ");
        Serial.print(getGreen()); Serial.print(", ");
        Serial.print(getBlue());
        Serial.print(" | Clear: "); Serial.print(getClear());

        Serial.print(" | HSV: ");
        Serial.print(getHue());        Serial.print(" deg, ");
        Serial.print(getSaturation()); Serial.print("%, ");
        Serial.print(getBrightness()); Serial.print("%");

        Serial.print(" -> Est.: ");
        Serial.println(getColorName(estimateColor()));
    }
}