#include "kcomp_motor_i2c.h"

bool wasBusy = false;

void printMenu() {
  Serial.println("\n=== K-COMP I2C DUAL MOTOR BENCH TEST (A & B @ 0x30) ===");
  Serial.println(" --- Motor A (A1/A2) ---");
  Serial.println(" [1] Motor A Forward 60% for 2 s");
  Serial.println(" [2] Motor A Reverse 60% for 2 s");
  Serial.println(" [3] Motor A Turn shaft +90 deg");
  Serial.println(" --- Motor B (B1/B2) ---");
  Serial.println(" [4] Motor B Forward 60% for 2 s");
  Serial.println(" [5] Motor B Reverse 60% for 2 s");
  Serial.println(" [6] Motor B Turn shaft +90 deg");
  Serial.println(" --- Both Motors Together (Chassis) ---");
  Serial.println(" [7] Drive Forward 60% for 2 s");
  Serial.println(" [8] Drive Backward 60% for 2 s");
  Serial.println(" [9] Chassis Turn +90 deg (Pivot Right)");
  Serial.println(" [0] Chassis Turn -180 deg (Pivot Left)");
  Serial.println(" [e] Endless Forward 50% (Both A & B)");
  Serial.println(" --- Stop Controls ---");
  Serial.println(" [b] Short Brake (abrupt stop)");
  Serial.println(" [c] Coast (smooth free-spin stop)");
  Serial.println("=======================================================");
}

void setup() {
  Serial.begin(115200);
  delay(200);

  // 1. Initialize primary motor shield at factory default address 0x30
  if (!initMotorI2C(MOTOR_ADDR_0x30)) {
    Serial.println("ERROR: No ACK from Motor Shield at 0x30!");
    Serial.println("Check: D1->SCL, D2->SDA, 3V3->3.3V, G->GND, and AD0/AD1 open.");
    while (1)
      ;
  }

  // 2. Flip Motor B in software if mounted mirrored on a robot chassis
  setMotorInvert(false, false);

  // 3. Calibration defaults for open-loop angle functions
  setMotorRPM(200);             // Rated shaft RPM at 100% speed (yellow TT = 200)
  setTurnCalibration(450, 60);  // Estimated ms for a 90-degree chassis pivot at speed 60

  Serial.println("SUCCESS: Motor Shield found at 0x30!");
  printMenu();
}

void loop() {
  // 1. Mandatory heartbeat: handles timed stops & prevents Wemos standby lockup
  motorUpdate();

  // 2. Report when a timed or angle-based move finishes automatically
  bool busyNow = isMotorBusy();
  if (wasBusy && !busyNow) {
    Serial.println("-> Motion complete (auto-braked by motorUpdate).");
  }
  wasBusy = busyNow;

  // 3. Read single-character commands from the Serial Monitor
  if (Serial.available() > 0) {
    char cmd = Serial.read();

    switch (cmd) {
      // --- Motor A ---
      case '1':
        Serial.println("Running: Motor A Forward 60% for 2000 ms...");
        setMotorA(60, 2000);
        break;

      case '2':
        Serial.println("Running: Motor A Reverse -60% for 2000 ms...");
        setMotorA(-60, 2000);
        break;

      case '3':
        Serial.println("Running: turnMotorAngle(MOTOR_A, +90 deg, speed 60)...");
        turnMotorAngle(MOTOR_A, 90, 60);
        break;

      // --- Motor B ---
      case '4':
        Serial.println("Running: Motor B Forward 60% for 2000 ms...");
        setMotorB(60, 2000);
        break;

      case '5':
        Serial.println("Running: Motor B Reverse -60% for 2000 ms...");
        setMotorB(-60, 2000);
        break;

      case '6':
        Serial.println("Running: turnMotorAngle(MOTOR_B, +90 deg, speed 60)...");
        turnMotorAngle(MOTOR_B, 90, 60);
        break;

      // --- Both Motors Together ---
      case '7':
        Serial.println("Running: Both Motors Forward 60% for 2000 ms...");
        driveForward(60, 2000);
        break;

      case '8':
        Serial.println("Running: Both Motors Backward 60% for 2000 ms...");
        driveBackward(60, 2000);
        break;

      case '9':
        Serial.println("Running: turnAngle(+90 deg, speed 60)...");
        turnAngle(90, 60);
        break;

      case '0':
        Serial.println("Running: turnAngle(-180 deg, speed 60)...");
        turnAngle(-180, 60);
        break;

      case 'e':
      case 'E':
        Serial.println("Running: Both Motors Endless Forward 50% (send 'b' or 'c' to stop)...");
        driveForward(50);
        break;

      // --- Stop Controls ---
      case 'b':
      case 'B':
        Serial.println("Action: Short Brake (immediate stop).");
        brakeMotors();
        break;

      case 'c':
      case 'C':
        Serial.println("Action: Coast (power disconnected).");
        coastMotors();
        break;

      case '\n':
      case '\r':
        break;  // Ignore line endings

      default:
        printMenu();
        break;
    }
  }
}