#include <kcomp_oled.h>
#include <kcomp_joystick.h>
#include <kcomp_button_select.h>
#include "kcomp_ir_transmitter.h"
#include <kcomp_led.h>
#include <kcomp_buzzer.h>

#define IR_TX_PIN 2

// ==============================================================================
// 1. MEMORY & VARIABLES (The Menu State)
// ==============================================================================
uint8_t cursorY = 0;             // Tracks which menu item is currently selected
const uint8_t MAX_ITEMS = 5;     // 6 total items (0 to 5)
bool joyNeutral = true;          // Prevents the cursor from flying off the screen

// The text labels for our OLED menu
const char* menuItems[] = {
    "1. TV Power", 
    "2. Volume Up", 
    "3. Volume Down", 
    "4. Mute", 
    "5. Prog +", 
    "6. Prog -"
};

// ==============================================================================
// 2. HARDWARE EVENTS (The Transmitter Logic)
// ==============================================================================
void onSelectClicked() {
    // Hardware Feedback: Turn on LED and beep to confirm transmission
    ledOn(100); 
    buzzerBeepNonBlocking(1200, 50); 
    
    // Evaluate the cursor position and broadcast the exact Samsung hex code
    switch(cursorY) {
        case 0: 
            sendSamsungTV(SAMSUNG_BTN_POWER); 
            break;
        case 1: 
            sendSamsungTV(SAMSUNG_BTN_VOL_UP); 
            break;
        case 2: 
            sendSamsungTV(SAMSUNG_BTN_VOL_DOWN); 
            break;
        case 3: 
            sendSamsungTV(SAMSUNG_BTN_MUTE); 
            break;
        case 4: 
            sendSamsungTV(SAMSUNG_BTN_CH_UP); // Maps to Prog +
            break;
        case 5: 
            sendSamsungTV(SAMSUNG_BTN_CH_DOWN); // Maps to Prog -
            break;
    }
    
    // Turn off LED after transmission is complete
    ledOff(); 
}

// ==============================================================================
// 3. SYSTEM SETUP
// ==============================================================================
void setup() {
    Serial.begin(115200);
    
    // Initialize all K-Comp onboard peripherals
    initDisplay();
    initJoystick();
    initButtonSelect();
    initLed();
    initBuzzer();
    
    // Initialize the external IR Transmitter
    initIRTransmitter(IR_TX_PIN);
    
    // Link the button press to our event callback
    attachButtonSelectClick(onSelectClicked);
}

// ==============================================================================
// 4. MAIN LOOP (The Heartbeat)
// ==============================================================================
void loop() {
    // ---------------------------------------------------------
    // A. ASYNCHRONOUS SERVICES
    // ---------------------------------------------------------
    pollSelectButton(); // Listens for button clicks without pausing the game
    updateMelody();     // Keeps the audio engine running
    
    // ---------------------------------------------------------
    // B. INPUT LAYER (Joystick Navigation)
    // ---------------------------------------------------------
    int joyY = -getJoystickYValue();
    
    // If joystick is pushed DOWN and was previously in the middle
    if (joyY > 250 && joyNeutral) {
        if (cursorY < MAX_ITEMS) cursorY++; // Move cursor down
        joyNeutral = false;                 // Lock movement until joystick centers
    } 
    // If joystick is pushed UP and was previously in the middle
    else if (joyY < -250 && joyNeutral) {
        if (cursorY > 0) cursorY--;         // Move cursor up
        joyNeutral = false;                 // Lock movement
    } 
    // If joystick returns to the deadzone (center)
    else if (joyY > -100 && joyY < 100) {
        joyNeutral = true;                  // Unlock movement for the next push
    }
    
    // ---------------------------------------------------------
    // C. RENDERING LAYER
    // ---------------------------------------------------------
    clearDisplay();
    
    // Draw the Header
    setCursor(18, 0);
    printText("SAMSUNG REMOTE", OLED_COLOR_WHITE, 1);
    drawLine(0, 10, 128, 10, OLED_COLOR_WHITE);
    
    // Draw the Menu Items
    for(int i = 0; i <= MAX_ITEMS; i++) {
        int yPos = 14 + (i * 8); // Space the items 8 pixels apart vertically
        
        if (i == cursorY) {
            // Draw an inverted box around the currently selected item for "Game Feel"
            fillRect(0, yPos - 1, 128, 9, OLED_COLOR_WHITE);
            setCursor(5, yPos);
            printText(menuItems[i], OLED_COLOR_INVERT, 1);
        } else {
            // Draw normal text for unselected items
            setCursor(5, yPos);
            printText(menuItems[i], OLED_COLOR_WHITE, 1);
        }
    }
    
    updateDisplay();
}