#ifndef _KCOMP_HX711_H
#define _KCOMP_HX711_H

#include <Arduino.h>

// ==============================================================================
// ⚖️ HX711 DEFAULT CALIBRATION CONSTANTS (Approximate Raw Units per Gram)
// ==============================================================================
#define HX711_SCALE_1KG   717.5f
#define HX711_SCALE_5KG   420.0f
#define HX711_SCALE_10KG  210.0f
#define HX711_SCALE_20KG  105.0f

// ==============================================================================
// CORE FUNCTIONS
// ==============================================================================

// Initializes the HX711 on any two digital pins (DOUT and SCK).
// Resets the chip, selects Channel A (Gain 128), and returns true if responsive.
bool initHX711(uint8_t dout_pin, uint8_t sck_pin);

// Returns true when the HX711 has a new 24-bit reading ready (non-blocking check).
bool isHX711Ready(void);

// Reads the raw 24-bit signed value from the ADC (averaged over 'samples' readings).
int32_t getHX711Raw(uint8_t samples = 1);

// Zeros the scale by averaging 'samples' readings and storing the tare offset.
void tareHX711(uint8_t samples = 10);

// Manually sets the calibration scale factor (raw ADC units per 1 gram).
void setHX711Scale(float scale_factor);

// Automatically calculates and sets the scale factor using a known weight in grams.
// Call tareHX711() with an empty scale first, place the known weight, then call this.
void calibrateHX711(float known_weight_g, uint8_t samples = 10);

// Returns the net weight in grams (g) as a decimal number.
float getHX711Weight_g(uint8_t samples = 1);

#endif