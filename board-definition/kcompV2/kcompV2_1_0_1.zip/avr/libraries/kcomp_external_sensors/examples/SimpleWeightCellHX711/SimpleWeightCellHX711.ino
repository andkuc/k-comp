#include "kcomp_HX711.h"

#define HX711_DT_PIN  3
#define HX711_SCK_PIN 8

void setup() {
    Serial.begin(115200);

    // 1. Initialize the HX711 sensor on Digital Pins D2 and D3
    if (!initHX711(HX711_DT_PIN, HX711_SCK_PIN)) {
        Serial.println("Error: HX711 not found! Check DT and SCK wiring.");
        while (1);
    }

    // 2. Set the calibration factor for your load cell (e.g., 5kg cell)
    setHX711Scale(HX711_SCALE_1KG);

    // 3. Zero the scale (do not touch the load cell during startup!)
    Serial.println("Taring scale... Keep platform empty.");
    tareHX711(10);
    Serial.println("Scale Ready!");
}

void loop() {
    // 4. Read the averaged weight in grams (5 samples per reading)
    float weight_g = getHX711Weight_g(5);

    // 5. Print the weight to the Serial Monitor
    Serial.print("Weight: ");
    Serial.print(weight_g, 1);
    Serial.println(" g");

    delay(250);
}