#include "kcomp_hx711.h"

// --- Encapsulated Module State (11 Bytes SRAM) ---
static uint8_t _dout_pin     = 2;
static uint8_t _sck_pin      = 3;
static int32_t _tare_offset  = 0;
static float   _scale_factor = 420.0f; // Default for 1kg / 5kg kit load cells

// ==============================================================================
// INTERNAL 24-BIT SYNCHRONOUS SHIFT HELPER
// ==============================================================================
static int32_t _readSingleRaw(void) {
    // Wait until DOUT goes LOW (indicating conversion is complete)
    // Timeout after 500ms so disconnected wires never freeze the K-Comp forever
    unsigned long start = millis();
    while (digitalRead(_dout_pin) == HIGH) {
        if (millis() - start > 500) {
            return 0;
        }
    }

    uint32_t raw24 = 0;

    // Shift in 24 bits (MSB first)
    for (uint8_t i = 0; i < 24; i++) {
        // Protect clock high-time (< 60us required by HX711 silicon)
        noInterrupts();
        digitalWrite(_sck_pin, HIGH);
        delayMicroseconds(1);
        uint8_t bitVal = digitalRead(_dout_pin);
        digitalWrite(_sck_pin, LOW);
        interrupts();

        raw24 = (raw24 << 1) | bitVal;
        delayMicroseconds(1);
    }

    // 25th clock pulse selects Channel A with Gain = 128 for the next reading
    noInterrupts();
    digitalWrite(_sck_pin, HIGH);
    delayMicroseconds(1);
    digitalWrite(_sck_pin, LOW);
    interrupts();

    // Sign-extend 24-bit two's complement to 32-bit signed integer (int32_t)
    if (raw24 & 0x800000UL) {
        raw24 |= 0xFF000000UL;
    }

    return (int32_t)raw24;
}

// ==============================================================================
// PUBLIC API
// ==============================================================================
bool initHX711(uint8_t dout_pin, uint8_t sck_pin) {
    _dout_pin = dout_pin;
    _sck_pin  = sck_pin;

    pinMode(_dout_pin, INPUT_PULLUP);
    pinMode(_sck_pin, OUTPUT);

    // Perform a clean hardware reset by holding SCK HIGH for 100us (> 60us)
    digitalWrite(_sck_pin, HIGH);
    delayMicroseconds(100);
    digitalWrite(_sck_pin, LOW);

    // Wait up to 500ms for the HX711 to wake up and pull DOUT LOW
    unsigned long start = millis();
    while (digitalRead(_dout_pin) == HIGH) {
        if (millis() - start > 500) {
            return false; // Sensor did not respond
        }
    }

    // Take one initial dummy reading to lock in Channel A (Gain 128)
    _readSingleRaw();
    return true;
}

bool isHX711Ready(void) {
    return (digitalRead(_dout_pin) == LOW);
}

int32_t getHX711Raw(uint8_t samples) {
    if (samples == 0) {
        samples = 1;
    }

    int64_t sum = 0;
    for (uint8_t i = 0; i < samples; i++) {
        sum += _readSingleRaw();
    }

    return (int32_t)(sum / samples);
}

void tareHX711(uint8_t samples) {
    _tare_offset = getHX711Raw(samples);
}

void setHX711Scale(float scale_factor) {
    if (scale_factor != 0.0f) {
        _scale_factor = scale_factor;
    }
}

void calibrateHX711(float known_weight_g, uint8_t samples) {
    if (known_weight_g == 0.0f) {
        return;
    }
    int32_t netRaw = getHX711Raw(samples) - _tare_offset;
    _scale_factor = (float)netRaw / known_weight_g;
}

float getHX711Weight_g(uint8_t samples) {
    int32_t netRaw = getHX711Raw(samples) - _tare_offset;
    return (float)netRaw / _scale_factor;
}