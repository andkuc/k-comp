/*
  Example: Button Start (Event Callbacks)
  Task:    Detects click, double-click, long press, and release via callbacks.
  Pins:    Onboard START button on D3 (DIP S1-4 ON)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_button_start.h>

// Callback functions: We pass their names to attachButtonStart...() in setup().
// The library then calls these functions automatically when an event happens.
void onButtonStartClick() {
  Serial.println("Start button clicked");
}

void onButtonStartDoubleClick() {
  Serial.println("Start button double-clicked");
}

void onButtonStartLongPress() {
  Serial.println("Start button longpress");
}

void onButtonStartLongRelease() {
  Serial.println("Start button longpress released");
}

void setup() {
  Serial.begin(115200);
  initButtonStart();
  Serial.println("Start button initialized...");

  // Register our callback functions for each gesture
  attachButtonStartClick(onButtonStartClick);
  attachButtonStartDoubleClick(onButtonStartDoubleClick);
  attachButtonStartLongPressed(onButtonStartLongPress);
  attachButtonStartLongReleased(onButtonStartLongRelease);
}

void loop() {
  // IMPORTANT: Call updateButtonStart() frequently WITHOUT long delay() calls,
  // otherwise double-clicks and long presses cannot be detected reliably.
  updateButtonStart();
  delay(10);
}
