/*
  Example: Onboard LED Brightness and Fading
  Task:    Sets LED brightness in percent (0-100%) and runs fade animations.
  Pins:    Onboard red LED on D5 (DIP S1-2 ON)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_led.h>

void setup() {
  Serial.begin(115200);
  initLed();
  Serial.println("LED initialized...");

  // Note: setLed() expects percentage (0..100%), not raw PWM (0..255).
  setLed(50);
  Serial.println("LED switched on at 50% for 1s.");
  delay(1000);

  setLed(100);
  Serial.println("LED switched on at 100% for 1s.");
  delay(1000);

  setLedOff();
  Serial.println("LED switched off.");
  delay(1000);
}

void loop() {
  // Blocking means the MCU waits until the fade finishes and cannot read buttons meanwhile.
  Serial.println("Fading in LED from 0% to 100% within 1s (blocking)...");
  fadeLedInBlocking(100, 1000);

  Serial.println("Fading out LED from 100% to 0% within 1s (blocking)...");
  fadeLedOutBlocking(100, 1000);
}
