/*
  Example: Button Start (Polling)
  Task:    Reads the onboard START button directly in loop().
  Pins:    Onboard START button on D3 (DIP S1-4 ON)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_button_start.h>

void setup() {
  Serial.begin(115200);
  initButtonStart();
  Serial.println("Start button initialized...");
}

void loop() {
  // Polling checks the current state directly (true while held down).
  // Note: To react only ONCE per press, compare with the previous state (edge detection).
  bool isPressed = isButtonStartPressed();

  if (isPressed) {
    Serial.println("Start button is pressed!");
  }

  // Slows down Serial Monitor output (do not use long delays in games!)
  delay(200);
}
