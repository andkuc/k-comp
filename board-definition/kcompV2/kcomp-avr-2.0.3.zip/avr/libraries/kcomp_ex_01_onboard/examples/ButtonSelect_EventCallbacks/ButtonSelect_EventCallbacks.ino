/*
  Example: Button Select (Event Callbacks)
  Task:    Detects click, double-click, long press, and release via callbacks.
  Pins:    Onboard SELECT button on D4 (DIP S1-5 ON)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_button_select.h>

// Callback functions: We pass their names to attachButtonSelect...() in setup().
// The library then calls these functions automatically when an event happens.
void onButtonSelectClick() {
  Serial.println("Select button clicked");
}

void onButtonSelectDoubleClick() {
  Serial.println("Select button double-clicked");
}

void onButtonSelectLongPress() {
  Serial.println("Select button longpress");
}

void onButtonSelectLongRelease() {
  Serial.println("Select button longpress released");
}

void setup() {
  Serial.begin(115200);
  initButtonSelect();
  Serial.println("Select button initialized...");

  // Register our callback functions for each gesture
  attachButtonSelectClick(onButtonSelectClick);
  attachButtonSelectDoubleClick(onButtonSelectDoubleClick);
  attachButtonSelectLongPressed(onButtonSelectLongPress);
  attachButtonSelectLongReleased(onButtonSelectLongRelease);
}

void loop() {
  // IMPORTANT: Call updateButtonSelect() frequently WITHOUT long delay() calls,
  // otherwise double-clicks and long presses cannot be detected reliably.
  updateButtonSelect();
  delay(10);
}
