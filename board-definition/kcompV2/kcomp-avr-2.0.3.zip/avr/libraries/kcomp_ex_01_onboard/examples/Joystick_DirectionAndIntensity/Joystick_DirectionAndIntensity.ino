/*
  Example: Joystick Direction and Intensity
  Task:    Reads raw/centered X & Y axes, 8-way direction, and intensity (0-100%).
  Pins:    Onboard 2-axis joystick (X on A2, Y on A1)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_joystick.h>

void printDirectionName(JoystickDirection dir) {
  switch (dir) {
    case JOYSTICK_CENTER:     Serial.print("CENTER"); break;
    case JOYSTICK_LEFT:       Serial.print("LEFT"); break;
    case JOYSTICK_RIGHT:      Serial.print("RIGHT"); break;
    case JOYSTICK_UP:         Serial.print("UP"); break;
    case JOYSTICK_DOWN:       Serial.print("DOWN"); break;
    case JOYSTICK_UP_LEFT:    Serial.print("UP_LEFT"); break;
    case JOYSTICK_UP_RIGHT:   Serial.print("UP_RIGHT"); break;
    case JOYSTICK_DOWN_LEFT:  Serial.print("DOWN_LEFT"); break;
    case JOYSTICK_DOWN_RIGHT: Serial.print("DOWN_RIGHT"); break;
    default:                  Serial.print("UNKNOWN"); break;
  }
}

void setup() {
  Serial.begin(115200);
  initJoystick();
  Serial.println("Joystick demo initialized...");
  delay(500);
}

void loop() {
  Serial.print("Raw X: ");
  Serial.print(getJoystickXRaw());
  Serial.print(" | Centered X: ");
  Serial.print(getJoystickXValue());

  Serial.print(" | Raw Y: ");
  Serial.print(getJoystickYRaw());
  Serial.print(" | Centered Y: ");
  Serial.print(getJoystickYValue());

  JoystickState state = getJoystickState();

  Serial.print(" || Direction: ");
  printDirectionName(state.direction);

  Serial.print(" | Intensity: ");
  Serial.print(state.intensity);
  Serial.println("%");

  delay(250);
}
