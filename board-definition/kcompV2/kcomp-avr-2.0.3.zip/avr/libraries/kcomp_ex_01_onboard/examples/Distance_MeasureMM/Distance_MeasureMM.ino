/*
  Example: Ultrasonic Distance Measurement (HC-SR04)
  Task:    Continuously measures distance in millimeters (20 mm to 4000 mm).
  Pins:    Onboard HC-SR04 slot (TRIG D11, ECHO D10)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_distance.h>

void setup() {
  Serial.begin(115200);
  initDistanceSensor();
  Serial.println("Distance Sensor initialized...");
}

void loop() {
  int distance = getDistanceMM();

  // The driver returns -1 if no echo was received (out of range or timeout)
  if (distance < 0) {
    Serial.println("Distance: Out of range (no echo)");
  } else {
    Serial.print("Distance: ");
    Serial.print(distance);
    Serial.println(" mm");
  }

  delay(500);
}
