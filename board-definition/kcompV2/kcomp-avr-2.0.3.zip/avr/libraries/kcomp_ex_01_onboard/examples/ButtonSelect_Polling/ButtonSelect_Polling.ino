/*
  Example: Button Select (Polling)
  Task:    Reads the onboard SELECT button directly in loop().
  Pins:    Onboard SELECT button on D4 (DIP S1-5 ON)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_button_select.h>

void setup() {
  Serial.begin(115200);
  initButtonSelect();
  Serial.println("Select button initialized...");
}

void loop() {
  // Polling checks the current state directly (true while held down).
  // Note: To react only ONCE per press, compare with the previous state (edge detection).
  bool isPressed = isButtonSelectPressed();

  if (isPressed) {
    Serial.println("Select button is pressed!");
  }

  // Slows down Serial Monitor output (do not use long delays in games!)
  delay(200);
}
