/*
  Example: OLED Display Diagnostics (Full Framebuffer - 1024 B RAM)
  Task:    Tests text, geometry, fast lines, invert/dim using kcomp_oled.h.
  Pins:    Onboard 0.96" SSD1306 OLED on I2C (0x3C, SDA A4, SCL A5)
  Monitor: Serial Monitor at 115200 baud + OLED display
*/

// Note: Full-buffer mode (kcomp_oled.h) is easiest to use (1024 bytes RAM).
// For larger projects that need more free SRAM, use kcomp_oled_paged.h (128 bytes RAM).
#include <kcomp_oled.h>

uint8_t currentTestPhase = 0;
unsigned long lastPhaseChange = 0;
int phaseDuration = 3000;

void setup() {
  Serial.begin(115200);
  Serial.println("Booting Standard Display Diagnostic...");

  if (!initDisplay()) {
    Serial.println("Error: OLED hardware not responding. Check wiring / I2C.");
    while (1) { delay(100); }
  }
}

void loop() {
  // --- 1. STATE MANAGEMENT (LOGIC) ---
  if (millis() - lastPhaseChange > phaseDuration) {
    currentTestPhase++;
    if (currentTestPhase > 3) currentTestPhase = 0;

    invertDisplay(false);
    dimDisplay(false);
    lastPhaseChange = millis();
  }

  // --- 2. RENDERING LAYER ---
  clearDisplay();

  switch (currentTestPhase) {
    case 0:
      setCursor(OLED_ALIGN_CENTER_X(12, 1), 10);
      printText("K-COMP BOARD", OLED_COLOR_WHITE, 1);
      setCursor(OLED_ALIGN_CENTER_X(10, 2), 30);
      printText("DIAGNOSTIC", OLED_COLOR_WHITE, 2);
      break;

    case 1:
      setCursor(0, 0);
      printText("GEOMETRY", OLED_COLOR_WHITE, 1);
      drawLine(0, 15, 127, 15, OLED_COLOR_WHITE);
      drawRect(5, 25, 20, 20, OLED_COLOR_WHITE);
      fillRect(35, 25, 20, 20, OLED_COLOR_WHITE);
      drawCircle(80, 35, 10, OLED_COLOR_WHITE);
      fillTriangle(105, 45, 115, 25, 125, 45, OLED_COLOR_WHITE);
      break;

    case 2:
      setCursor(0, 0);
      printText("FAST LINES", OLED_COLOR_WHITE, 1);
      for (int i = 0; i < 128; i += 8) {
        drawFastVLine(i, 15, 49, OLED_COLOR_WHITE);
      }
      for (int i = 15; i < 64; i += 8) {
        drawFastHLine(0, i, 128, OLED_COLOR_WHITE);
      }
      break;

    case 3:
      setCursor(OLED_ALIGN_CENTER_X(13, 1), OLED_ALIGN_CENTER_Y(1));
      if (millis() % 1000 < 500) {
        invertDisplay(true);
        printText("INVERT TEST", OLED_COLOR_WHITE, 1);
      } else {
        invertDisplay(false);
        dimDisplay(true);
        printText("DIM TEST", OLED_COLOR_WHITE, 1);
      }
      break;
  }

  updateDisplay();
  delay(20);
}
