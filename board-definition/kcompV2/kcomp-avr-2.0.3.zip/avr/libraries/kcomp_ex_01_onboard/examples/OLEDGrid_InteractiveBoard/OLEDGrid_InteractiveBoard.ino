/*
  Example: OLED Grid Interactive Board
  Task:    Draws a 3x3 game grid with X/O pieces and a joystick-controlled cursor.
  Pins:    Onboard OLED (I2C 0x3C) + Joystick (A1/A2)
  Monitor: Output on OLED display (Serial Monitor not required)
*/

#include <kcomp_oled_paged.h>
#include <kcomp_oled_grid.h>
#include <kcomp_joystick.h>

#define GRID_ROWS     3
#define GRID_COLS     3
#define GRID_CELL_W   20
#define GRID_CELL_H   20
#define GRID_OFFSET_X 34
#define GRID_OFFSET_Y 2

// GRID_MEM_SIZE calculates the exact byte size (4 bits per cell = 2 cells per byte)
uint8_t myGameMemory[GRID_MEM_SIZE(GRID_ROWS, GRID_COLS)] = {0};

// Custom callback to draw each non-empty cell (state 1 = X, state 2 = O)
void drawPieces(int16_t anchorX, int16_t anchorY, int16_t w, int16_t h, uint8_t state) {
  if (state == 1) {
    drawLine(anchorX + 3, anchorY + 3, anchorX + w - 3, anchorY + h - 3, OLED_COLOR_WHITE);
    drawLine(anchorX + w - 3, anchorY + 3, anchorX + 3, anchorY + h - 3, OLED_COLOR_WHITE);
  } else if (state == 2) {
    drawCircle(anchorX + w / 2, anchorY + h / 2, (w / 2) - 3, OLED_COLOR_WHITE);
  }
}

// Custom callback to draw the active cursor box
void drawMyCursor(int16_t anchorX, int16_t anchorY, int16_t w, int16_t h) {
  drawRect(anchorX + 1, anchorY + 1, w - 2, h - 2, OLED_COLOR_INVERT);
}

void setup() {
  initDisplay();
  initJoystick();

  initGrid(GRID_ROWS, GRID_COLS, GRID_CELL_W, GRID_CELL_H, GRID_OFFSET_X, GRID_OFFSET_Y, myGameMemory);
  attachGridRender(drawPieces);
  attachGridCursorRender(drawMyCursor);
  setGridCursorEnabled(true);

  // Place two sample pieces (X at top-left, O in the center)
  setGridCell(0, 0, 1);
  setGridCell(1, 1, 2);
}

void loop() {
  // --- INPUT LAYER ---
  int joyX = getJoystickXValue();
  int joyY = getJoystickYValue();

  if (joyX > 250)  moveGridCursor(0, 1);   // Right
  if (joyX < -250) moveGridCursor(0, -1);  // Left
  if (joyY > 250)  moveGridCursor(-1, 0);  // Up
  if (joyY < -250) moveGridCursor(1, 0);   // Down

  // --- RENDERING LAYER (Paged OLED Loop) ---
  firstPage();
  do {
    renderGrid();
  } while (nextPage());
}
