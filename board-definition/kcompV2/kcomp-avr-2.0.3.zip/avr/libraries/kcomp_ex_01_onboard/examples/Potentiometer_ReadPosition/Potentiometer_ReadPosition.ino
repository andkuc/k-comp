/*
  Example: Onboard Potentiometer
  Task:    Reads both raw 10-bit ADC (0-1023) and scaled percent (0-100%) values.
  Pins:    Onboard rotary potentiometer on A0 (DIP S1-3 ON)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_potentiometer.h>

void setup() {
  Serial.begin(115200);
  initPotentiometer();
  Serial.println("Potentiometer initialized...");
}

void loop() {
  // getPotentiometerRaw() returns 0..1023 (10-bit ADC), getPotentiometerValue() returns 0..100%.
  int raw = getPotentiometerRaw();
  int value = getPotentiometerValue();

  Serial.print("Raw (0-1023): ");
  Serial.print(raw);
  Serial.print(" | Scaled: ");
  Serial.print(value);
  Serial.println("%");

  delay(500);
}
