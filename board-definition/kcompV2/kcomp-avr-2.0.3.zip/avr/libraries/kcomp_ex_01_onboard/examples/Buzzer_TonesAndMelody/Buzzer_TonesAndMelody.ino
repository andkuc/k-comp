/*
  Example: Buzzer Tones and Melody
  Task:    Demonstrates blocking tones/melodies and non-blocking playback.
  Pins:    Onboard passive buzzer on D9 (DIP S1-6 ON)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_buzzer.h>

// Global arrays: Must stay valid in memory while non-blocking playBuzzerMelody() runs!
uint16_t melody[]        = { NOTE_C4, NOTE_G3, NOTE_G3, NOTE_A3, NOTE_G3, NOTE_REST, NOTE_B3, NOTE_C4 };
uint16_t noteDurations[] = { 4,       8,       8,       4,       4,       4,         4,       4 };
uint8_t  melodyLength    = 8;

void setup() {
  Serial.begin(115200);
  initBuzzer();
  Serial.println("Buzzer initialized...");

  // --- PART 1: BLOCKING EXAMPLES (CPU waits until finished) ---
  Serial.println("1) Continuous tone at 175 Hz (F3) for 1s...");
  playBuzzerTone(175);
  delay(1000);
  stopBuzzer();
  delay(500);

  Serial.println("2) Blocking beep at 392 Hz (G4) for 500 ms...");
  playBuzzerBeepBlocking(NOTE_G4, 500);
  delay(500);

  Serial.println("3) Blocking melody (setup waits until finished)...");
  playBuzzerMelodyBlocking(melody, noteDurations, melodyLength);
  delay(1000);

  // --- PART 2: NON-BLOCKING EXAMPLE (runs in background via loop) ---
  Serial.println("4) Non-blocking melody (driven by updateBuzzer() in loop)...");
  playBuzzerMelody(melody, noteDurations, melodyLength);
}

void loop() {
  // Advances the non-blocking melody step by step without freezing your program
  updateBuzzer();
  delay(20);
}
