// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      ex_01_onboard
// @title       K-Comp Examples: 01_Onboard
// @targets     avr, esp32s3
// @bus         none (example collection)
// @timers      none
// @sram_bytes  0

#ifndef KCOMP_EX_01_ONBOARD_H
#define KCOMP_EX_01_ONBOARD_H

// Example-only library exposing '01_Onboard' directly under Examples for K-Comp V2.

#endif
