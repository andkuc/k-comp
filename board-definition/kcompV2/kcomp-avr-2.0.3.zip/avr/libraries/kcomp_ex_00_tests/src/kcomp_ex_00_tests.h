// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      ex_00_tests
// @title       K-Comp Examples: 00_Tests
// @targets     avr, esp32s3
// @bus         none (example collection)
// @timers      none
// @sram_bytes  0

#ifndef KCOMP_EX_00_TESTS_H
#define KCOMP_EX_00_TESTS_H

// Example-only library exposing '00_Tests' directly under Examples for K-Comp V2.

#endif
