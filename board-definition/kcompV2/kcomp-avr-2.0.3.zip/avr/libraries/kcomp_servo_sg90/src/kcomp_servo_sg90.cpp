// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_servo_sg90.h"

#if defined(__AVR__)
  #include <avr/interrupt.h>
  #include <avr/io.h>
#endif

// Standard RC servo pulse bounds (microseconds) within a 20 ms (50 Hz) frame
static constexpr uint16_t SERVO_MIN_US     = 544U;
static constexpr uint16_t SERVO_NEUTRAL_US = 1500U;
static constexpr uint16_t SERVO_MAX_US     = 2400U;
static constexpr uint16_t SERVO_FRAME_US   = 20000U;

struct ServoChannel {
    uint8_t  pin;
    uint8_t  type;
    bool     active;
    uint16_t pulseUs;
#if defined(__AVR__)
    volatile uint8_t* outPort;
    uint8_t  bitMask;
#endif
};

static volatile ServoChannel channels[SERVO_MAX_COUNT] = {
#if defined(__AVR__)
    {0U, SERVO_TYPE_180, false, SERVO_NEUTRAL_US, NULL, 0U},
    {0U, SERVO_TYPE_180, false, SERVO_NEUTRAL_US, NULL, 0U},
    {0U, SERVO_TYPE_180, false, SERVO_NEUTRAL_US, NULL, 0U},
    {0U, SERVO_TYPE_180, false, SERVO_NEUTRAL_US, NULL, 0U}
#else
    {0U, SERVO_TYPE_180, false, SERVO_NEUTRAL_US},
    {0U, SERVO_TYPE_180, false, SERVO_NEUTRAL_US},
    {0U, SERVO_TYPE_180, false, SERVO_NEUTRAL_US},
    {0U, SERVO_TYPE_180, false, SERVO_NEUTRAL_US}
#endif
};

#if defined(__AVR__)
// With Timer1 prescaler 8: at 16 MHz -> 2 ticks/us (0.5 us/tick)
static constexpr uint16_t TICKS_PER_US = (uint16_t)(F_CPU / 8000000UL);
static constexpr uint16_t FRAME_TICKS  = SERVO_FRAME_US * TICKS_PER_US;

static bool timer1Initialized = false;
static volatile int8_t   isrChannel = -1;
static volatile uint16_t isrFrameStart = 0U;

static void initTimer1ServoEngine() {
    if (timer1Initialized) {
        return;
    }
    noInterrupts();
    TCCR1A = 0U;
    TCCR1B = (uint8_t)(1U << CS11); // Normal mode, prescaler 8
    TCCR1C = 0U;
    TCNT1  = 0U;
    isrChannel = -1;
    isrFrameStart = 0U;
    OCR1A  = 4000U;                 // First ISR in 2 ms
    TIFR1  = (uint8_t)(1U << OCF1A);
    TIMSK1 = (uint8_t)(1U << OCIE1A);
    timer1Initialized = true;
    interrupts();
}

ISR(TIMER1_COMPA_vect) {
    if (isrChannel < 0) {
        isrFrameStart = TCNT1;
    } else if (isrChannel < (int8_t)SERVO_MAX_COUNT && channels[isrChannel].active && channels[isrChannel].outPort != NULL) {
        *(channels[isrChannel].outPort) &= (uint8_t)(~channels[isrChannel].bitMask);
    }

    isrChannel++;
    while (isrChannel < (int8_t)SERVO_MAX_COUNT) {
        if (channels[isrChannel].active && channels[isrChannel].outPort != NULL) {
            *(channels[isrChannel].outPort) |= channels[isrChannel].bitMask;
            OCR1A = (uint16_t)(TCNT1 + (channels[isrChannel].pulseUs * TICKS_PER_US));
            return;
        }
        isrChannel++;
    }

    // Wait out remainder of the 20 ms frame before starting channel 0 again
    const uint16_t elapsed = (uint16_t)(TCNT1 - isrFrameStart);
    if (elapsed < (uint16_t)(FRAME_TICKS - 400U)) {
        OCR1A = (uint16_t)(isrFrameStart + FRAME_TICKS);
    } else {
        OCR1A = (uint16_t)(TCNT1 + 400U);
    }
    isrChannel = -1;
}
#endif

static void applyPulseUs(uint8_t id, uint16_t pulseUs) {
    if (pulseUs < SERVO_MIN_US) pulseUs = SERVO_MIN_US;
    if (pulseUs > SERVO_MAX_US) pulseUs = SERVO_MAX_US;

#if defined(__AVR__)
    noInterrupts();
    channels[id].pulseUs = pulseUs;
    interrupts();
#elif defined(ESP32)
    channels[id].pulseUs = pulseUs;
    const uint32_t duty = ((uint32_t)pulseUs * 16383UL) / (uint32_t)SERVO_FRAME_US;
    ledcWrite(channels[id].pin, duty);
#else
    channels[id].pulseUs = pulseUs;
#endif
}

bool initServo(uint8_t id, uint8_t pin, uint8_t type) {
    if (id >= SERVO_MAX_COUNT) {
        return false;
    }

    pinMode(pin, OUTPUT);
    digitalWrite(pin, LOW);

#if defined(__AVR__)
    const uint8_t port = digitalPinToPort(pin);
    if (port == NOT_A_PIN) {
        return false;
    }
    volatile uint8_t* outPort = portOutputRegister(port);
    const uint8_t bitMask = digitalPinToBitMask(pin);

    noInterrupts();
    if (channels[id].active && channels[id].outPort != NULL) {
        *(channels[id].outPort) &= (uint8_t)(~channels[id].bitMask);
    }
    channels[id].pin = pin;
    channels[id].type = type;
    channels[id].pulseUs = SERVO_NEUTRAL_US;
    channels[id].outPort = outPort;
    channels[id].bitMask = bitMask;
    channels[id].active = true;
    interrupts();
    initTimer1ServoEngine();
#elif defined(ESP32)
    channels[id].pin = pin;
    channels[id].type = type;
    channels[id].pulseUs = SERVO_NEUTRAL_US;
    channels[id].active = true;
    ledcAttach(pin, 50U, 14U);
    applyPulseUs(id, SERVO_NEUTRAL_US);
#else
    channels[id].pin = pin;
    channels[id].type = type;
    channels[id].pulseUs = SERVO_NEUTRAL_US;
    channels[id].active = true;
#endif

    stopServo(id);
    return true;
}

void setServoAngle(uint8_t id, uint8_t angle) {
    if (id >= SERVO_MAX_COUNT || !channels[id].active) {
        return;
    }
    if (channels[id].type != SERVO_TYPE_180) {
        return;
    }
    if (angle > 180U) {
        angle = 180U;
    }
    const uint16_t pulseUs = (uint16_t)(SERVO_MIN_US + (((uint32_t)angle * (SERVO_MAX_US - SERVO_MIN_US)) / 180UL));
    applyPulseUs(id, pulseUs);
}

void setServoSpeed(uint8_t id, int8_t speed) {
    if (id >= SERVO_MAX_COUNT || !channels[id].active) {
        return;
    }
    if (channels[id].type != SERVO_TYPE_360) {
        return;
    }
    if (speed < -100) speed = -100;
    if (speed > 100)  speed = 100;

    const uint16_t halfSpan = (SERVO_MAX_US - SERVO_MIN_US) / 2U;
    const int32_t offset = ((int32_t)speed * (int32_t)halfSpan) / 100L;
    applyPulseUs(id, (uint16_t)((int32_t)SERVO_NEUTRAL_US + offset));
}

void stopServo(uint8_t id) {
    if (id >= SERVO_MAX_COUNT || !channels[id].active) {
        return;
    }
    if (channels[id].type == SERVO_TYPE_360) {
        applyPulseUs(id, SERVO_NEUTRAL_US);
    }
}
