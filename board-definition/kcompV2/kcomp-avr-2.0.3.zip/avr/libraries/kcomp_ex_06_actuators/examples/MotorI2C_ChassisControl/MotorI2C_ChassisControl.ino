/*
  Example: I2C Dual DC Motor Shield (TB6612FNG)
  Task:    Interactive bench test for individual motors and 2WD chassis moves.
  Pins:    I2C (SDA A4, SCL A5, 0x30) + EXTERNAL motor power (do NOT draw from USB 5V!)
  Monitor: Serial Monitor at 115200 baud (send 0-9, e, b, c)
*/

#include <kcomp_motor_i2c.h>

bool wasBusy = false;

void printMenu() {
  Serial.println("
=== K-COMP I2C DUAL MOTOR BENCH TEST (A & B @ 0x30) ===");
  Serial.println(" [1/2/3] Motor A: Forward 2s | Reverse 2s | Turn +90 deg");
  Serial.println(" [4/5/6] Motor B: Forward 2s | Reverse 2s | Turn +90 deg");
  Serial.println(" [7/8]   Chassis: Forward 2s | Backward 2s");
  Serial.println(" [9/0]   Chassis: Pivot +90 deg | Pivot -180 deg");
  Serial.println(" [e]     Endless Forward 50%");
  Serial.println(" [b/c]   Short Brake | Coast");
  Serial.println("=======================================================");
}

void setup() {
  Serial.begin(115200);
  delay(200);

  if (!initMotorI2C(MOTOR_ADDR_0x30)) {
    Serial.println("Error: No ACK from Motor Shield at 0x30! Check I2C wiring & external power.");
    while (1) { delay(100); }
  }

  setMotorInvert(false, false);
  setMotorRPM(200);
  setMotorTurnCalibration(450, 60);

  Serial.println("Motor Shield found at 0x30!");
  printMenu();
}

void loop() {
  // MANDATORY: Call updateMotors() every loop() for timed stops and I2C keep-alive!
  updateMotors();

  bool busyNow = isMotorBusy();
  if (wasBusy && !busyNow) {
    Serial.println("-> Motion complete (auto-braked).");
  }
  wasBusy = busyNow;

  if (Serial.available() > 0) {
    char cmd = Serial.read();
    switch (cmd) {
      case '1': Serial.println("Motor A Forward 60% (2s)");   setMotorASpeed(60, 2000); break;
      case '2': Serial.println("Motor A Reverse -60% (2s)");  setMotorASpeed(-60, 2000); break;
      case '3': Serial.println("Motor A Shaft +90 deg");      turnMotorShaftAngle(MOTOR_A, 90, 60); break;
      case '4': Serial.println("Motor B Forward 60% (2s)");   setMotorBSpeed(60, 2000); break;
      case '5': Serial.println("Motor B Reverse -60% (2s)");  setMotorBSpeed(-60, 2000); break;
      case '6': Serial.println("Motor B Shaft +90 deg");      turnMotorShaftAngle(MOTOR_B, 90, 60); break;
      case '7': Serial.println("Chassis Forward 60% (2s)");   driveMotorForward(60, 2000); break;
      case '8': Serial.println("Chassis Backward 60% (2s)");  driveMotorBackward(60, 2000); break;
      case '9': Serial.println("Chassis Pivot +90 deg");      turnMotorChassisAngle(90, 60); break;
      case '0': Serial.println("Chassis Pivot -180 deg");     turnMotorChassisAngle(-180, 60); break;
      case 'e':
      case 'E': Serial.println("Endless Forward 50% (b/c to stop)"); driveMotorForward(50); break;
      case 'b':
      case 'B': Serial.println("Brake"); brakeMotors(); break;
      case 'c':
      case 'C': Serial.println("Coast"); coastMotors(); break;
      case '
':
      case '': break;
      default: printMenu(); break;
    }
  }
}
