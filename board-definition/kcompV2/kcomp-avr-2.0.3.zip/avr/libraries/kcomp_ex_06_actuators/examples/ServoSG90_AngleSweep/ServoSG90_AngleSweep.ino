/*
  Example: SG90 Micro Servo (180-deg Positional & 360-deg Continuous)
  Task:    Sweeps a 180-deg servo by angle (plus commented 360-deg speed demo).
  Pins:    Signal on D6 (Note: uses Timer1 — do not use analogWrite on D9/D10!)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_servo_sg90.h>

#define SERVO0_PIN 6
#define SERVO0_ID  0

// Optional second 360-degree continuous rotation servo:
// #define SERVO1_PIN 7
// #define SERVO1_ID  1

void setup() {
  Serial.begin(115200);
  Serial.println("--- SG90 Servo Test ---");

  // 180-degree positional servo (controlled via setServoAngle 0..180)
  initServo(SERVO0_ID, SERVO0_PIN, SERVO_TYPE_180);

  // 360-degree continuous servo (controlled via setServoSpeed -100..+100 and stopServo)
  // initServo(SERVO1_ID, SERVO1_PIN, SERVO_TYPE_360);

  Serial.println("System Ready.");
}

void loop() {
  // --- PART 1: 180-degree Positional Servo (Angle) ---
  Serial.println("Servo0 -> 0 degrees");
  setServoAngle(SERVO0_ID, 0);
  delay(1000);

  Serial.println("Servo0 -> 90 degrees");
  setServoAngle(SERVO0_ID, 90);
  delay(1000);

  Serial.println("Servo0 -> 180 degrees");
  setServoAngle(SERVO0_ID, 180);
  delay(1000);

  // --- PART 2: 360-degree Continuous Servo (Speed) ---
  /*
  Serial.println("Servo1 -> Forward 50% speed");
  setServoSpeed(SERVO1_ID, 50);
  delay(2000);

  Serial.println("Servo1 -> STOP");
  stopServo(SERVO1_ID);
  delay(1000);

  Serial.println("Servo1 -> Reverse -100% speed");
  setServoSpeed(SERVO1_ID, -100);
  delay(2000);

  stopServo(SERVO1_ID);
  delay(1000);
  */
}
