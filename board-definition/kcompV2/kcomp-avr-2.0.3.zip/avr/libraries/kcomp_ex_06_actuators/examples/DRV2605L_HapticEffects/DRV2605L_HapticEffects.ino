/*
  Example: DRV2605L Haptic Motor Driver
  Task:    Plays single ROM effects, 8-slot sequences, real-time, and audio mode.
  Pins:    I2C bus (SDA A4, SCL A5, address 0x5A)
  Monitor: Serial Monitor at 115200 baud (send 0-4)
*/

#include <kcomp_drv2605l.h>

void setup() {
  Serial.begin(115200);

  if (!initDRV2605L()) {
    Serial.println("Error: DRV2605L not found! Check I2C wiring.");
    while (1) { delay(100); }
  }

  Serial.println("--- DRV2605L Tactile Interface Ready ---");
  Serial.println("1: Single ROM Effect (Strong Click)");
  Serial.println("2: Multi-Slot Sequence (Slots 0..6 + VIBE_STOP)");
  Serial.println("3: Real-Time Playback (3-Second Custom Vibe)");
  Serial.println("4: Audio-to-Vibe Mode (IN pin)");
  Serial.println("0: Stop Motor / Return to ROM Mode");
}

void loop() {
  if (Serial.available() > 0) {
    char cmd = Serial.read();
    while (Serial.available()) Serial.read();

    if (cmd == '1') {
      Serial.println(">> Playing single ROM effect...");
      playDRV2605LEffect(VIBE_STRONG_CLICK_100);
    } else if (cmd == '2') {
      Serial.println(">> Playing multi-slot sequence...");
      setDRV2605LRomMode();

      setDRV2605LSequenceSlot(0, VIBE_SOFT_BUMP_100);
      setDRV2605LSequenceSlot(1, VIBE_SHARP_TICK_100);
      setDRV2605LSequenceSlot(2, VIBE_SHARP_TICK_100);
      setDRV2605LSequenceSlot(3, VIBE_RAMP_UP_SHORT);
      setDRV2605LSequenceSlot(4, VIBE_STRONG_CLICK_100);
      setDRV2605LSequenceSlot(5, VIBE_RAMP_DOWN_SHORT);
      setDRV2605LSequenceSlot(6, VIBE_SOFT_FUZZ_60);
      // VIBE_STOP (0) marks the end of the sequence — just like '\0' in a C string!
      setDRV2605LSequenceSlot(7, VIBE_STOP);

      playDRV2605LSequence();
    } else if (cmd == '3') {
      Serial.println(">> Real-Time Playback: 50% power for 3 seconds...");
      setDRV2605LRealTimeMode();
      setDRV2605LIntensity(127);
      delay(3000);
      setDRV2605LIntensity(0);
      setDRV2605LRomMode();
      Serial.println(">> Done.");
    } else if (cmd == '4') {
      Serial.println(">> Audio-to-Vibe mode active (feed analog audio to IN pin).");
      setDRV2605LAudioMode();
    } else if (cmd == '0') {
      Serial.println(">> Stopped. Returned to ROM mode.");
      setDRV2605LRomMode();
      stopDRV2605L();
    }
  }
}
