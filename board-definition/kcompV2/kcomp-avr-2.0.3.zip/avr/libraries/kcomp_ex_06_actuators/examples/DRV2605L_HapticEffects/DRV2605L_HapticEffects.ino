/*
  Program Title: Simple DRV2605L Haptic Driver Demo
  Author: Andreas Kucher
  License: MIT

  Demonstrates single ROM effects, an 8-slot haptic sequence, and real-time
  vibration control over I2C (address 0x5A). Send '1', '2', '3', or '0' in Serial Monitor.
*/

#include <kcomp_drv2605l.h>

void setup() {
  Serial.begin(115200);

  if (!initDRV2605L()) {
    Serial.println(F("Error: DRV2605L not found! Check I2C wiring."));
    while (1) {}
  }

  Serial.println(F("DRV2605L ready. Commands: 1=Sequence, 2=Audio mode, 3=Real-time pulse, 0=Stop"));
}

void loop() {
  if (Serial.available() > 0) {
    char cmd = (char)Serial.read();
    while (Serial.available() > 0) {
      Serial.read();
    }

    if (cmd == '1') {
      setDRV2605LRomMode();
      setDRV2605LSequenceSlot(0, VIBE_SOFT_BUMP_100);
      setDRV2605LSequenceSlot(1, VIBE_SHARP_TICK_100);
      setDRV2605LSequenceSlot(2, VIBE_STRONG_CLICK_100);
      setDRV2605LSequenceSlot(3, VIBE_RAMP_DOWN_SHORT);
      setDRV2605LSequenceSlot(4, VIBE_STOP);
      playDRV2605LSequence();
    } else if (cmd == '2') {
      setDRV2605LAudioMode();
    } else if (cmd == '3') {
      setDRV2605LRealTimeMode();
      setDRV2605LIntensity(128);
      delay(500);
      setDRV2605LIntensity(0);
      setDRV2605LRomMode();
    } else if (cmd == '0') {
      setDRV2605LRomMode();
      stopDRV2605L();
    }
  }
}
