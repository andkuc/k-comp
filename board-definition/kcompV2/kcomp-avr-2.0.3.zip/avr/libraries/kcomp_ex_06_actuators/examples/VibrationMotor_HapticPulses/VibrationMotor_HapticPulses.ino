/*
  Program Title: Simple PWM Vibration Motor Demo
  Author: Andreas Kucher
  License: MIT

  Demonstrates steady vibration and non-blocking vibration pulses on a PWM
  pin at 115200 baud. Send '1', '2', '3', or '0' in Serial Monitor.
*/

#include <kcomp_vibration_motor.h>
#define VIB_PIN 6

void setup() {
  Serial.begin(115200);
  initVibrationMotor(VIB_PIN);
  Serial.println(F("Vibration motor ready. Commands: 1=Short pulse, 2=Long pulse, 3=50% ON, 0=Stop"));
}

void loop() {
  updateVibrationMotor();

  if (Serial.available() > 0) {
    char cmd = (char)Serial.read();
    while (Serial.available() > 0) {
      Serial.read();
    }

    if (cmd == '1') {
      pulseVibrationMotor(255, 200);
    } else if (cmd == '2') {
      pulseVibrationMotor(150, 800);
    } else if (cmd == '3') {
      setVibrationMotor(128);
    } else if (cmd == '0') {
      stopVibrationMotor();
    }
  }
}
