/*
  Example: PWM Vibration Motor Module
  Task:    Triggers non-blocking timed vibration pulses and steady PWM power.
  Pins:    PWM-capable digital pin D6 (valid AVR PWM pins: D3, D5, D6, D9, D10, D11)
  Monitor: Serial Monitor at 115200 baud (send 0-3)
*/

#include <kcomp_vibration_motor.h>

#define VIBRATION_PIN 6

void setup() {
  Serial.begin(115200);
  initVibrationMotor(VIBRATION_PIN);

  Serial.println("--- Vibration Motor Ready ---");
  Serial.println("1: Short Click (Power 255, 200 ms)");
  Serial.println("2: Heavy Rumble (Power 150, 800 ms)");
  Serial.println("3: Permanent ON at 50% (Power 127)");
  Serial.println("0: Stop");
}

void loop() {
  // Keeps timed non-blocking pulses running in the background
  updateVibrationMotor();

  if (Serial.available() > 0) {
    char cmd = Serial.read();
    while (Serial.available()) Serial.read();

    if (cmd == '1') {
      Serial.println("Short Click (255, 200 ms)");
      pulseVibrationMotor(255, 200);
    } else if (cmd == '2') {
      Serial.println("Heavy Rumble (150, 800 ms)");
      pulseVibrationMotor(150, 800);
    } else if (cmd == '3') {
      Serial.println("Permanent ON (127)");
      setVibrationMotor(127);
    } else if (cmd == '0') {
      Serial.println("Stopped.");
      stopVibrationMotor();
    }
  }
}
