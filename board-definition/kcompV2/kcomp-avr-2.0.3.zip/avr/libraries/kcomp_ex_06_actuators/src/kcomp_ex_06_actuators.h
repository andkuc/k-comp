// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      ex_06_actuators
// @title       K-Comp Examples: 06_Actuators
// @targets     avr, esp32s3
// @bus         none (example collection)
// @timers      none
// @sram_bytes  0

#ifndef KCOMP_EX_06_ACTUATORS_H
#define KCOMP_EX_06_ACTUATORS_H

// Example-only library exposing '06_Actuators' directly under Examples for K-Comp V2.

#endif
