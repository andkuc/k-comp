// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      ex_05_biometrics
// @title       K-Comp Examples: 05_Biometrics
// @targets     avr, esp32s3
// @bus         none (example collection)
// @timers      none
// @sram_bytes  0

#ifndef KCOMP_EX_05_BIOMETRICS_H
#define KCOMP_EX_05_BIOMETRICS_H

// Example-only library exposing '05_Biometrics' directly under Examples for K-Comp V2.

#endif
