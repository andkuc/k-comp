/*
  Example: KY-039 Optical Pulse Detector
  Task:    Detects pulse peaks and estimates heart rate (BPM) non-blockingly.
  Pins:    Analog signal 'S' on A3
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_ky039.h>

#define KY039_PIN A3

void setup() {
  Serial.begin(115200);
  initKY039(KY039_PIN);

  // Tip: Shield the sensor from bright room lights (50 Hz flicker causes noise)
  // and rest your finger lightly without pressing too hard.
  Serial.println("KY-039 Pulse Detector Online");
  Serial.println("Place finger lightly on the sensor...");
}

void loop() {
  // Run continuously without delay() so the 20 ms filter window stays accurate
  KY039Data heart = updateKY039();

  if (heart.beatDetected) {
    Serial.print("BEAT! | BPM: ");
    Serial.print(heart.bpm);
    Serial.print(" | Delta: ");
    Serial.print(heart.intervalDiffMs);
    Serial.println(" ms");
  }
}
