/*
  Example: AS608 Optical Fingerprint Sensor Console
  Task:    Interactive menu to scan, enroll, count, delete, and clear fingerprints.
  Pins:    UART RX on D6 (to Sensor TX), TX on D7 (to Sensor RX), 3.3V power!
  Monitor: Serial Monitor at 115200 baud (send 1-5)
*/

#include <kcomp_as608.h>

#define AS608_RX_PIN 6
#define AS608_TX_PIN 7
#define AS608_BAUD   57600  // Note: 57600 baud is the upper limit for AVR SoftwareSerial

bool menuPrinted = false;

void clearSerialBuffer() {
  delay(10);
  while (Serial.available()) {
    Serial.read();
  }
}

int getNumberFromSerial() {
  while (!Serial.available()) {}
  int num = Serial.parseInt();
  clearSerialBuffer();
  return num;
}

void printMenu() {
  Serial.println("
----------------------------------");
  Serial.println("MAIN MENU - Type a number and press Enter:");
  Serial.println("  1. Scan Fingerprint");
  Serial.println("  2. Enroll New Fingerprint");
  Serial.println("  3. Check Total Enrolled Count");
  Serial.println("  4. Delete a Specific ID");
  Serial.println("  5. ERASE ENTIRE DATABASE");
  Serial.println("----------------------------------");
  Serial.print("Your choice: ");
}

void handleScan() {
  Serial.println("
>>> [MODE: SCAN FINGERPRINT]");
  Serial.println("Place your finger on the glass...");
  setAS608Led(AS608_LED_BREATHING, AS608_LED_PURPLE, 100, 0);

  int16_t id = AS608_NO_FINGER;
  while (id == AS608_NO_FINGER) {
    id = scanAS608Fingerprint();
  }

  if (id >= 0) {
    Serial.print("[GRANTED] Welcome! You are ID #");
    Serial.println(id);
    setAS608Led(AS608_LED_ALWAYS_ON, AS608_LED_BLUE, 100, 0);
  } else {
    Serial.println("[DENIED] Unknown Fingerprint.");
    setAS608Led(AS608_LED_FLASHING, AS608_LED_RED, 100, 2);
  }
  delay(2000);
}

void handleEnroll() {
  Serial.println("
>>> [MODE: ENROLL NEW USER]");
  Serial.print("Enter an ID number (1 to 127): ");
  int targetID = getNumberFromSerial();
  Serial.println(targetID);

  if (isAS608SlotOccupied(targetID)) {
    Serial.println("[WARNING] That ID is already taken! Try another one.");
  } else {
    Serial.println("Place finger, remove when prompted, then place again...");
    int8_t status = enrollAS608Fingerprint(targetID);
    if (status == AS608_OK) {
      Serial.println("[SUCCESS] Fingerprint enrolled!");
      setAS608Led(AS608_LED_FLASHING, AS608_LED_BLUE, 100, 3);
    } else {
      Serial.println("[ERROR] Enrollment failed.");
      setAS608Led(AS608_LED_FLASHING, AS608_LED_RED, 100, 3);
    }
  }
  delay(2000);
}

void handleCount() {
  Serial.println("
>>> [MODE: DATABASE COUNT]");
  int count = getAS608FingerprintCount();
  if (count >= 0) {
    Serial.print("Stored fingerprints: ");
    Serial.println(count);
  } else {
    Serial.println("[ERROR] Could not read database.");
  }
  delay(1500);
}

void handleDelete() {
  Serial.println("
>>> [MODE: DELETE SINGLE USER]");
  Serial.print("Enter the ID number to delete: ");
  int targetID = getNumberFromSerial();
  Serial.println(targetID);

  if (deleteAS608Fingerprint(targetID) == AS608_OK) {
    Serial.println("[SUCCESS] Fingerprint deleted.");
  } else {
    Serial.println("[ERROR] Could not delete slot.");
  }
  delay(1500);
}

void handleClearAll() {
  Serial.println("
>>> [MODE: FACTORY RESET]");
  Serial.println("Delete EVERY fingerprint? (y/n)");
  while (!Serial.available()) {}
  char confirm = Serial.read();
  clearSerialBuffer();

  if (confirm == 'y' || confirm == 'Y') {
    if (clearAS608Fingerprints()) {
      Serial.println("[DELETED] Database is now empty.");
      setAS608Led(AS608_LED_FLASHING, AS608_LED_RED, 50, 5);
    } else {
      Serial.println("[ERROR] Failed to wipe database.");
    }
  } else {
    Serial.println("Cancelled.");
  }
  delay(1500);
}

void setup() {
  Serial.begin(115200);
  Serial.println("
=== AS608 FINGERPRINT CONSOLE ===");

  if (initAS608(AS608_RX_PIN, AS608_TX_PIN, AS608_BAUD)) {
    Serial.println("[SUCCESS] Sensor found and ready!");
    setAS608Led(AS608_LED_FLASHING, AS608_LED_BLUE, 100, 2);
  } else {
    Serial.println("[ERROR] AS608 not found! Check TX/RX wiring and 3.3V power.");
    while (1) { delay(100); }
  }
}

void loop() {
  if (!menuPrinted) {
    printMenu();
    menuPrinted = true;
  }

  if (Serial.available() > 0) {
    char choice = Serial.read();
    clearSerialBuffer();

    switch (choice) {
      case '1': handleScan(); break;
      case '2': handleEnroll(); break;
      case '3': handleCount(); break;
      case '4': handleDelete(); break;
      case '5': handleClearAll(); break;
      default:  break;
    }

    menuPrinted = false;
    setAS608Led(AS608_LED_ALWAYS_OFF, AS608_LED_BLUE, 0, 0);
  }
}
