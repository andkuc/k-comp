/*
  Example: MAX30102 Heart Rate & SpO2 Sensor
  Task:    Drains the 100 Hz FIFO buffer and prints BPM and SpO2 (%) every 1 s.
  Pins:    I2C bus (SDA A4, SCL A5, address 0x57)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_max30102.h>

unsigned long lastPrintTime = 0;

void setup() {
  Serial.begin(115200);
  Serial.println("Initializing MAX30102...");

  if (!initMAX30102()) {
    Serial.println("Error: MAX30102 not found! Check I2C wiring.");
    while (1) { delay(100); }
  }
  Serial.println("Place finger gently on the sensor.");
}

void loop() {
  // IMPORTANT: Never use delay() in loop() here!
  // updateMAX30102() must drain the 100 Hz FIFO continuously or samples will overflow.
  updateMAX30102();

  // Print once per second using millis() instead of delay()
  if (millis() - lastPrintTime >= 1000) {
    lastPrintTime = millis();

    int bpm = getMAX30102HeartRate();
    int spo2 = getMAX30102SpO2();

    if (bpm > 0) {
      Serial.print("Heart Rate: "); Serial.print(bpm);
      Serial.print(" bpm	SpO2: ");  Serial.print(spo2);
      Serial.println(" %");
    } else {
      Serial.println("No finger detected.");
    }
  }
}
