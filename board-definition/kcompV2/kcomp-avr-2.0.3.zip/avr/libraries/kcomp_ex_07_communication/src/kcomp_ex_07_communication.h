// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      ex_07_communication
// @title       K-Comp Examples: 07_Communication
// @targets     avr, esp32s3
// @bus         none (example collection)
// @timers      none
// @sram_bytes  0

#ifndef KCOMP_EX_07_COMMUNICATION_H
#define KCOMP_EX_07_COMMUNICATION_H

// Example-only library exposing '07_Communication' directly under Examples for K-Comp V2.

#endif
