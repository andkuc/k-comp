/*
  Example: ESP8266 One-Time Baud Rate Setup Tool
  Task:    Reconfigures a factory 115200-baud ESP-01 module down to 9600 baud.
  Pins:    UART RX on D7 (to ESP TX), TX on D6 (to ESP RX), DIP S1-7/S1-8
  Monitor: Serial Monitor at 115200 baud (run ONCE before ESP8266_HttpClient)
*/

#include <kcomp_esp8266.h>

#define ESP8266_RX_PIN 7
#define ESP8266_TX_PIN 6

void setup() {
  Serial.begin(115200);
  delay(2000);

  Serial.println("ESP8266 One-Time Baud Rate Tool");
  Serial.println("Attempting to configure ESP8266 to 9600 baud...");

  if (setupESP8266BaudRate(ESP8266_RX_PIN, ESP8266_TX_PIN)) {
    Serial.println("SUCCESS: ESP8266 now responds at 9600 baud!");
  } else {
    Serial.println("ERROR: Could not reach ESP8266. Check wiring, DIP switches & 3.3V power.");
  }
}

void loop() {
  // One-time setup tool: nothing to do in loop()
  delay(1000);
}
