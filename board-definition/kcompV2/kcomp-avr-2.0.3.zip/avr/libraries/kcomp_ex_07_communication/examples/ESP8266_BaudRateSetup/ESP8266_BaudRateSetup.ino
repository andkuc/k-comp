/*
  Program Title: ESP8266 9600-Baud Configuration Tool
  Author: Andreas Kucher
  License: MIT

  One-time utility to reconfigure a factory 115200-baud ESP8266 (ESP-01)
  module down to 9600 baud for reliable SoftwareSerial operation on K-Comp V2.
*/

#include <kcomp_esp8266.h>
#define ESP_RX_PIN 7
#define ESP_TX_PIN 6

void setup() {
  Serial.begin(115200);
  delay(1500);

  Serial.println(F("Configuring ESP8266 to 9600 baud..."));
  if (setupESP8266BaudRate(ESP_RX_PIN, ESP_TX_PIN)) {
    Serial.println(F("Success! ESP8266 is ready at 9600 baud."));
  } else {
    Serial.println(F("Failed. Check power supply and RX/TX wiring."));
  }
}

void loop() {
  delay(1000);
}
