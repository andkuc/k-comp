/*
  Program Title: Simple Infrared Transmitter Demo
  Author: Andreas Kucher
  License: MIT

  Sends a NEC 21-button POWER command every 2 seconds on the configured IR LED pin.
*/

#include <kcomp_ir_transmitter.h>
#define IR_TX_PIN 2

void setup() {
  Serial.begin(115200);
  initIRTransmitter(IR_TX_PIN);
  Serial.println(F("IR transmitter ready."));
}

void loop() {
  Serial.println(F("Sending NEC POWER code..."));
  sendIR21Button(IR_BTN_POWER);
  delay(2000);
}
