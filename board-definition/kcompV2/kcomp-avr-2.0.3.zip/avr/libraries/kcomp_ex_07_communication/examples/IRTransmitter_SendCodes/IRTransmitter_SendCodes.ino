/*
  Example: Infrared TV Remote Transmitter (OLED Menu)
  Task:    Navigate with Joystick UP/DOWN, press SELECT to send Samsung IR code.
  Pins:    IR LED on D2 + onboard OLED (I2C), Joystick (A1/A2), SELECT (D4)
  Monitor: Output on OLED display (Serial Monitor optional at 115200 baud)
*/

#include <kcomp_oled.h>
#include <kcomp_joystick.h>
#include <kcomp_button_select.h>
#include <kcomp_ir_transmitter.h>
#include <kcomp_led.h>
#include <kcomp_buzzer.h>

#define IR_TX_PIN 2
#define MAX_ITEMS 5  // 6 menu entries (index 0..5)

uint8_t cursorY = 0;
bool joyNeutral = true;

const char* menuItems[] = {
  "1. TV Power",
  "2. Volume Up",
  "3. Volume Down",
  "4. Mute",
  "5. Prog +",
  "6. Prog -"
};

void onSelectClicked() {
  setLed(100);
  playBuzzerBeep(1200, 50);

  switch (cursorY) {
    case 0: sendIRSamsungTV(SAMSUNG_BTN_POWER); break;
    case 1: sendIRSamsungTV(SAMSUNG_BTN_VOL_UP); break;
    case 2: sendIRSamsungTV(SAMSUNG_BTN_VOL_DOWN); break;
    case 3: sendIRSamsungTV(SAMSUNG_BTN_MUTE); break;
    case 4: sendIRSamsungTV(SAMSUNG_BTN_CH_UP); break;
    case 5: sendIRSamsungTV(SAMSUNG_BTN_CH_DOWN); break;
  }

  setLedOff();
}

void setup() {
  Serial.begin(115200);
  initDisplay();
  initJoystick();
  initButtonSelect();
  initLed();
  initBuzzer();
  initIRTransmitter(IR_TX_PIN);

  attachButtonSelectClick(onSelectClicked);
}

void loop() {
  updateButtonSelect();
  updateBuzzer();

  // Joystick navigation (UP/DOWN) with return-to-center lock
  int joyY = -getJoystickYValue();
  if (joyY > 250 && joyNeutral) {
    if (cursorY < MAX_ITEMS) cursorY++;
    joyNeutral = false;
  } else if (joyY < -250 && joyNeutral) {
    if (cursorY > 0) cursorY--;
    joyNeutral = false;
  } else if (joyY > -100 && joyY < 100) {
    joyNeutral = true;
  }

  // Render OLED menu
  clearDisplay();
  setCursor(18, 0);
  printText("SAMSUNG REMOTE", OLED_COLOR_WHITE, 1);
  drawLine(0, 10, 128, 10, OLED_COLOR_WHITE);

  for (int i = 0; i <= MAX_ITEMS; i++) {
    int yPos = 14 + (i * 8);
    if (i == cursorY) {
      fillRect(0, yPos - 1, 128, 9, OLED_COLOR_WHITE);
      setCursor(5, yPos);
      printText(menuItems[i], OLED_COLOR_INVERT, 1);
    } else {
      setCursor(5, yPos);
      printText(menuItems[i], OLED_COLOR_WHITE, 1);
    }
  }
  updateDisplay();
}
