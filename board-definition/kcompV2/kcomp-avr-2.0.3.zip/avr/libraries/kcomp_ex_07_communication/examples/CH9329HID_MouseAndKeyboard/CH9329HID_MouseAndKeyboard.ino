/*
  Example: CH9329 USB HID Mouse & Keyboard Emulator
  Task:    Interactive test suite for relative/absolute mouse, typing, and macros.
  Pins:    UART RX on D6 (to CH9329 TX), TX on D7 (to CH9329 RX) at 9600 baud
  Monitor: Serial Monitor at 115200 baud (send 1-6)
*/

#include <kcomp_ch9329_hid.h>

#define CH9329_RX_PIN 6
#define CH9329_TX_PIN 7

void testConfig() {
  Serial.println("Configuring CH9329 to Mode 0 (PID E010)...");
  Serial.println("Please wait 3 seconds for chip restart...");
  resetCH9329Mode();
  delay(3000);
  Serial.println("Configuration packet sent.");
}

void testMouseMove() {
  Serial.println("Drawing a square with the mouse...");
  int speed = 10;
  int dist = 100;

  for (int i = 0; i < dist / speed; i++) { moveCH9329Mouse(speed, 0); delay(20); }
  delay(200);
  for (int i = 0; i < dist / speed; i++) { moveCH9329Mouse(0, speed); delay(20); }
  delay(200);
  for (int i = 0; i < dist / speed; i++) { moveCH9329Mouse(-speed, 0); delay(20); }
  delay(200);
  for (int i = 0; i < dist / speed; i++) { moveCH9329Mouse(0, -speed); delay(20); }
}

void testMouseClickScroll() {
  Serial.println("Testing Right Click...");
  clickCH9329Mouse(CH9329_MOUSE_RIGHT);
  delay(100);
  clickCH9329Mouse(0);
  delay(1000);

  Serial.println("Testing Left Click...");
  clickCH9329Mouse(CH9329_MOUSE_LEFT);
  delay(100);
  clickCH9329Mouse(0);
  delay(1000);

  Serial.println("Scrolling Down & Up...");
  for (int i = 0; i < 5; i++) { scrollCH9329Mouse(-1); delay(100); }
  for (int i = 0; i < 5; i++) { scrollCH9329Mouse(1);  delay(100); }
}

void testAbsoluteMouse() {
  Serial.println("Moving to (0,0) -> (200,0) -> (0,200) -> (200,200)...");
  moveCH9329MouseAbsolute(0, 0);     delay(1000);
  moveCH9329MouseAbsolute(200, 0);   delay(1000);
  moveCH9329MouseAbsolute(0, 200);   delay(1000);
  moveCH9329MouseAbsolute(200, 200); delay(1000);
}

void testTyping() {
  Serial.println("Typing text in 2 seconds (focus a text box)...");
  delay(2000);
  typeCH9329Text("Hello! This is the CH9329 Library.");
  writeCH9329Key(KEY_RETURN);
  typeCH9329Text("It supports Symbols: !@#$%^&*()");
  writeCH9329Key(KEY_RETURN);
}

void testMacro() {
  Serial.println("Executing Macro: Win+R -> notepad...");
  pressCH9329Key(KEY_LEFT_GUI);
  writeCH9329Key('r');
  releaseCH9329AllKeys();
  delay(500);

  typeCH9329Text("notepad");
  delay(100);
  writeCH9329Key(KEY_RETURN);
  delay(1000);
  typeCH9329Text("Automation successful!");
}

void setup() {
  Serial.begin(115200);
  initCH9329(CH9329_RX_PIN, CH9329_TX_PIN);

  Serial.println("
=== CH9329 USB HID TEST SUITE ===");
  Serial.println("1. Force Mode 0 Config");
  Serial.println("2. Relative Mouse Square");
  Serial.println("3. Mouse Click & Scroll");
  Serial.println("4. Absolute Mouse Positions");
  Serial.println("5. Keyboard Typing");
  Serial.println("6. Macro (Open Notepad)");
  Serial.println("Enter a number (1-6):");
}

void loop() {
  if (Serial.available() > 0) {
    char cmd = Serial.read();
    while (Serial.available()) Serial.read();

    switch (cmd) {
      case '1': testConfig(); break;
      case '2': testMouseMove(); break;
      case '3': testMouseClickScroll(); break;
      case '4': testAbsoluteMouse(); break;
      case '5': testTyping(); break;
      case '6': testMacro(); break;
      default:  Serial.println("Unknown command."); break;
    }
    Serial.println("
Done. Select another test (1-6):");
  }
}
