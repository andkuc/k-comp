/*
  Program Title: Simple 21-Button NEC IR Receiver Demo
  Author: Andreas Kucher
  License: MIT

  Receives 32-bit NEC infrared codes on an interrupt pin (D2 or D3 on K-Comp V2)
  and prints them to the Serial Monitor at 115200 baud.
*/

#include <kcomp_ir_receiver_21_button.h>
#define IR_RX_PIN 2

void setup() {
  Serial.begin(115200);
  initIRReceiver(IR_RX_PIN);
  Serial.println(F("IR receiver ready. Press a button on the 21-button remote..."));
}

void loop() {
  if (isIRAvailable()) {
    uint32_t cmd = getIRCommand();
    Serial.print(F("Received NEC code: 0x"));
    Serial.println(cmd, HEX);
  }
}
