/*
  Example: 21-Button NEC Infrared Receiver
  Task:    Decodes 32-bit NEC IR remote codes via external pin interrupt.
  Pins:    IR receiver on D2 (MUST be an interrupt pin: D2 or D3 on K-Comp V2!)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_ir_receiver_21_button.h>
#include <kcomp_led.h>
#include <kcomp_buzzer.h>

#define IR_RX_PIN 2

void setup() {
  Serial.begin(115200);
  initLed();
  initBuzzer();
  initIRReceiver(IR_RX_PIN);

  Serial.println("=== 21-Button IR Receiver Online ===");
  Serial.println("Press buttons on your remote...");
}

void loop() {
  // Keeps non-blocking buzzer beeps running in the background
  updateBuzzer();

  if (isIRAvailable()) {
    uint32_t irCommand = getIRCommand();
    Serial.print("Raw Hex Received: 0x");
    Serial.println(irCommand, HEX);

    switch (irCommand) {
      case IR_BTN_PLAY:
        Serial.println("Action: PLAY -> Tone");
        setLedOff();
        playBuzzerBeep(800, 200);
        break;

      case IR_BTN_VOL_UP:
        Serial.println("Action: VOL UP -> Bright Flash");
        setLed(100);
        playBuzzerBeep(1000, 100);
        break;

      case IR_BTN_VOL_DOWN:
        Serial.println("Action: VOL DOWN -> Dim Flash");
        setLed(10);
        playBuzzerBeep(400, 100);
        break;

      case IR_BTN_EQ:
        Serial.println("Action: EQ -> Long Warning Tone");
        setLedOff();
        playBuzzerBeep(200, 1000);
        break;

      default:
        setLedOff();
        break;
    }
  }
}
