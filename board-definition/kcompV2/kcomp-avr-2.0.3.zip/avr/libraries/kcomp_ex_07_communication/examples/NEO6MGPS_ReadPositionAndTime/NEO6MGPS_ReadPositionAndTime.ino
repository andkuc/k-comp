/*
  Program Title: Simple GY-NEO6M GPS Receiver Demo
  Author: Andreas Kucher
  License: MIT

  Parses NMEA GPS coordinates, speed, and local time over UART at 9600 baud
  (SoftwareSerial on AVR, Serial1 on ESP32-S3).
*/

#include <kcomp_neo6m_gps.h>
#define GPS_RX_PIN 6
#define GPS_TX_PIN 7

void setup() {
  Serial.begin(115200);
  if (!initGPS(GPS_RX_PIN, GPS_TX_PIN, 9600)) {
    Serial.println(F("Error: GPS module not responding! Check RX/TX wiring."));
    while (1) {}
  }
  setGPSTimezoneOffset(1);  // UTC+1 (CET)
  Serial.println(F("GPS initialized. Waiting for satellite fix..."));
}

void loop() {
  if (updateGPS()) {
    GPSData gps = getGPSData();
    if (gps.valid) {
      Serial.print(F("Lat: "));
      Serial.print(gps.latitude, 6);
      Serial.print(F(" | Lon: "));
      Serial.print(gps.longitude, 6);
      Serial.print(F(" | Sats: "));
      Serial.println(gps.satellites);
    }
  }
}
