/*
  Example: GY-NEO6M GPS Position, Local Time & Navigation
  Task:    Verifies NMEA UART link, parses GPS fix, and computes bearing/distance.
  Pins:    UART RX on D6 (to GPS TX), TX on D7 (to GPS RX) at 9600 baud
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_neo6m_gps.h>

#define GPS_RX_PIN 6
#define GPS_TX_PIN 7
#define GPS_BAUD   9600

// Example destination: London, UK
#define DEST_LAT 51.5074
#define DEST_LON -0.1278

void printCardinalText(GPSCardinal c) {
  switch (c) {
    case CARDINAL_N:  Serial.print("North"); break;
    case CARDINAL_NE: Serial.print("North-East"); break;
    case CARDINAL_E:  Serial.print("East"); break;
    case CARDINAL_SE: Serial.print("South-East"); break;
    case CARDINAL_S:  Serial.print("South"); break;
    case CARDINAL_SW: Serial.print("South-West"); break;
    case CARDINAL_W:  Serial.print("West"); break;
    case CARDINAL_NW: Serial.print("North-West"); break;
    default:          Serial.print("Unknown"); break;
  }
}

void setup() {
  Serial.begin(115200);
  Serial.println("--- K-Comp NEO-6M GPS Demo ---");

  // initGPS() verifies valid NMEA traffic (proves wiring & power even indoors).
  // A satellite fix (gps.valid == true) additionally requires a clear sky view!
  if (!initGPS(GPS_RX_PIN, GPS_TX_PIN, GPS_BAUD)) {
    Serial.println("Error: No valid NMEA data from NEO-6M! Check RX/TX wiring & power.");
    while (1) { delay(100); }
  }

  // Configure local timezone (Austria/Germany: CET = +1, DST = true in summer)
  setGPSTimezoneOffset(1);
  setGPSDST(false);

  Serial.println("GPS module connected (NMEA OK). Waiting for satellite fix...");
}

void loop() {
  // Continuously feed updateGPS() for 1 second (never use delay(1000)!)
  unsigned long start = millis();
  while (millis() - start < 1000) {
    updateGPS();
  }

  GPSData gps = getGPSData();
  Serial.println("
-------------------------------------------");

  if (gps.valid) {
    Serial.println("[ STATUS: SATELLITE FIX ACTIVE ]");

    Serial.print("Local Time: ");
    if (gps.hour < 10) Serial.print("0");   Serial.print(gps.hour);   Serial.print(":");
    if (gps.minute < 10) Serial.print("0"); Serial.print(gps.minute); Serial.print(":");
    if (gps.second < 10) Serial.print("0"); Serial.println(gps.second);

    Serial.print("Date:       ");
    if (gps.day < 10) Serial.print("0");   Serial.print(gps.day);   Serial.print(".");
    if (gps.month < 10) Serial.print("0"); Serial.print(gps.month); Serial.print(".");
    Serial.println(gps.year);

    Serial.print("Latitude:   "); Serial.print(gps.latitude, 6);  Serial.println(" deg");
    Serial.print("Longitude:  "); Serial.print(gps.longitude, 6); Serial.println(" deg");
    Serial.print("Altitude:   "); Serial.print(gps.altitude);     Serial.println(" m");

    Serial.print("Speed:      "); Serial.print(gps.speedKmh);  Serial.println(" km/h");
    Serial.print("Heading:    "); Serial.print(gps.courseDeg); Serial.print(" deg (");
    printCardinalText(getGPSCardinal(gps.courseDeg));
    Serial.println(")");

    Serial.print("Satellites: "); Serial.print(gps.satellites);
    Serial.print(" | HDOP: ");    Serial.println(gps.hdop);

    double dist = getGPSDistanceMeters(gps.latitude, gps.longitude, DEST_LAT, DEST_LON);
    double bear = getGPSCourseDeg(gps.latitude, gps.longitude, DEST_LAT, DEST_LON);
    Serial.print("To London:  "); Serial.print(dist / 1000.0); Serial.print(" km @ ");
    Serial.print(bear); Serial.println(" deg");
  } else {
    Serial.println("[ STATUS: SEARCHING FOR SATELLITES... ]");
    Serial.print("Satellites visible: "); Serial.println(gps.satellites);
    Serial.println("Go outside or near a window for a clear sky view.");
  }
}
