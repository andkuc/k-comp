/*
  Example: PN532 NFC / RFID Tag Reader & Writer
  Task:    Reads and writes a 16-byte text block on MIFARE Classic or NTAG tags.
  Pins:    I2C bus (SDA A4, SCL A5, address 0x24; set PN532 DIP to I2C mode)
  Monitor: Serial Monitor at 115200 baud (send 'r' to read, 'w' to write)
*/

#include <kcomp_pn532.h>

// Safe user data slot. WARNING for MIFARE Classic: NEVER write to sector trailer
// blocks (3, 7, 11, 15, ...), or you can permanently lock that sector!
#define PN532_TARGET_SLOT 4

uint8_t globalDataToWrite[16] = "Hello, K-Comp!!";
uint8_t dataBuffer[16];

void setup() {
  Serial.begin(115200);
  Serial.println("=== PN532 NFC TERMINAL ===");

  if (!initPN532()) {
    Serial.println("Error: PN532 not found! Check I2C wiring & DIP switches.");
    while (1) { delay(100); }
  }

  Serial.println("Menu: [r] Read tag | [w] Write tag");
}

void loop() {
  if (Serial.available() > 0) {
    char command = Serial.read();
    while (Serial.available() > 0) {
      Serial.read();
      delay(2);
    }

    if (command == 'r' || command == 'R') {
      Serial.println("
>> READ MODE: Hold tag on reader...");
      while (scanPN532Tag() != PN532_OK) {
        delay(100);
      }

      if (readPN532TagMemory(PN532_TARGET_SLOT, dataBuffer) == PN532_OK) {
        Serial.print(">> Slot 4 Data: [ ");
        for (int i = 0; i < 16; i++) {
          if (dataBuffer[i] >= 32 && dataBuffer[i] <= 126) {
            Serial.print((char)dataBuffer[i]);
          } else {
            Serial.print(".");
          }
        }
        Serial.println(" ]");
      } else {
        Serial.println(">> Read failed.");
      }

      delay(2000);
      Serial.println("Menu: [r] Read tag | [w] Write tag");
    } else if (command == 'w' || command == 'W') {
      Serial.println("
>> WRITE MODE: Hold tag on reader...");
      while (scanPN532Tag() != PN532_OK) {
        delay(100);
      }

      if (writePN532TagMemory(PN532_TARGET_SLOT, globalDataToWrite) == PN532_OK) {
        Serial.println(">> Write successful!");
      } else {
        Serial.println(">> Write failed.");
      }

      delay(2000);
      Serial.println("Menu: [r] Read tag | [w] Write tag");
    } else {
      Serial.println("Invalid command. Send 'r' or 'w'.");
    }
  }
}
