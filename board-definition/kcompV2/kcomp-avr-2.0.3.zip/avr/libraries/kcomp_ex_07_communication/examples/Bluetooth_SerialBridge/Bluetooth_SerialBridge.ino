/*
  Example: Bluetooth HC-05 / HC-06 Serial Bridge
  Task:    Forwards text bidirectionally between USB Serial (PC) and Bluetooth.
  Pins:    BT RX on D7 (to HC-05 TX), BT TX on D6 (to HC-05 RX), DIP S1-7/S1-8
  Monitor: Serial Monitor at 115200 baud (Bluetooth UART runs at 9600 baud)
*/

#include <SoftwareSerial.h>

#define BT_RX_PIN 7
#define BT_TX_PIN 6

// SoftwareSerial talks to the HC-05/06 module (9600 baud),
// while hardware Serial talks to your PC over USB (115200 baud).
SoftwareSerial BTSerial(BT_RX_PIN, BT_TX_PIN);

void setup() {
  Serial.begin(115200);
  BTSerial.begin(9600);
}

void loop() {
  if (BTSerial.available()) {
    Serial.write(BTSerial.read());
  }

  if (Serial.available()) {
    BTSerial.write(Serial.read());
  }
}
