/*
  Program Title: Simple ESP8266 WiFi HTTP Client Demo
  Author: Andreas Kucher
  License: MIT

  Connects an ESP-01 (ESP8266 AT firmware at 9600 baud) to WiFi and performs
  an HTTP GET request over UART (SoftwareSerial on AVR, Serial1 on ESP32-S3).
*/

#include <kcomp_esp8266.h>
#define ESP_RX_PIN 7
#define ESP_TX_PIN 6

const char* WIFI_SSID = "your_ssid";
const char* WIFI_PASS = "your_password";

void setup() {
  Serial.begin(115200);
  delay(1000);

  if (!initESP8266(ESP_RX_PIN, ESP_TX_PIN, WIFI_SSID, WIFI_PASS)) {
    Serial.println(F("Error: WiFi connection failed!"));
    while (1) {}
  }

  printESP8266WifiStatus();
}

void loop() {
  if (connectESP8266Server("httpbin.org", 80)) {
    printESP8266Line("GET /get HTTP/1.1");
    printESP8266Line("Host: httpbin.org");
    printESP8266Line("Connection: close");
    printESP8266Line("");

    unsigned long lastByteMs = millis();
    while ((millis() - lastByteMs) < 5000) {
      while (getESP8266Available() > 0) {
        Serial.write((uint8_t)readESP8266());
        lastByteMs = millis();
      }
    }
    stopESP8266();
  }

  delay(10000);
}
