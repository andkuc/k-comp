/*
  Example: ESP8266 WiFi HTTP/HTTPS Client
  Task:    Joins WiFi, syncs NTP time (for TLS/SSL), and sends an HTTP GET request.
  Pins:    UART RX on D7 (to ESP TX), TX on D6 (to ESP RX) at 9600 baud
  Monitor: Serial Monitor at 115200 baud (run ESP8266_BaudRateSetup first!)
*/

#include <kcomp_esp8266.h>

#define ESP8266_RX_PIN 7
#define ESP8266_TX_PIN 6

// >>> CHANGE THESE TO YOUR WIFI CREDENTIALS <<<
const char* WIFI_SSID = "your_ssid";
const char* WIFI_PASS = "your_password";

const char* SERVER_DOMAIN = "httpbin.org";
int SERVER_PORT = 80;  // Use 443 for HTTPS (SSL/TLS)

void setup() {
  Serial.begin(115200);
  delay(2000);
  Serial.println("Initializing ESP8266 WiFi Client...");

  if (!initESP8266(ESP8266_RX_PIN, ESP8266_TX_PIN, WIFI_SSID, WIFI_PASS)) {
    Serial.println("Error: WiFi connection failed! Check SSID/password, wiring & 9600 baud.");
    while (1) { delay(100); }
  }

  Serial.println("WiFi connected!");

  // NTP time sync is required so HTTPS/SSL certificates can be validated
  syncESP8266Time(1);
  setESP8266SSLBufferSize(8192);
  printESP8266WifiStatus();
}

void loop() {
  Serial.println("
--- Starting HTTP Request ---");

  if (connectESP8266Server(SERVER_DOMAIN, SERVER_PORT)) {
    Serial.println("Connected to server!");

    printESP8266Line("GET /get HTTP/1.1");
    printESP8266Line("Host: httpbin.org");
    printESP8266Line("Connection: close");
    printESP8266Line("");

    unsigned long timeout = millis();
    while (millis() - timeout < 5000) {
      while (getESP8266Available()) {
        char c = readESP8266();
        Serial.write(c);
        timeout = millis();
      }
    }

    Serial.println("
--- End of Response ---");
    stopESP8266();
  } else {
    Serial.println("Connection to server failed.");
  }

  delay(10000);
}
