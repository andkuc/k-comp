// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      ex_04_motion_power
// @title       K-Comp Examples: 04_Motion_Power
// @targets     avr, esp32s3
// @bus         none (example collection)
// @timers      none
// @sram_bytes  0

#ifndef KCOMP_EX_04_MOTION_POWER_H
#define KCOMP_EX_04_MOTION_POWER_H

// Example-only library exposing '04_Motion_Power' directly under Examples for K-Comp V2.

#endif
