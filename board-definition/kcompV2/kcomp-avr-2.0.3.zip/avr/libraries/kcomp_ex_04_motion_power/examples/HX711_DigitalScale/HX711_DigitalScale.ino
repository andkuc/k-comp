/*
  Example: HX711 Digital Weigh Scale
  Task:    Tares a load cell and prints calibrated weight in grams.
  Pins:    DOUT on D3, SCK on D8
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_hx711.h>

#define HX711_DT_PIN  3
#define HX711_SCK_PIN 8

void setup() {
  Serial.begin(115200);

  if (!initHX711(HX711_DT_PIN, HX711_SCK_PIN)) {
    Serial.println("Error: HX711 not found! Check DT and SCK wiring.");
    while (1) { delay(100); }
  }

  // 2-step calibration: (1) Tare empty platform with tareHX711(),
  // (2) Optionally place a known weight and call calibrateHX711(knownGrams).
  setHX711Scale(HX711_SCALE_1KG);

  Serial.println("Taring scale... Keep platform empty.");
  tareHX711(10);
  Serial.println("Scale Ready!");
}

void loop() {
  float weightGrams = getHX711Weight_g(5);

  Serial.print("Weight: ");
  Serial.print(weightGrams, 1);
  Serial.println(" g");

  delay(250);
}
