/*
  Program Title: Simple HX711 Load Cell Scale Demo
  Author: Andreas Kucher
  License: MIT

  Initializes an HX711 24-bit load cell amplifier, tares the empty platform,
  and prints averaged weight readings in grams at 115200 baud.
*/

#include <kcomp_hx711.h>
#define HX711_DOUT_PIN 3
#define HX711_SCK_PIN 8

void setup() {
  Serial.begin(115200);

  if (!initHX711(HX711_DOUT_PIN, HX711_SCK_PIN)) {
    Serial.println(F("Error: HX711 not found! Check DOUT and SCK wiring."));
    while (1) {}
  }

  setHX711Scale(HX711_SCALE_1KG);
  Serial.println(F("Taring scale... Keep platform empty."));
  tareHX711(10);
  Serial.println(F("Scale ready."));
}

void loop() {
  float weightGrams = getHX711Weight_g(5);
  Serial.print(F("Weight: "));
  Serial.print(weightGrams, 1);
  Serial.println(F(" g"));

  delay(250);
}
