/*
  Program Title: Simple HLK-LD2410C Presence Radar Demo
  Author: Andreas Kucher
  License: MIT

  Reads presence, motion state, and distance (cm) from an HLK-LD2410C
  24 GHz radar over UART at 9600 baud (SoftwareSerial on AVR, Serial1 on ESP32-S3).
*/

#include <kcomp_ld2410.h>
#define RADAR_RX_PIN 6
#define RADAR_TX_PIN 7

void setup() {
  Serial.begin(115200);

  if (!initLD2410(RADAR_RX_PIN, RADAR_TX_PIN, 9600)) {
    Serial.println(F("Error: LD2410C not responding! Check wiring and baud rate."));
    while (1) {}
  }

  Serial.println(F("LD2410C radar initialized."));
}

void loop() {
  if (updateLD2410()) {
    if (isLD2410PresenceDetected()) {
      Serial.print(F("Presence | Dist: "));
      Serial.print(getLD2410DistanceCM());
      Serial.print(F(" cm | Moving: "));
      Serial.print(isLD2410Moving() ? F("YES") : F("NO"));
      Serial.print(F(" | Stationary: "));
      Serial.println(isLD2410Stationary() ? F("YES") : F("NO"));
    }
  }
}
