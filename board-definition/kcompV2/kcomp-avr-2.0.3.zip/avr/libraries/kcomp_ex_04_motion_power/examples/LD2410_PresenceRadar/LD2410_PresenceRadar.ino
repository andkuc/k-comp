/*
  Example: HLK-LD2410C 24 GHz Human Presence Radar
  Task:    Detects moving and stationary human presence plus target distance (cm).
  Pins:    UART RX on D6 (to Sensor TX), TX on D7 (to Sensor RX) at 9600 baud
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_ld2410.h>

#define LD2410_RX_PIN 6
#define LD2410_TX_PIN 7

void setup() {
  Serial.begin(115200);
  Serial.println("LD2410C Radar Test");

  // Note: Factory-new LD2410 modules often ship at 256000 baud.
  // For AVR SoftwareSerial, set the sensor once to 9600 baud first.
  if (!initLD2410(LD2410_RX_PIN, LD2410_TX_PIN, 9600)) {
    Serial.println("Error: LD2410 not found! Check wiring (Sensor TX->D6, RX->D7) and 9600 baud.");
    while (1) { delay(100); }
  }
  Serial.println("LD2410 Connected!");
}

void loop() {
  if (updateLD2410()) {
    if (isLD2410PresenceDetected()) {
      Serial.print("Target Distance: ");
      Serial.print(getLD2410DistanceCM());
      Serial.print(" cm");

      if (isLD2410Moving())     Serial.print(" [Moving]");
      if (isLD2410Stationary()) Serial.print(" [Static]");
      Serial.println();
    }
  }
}
