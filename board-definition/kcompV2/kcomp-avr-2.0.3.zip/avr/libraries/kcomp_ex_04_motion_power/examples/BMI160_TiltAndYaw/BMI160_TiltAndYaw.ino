/*
  Example: GY-BMI160 6-Axis IMU (Tilt & Yaw)
  Task:    Reads acceleration, gyro speed, pitch/roll tilt, and integrated yaw.
  Pins:    I2C bus (SDA A4, SCL A5, address 0x69; alt 0x68)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_bmi160.h>

void setup() {
  Serial.begin(115200);
  Serial.println("Initializing GY-BMI160...");

  if (!initBMI160()) {
    Serial.println("Error: BMI160 not found! Check I2C wiring.");
    while (1) { delay(100); }
  }

  // Note: Without a magnetometer, Yaw (Z) drifts slowly over time.
  // Call resetBMI160Yaw() whenever you want to re-zero the Z heading.
  resetBMI160Yaw();
  Serial.println("BMI160 Ready! Tilt for Pitch/Roll, rotate flat for Yaw (Z).");
  delay(500);
}

void loop() {
  // Call getBMI160Data() frequently (10-50 ms) for accurate Yaw integration
  BMI160Data imu = getBMI160Data();

  Serial.print("ACC [m/s^2]: X="); Serial.print(imu.accelX);
  Serial.print(" Y="); Serial.print(imu.accelY);
  Serial.print(" Z="); Serial.print(imu.accelZ);

  Serial.print(" || GYRO [deg/s]: X="); Serial.print(imu.gyroX);
  Serial.print(" Y="); Serial.print(imu.gyroY);
  Serial.print(" Z="); Serial.print(imu.gyroZ);

  Serial.print(" || Angles [deg]: Pitch="); Serial.print(imu.angleX, 1);
  Serial.print(" Roll="); Serial.print(imu.angleY, 1);
  Serial.print(" Yaw="); Serial.println(imu.angleZ, 1);

  delay(50);
}
