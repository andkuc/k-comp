/*
  Program Title: Simple TOF400C (VL53L1X) Laser Distance Demo
  Author: Andreas Kucher
  License: MIT

  Reads laser time-of-flight distance in millimeters/centimeters over I2C
  (address 0x29). Use TOF400C_MODE_SHORT in bright ambient light.
*/

#include <kcomp_tof400c.h>

void setup() {
  Serial.begin(115200);
  delay(500);

  Serial.println(F("TOF400C Laser Distance Test"));
  if (!initTOF400C()) {
    Serial.println(F("Error: TOF400C not found! Check I2C wiring."));
    while (1) {}
  }

  Serial.println(F("TOF400C initialized."));
}

void loop() {
  TOF400CData reading = getTOF400CData();
  if (reading.isValid) {
    Serial.print(F("Distance: "));
    Serial.print(reading.distanceMM);
    Serial.print(F(" mm ("));
    Serial.print((float)reading.distanceMM / 10.0, 1);
    Serial.println(F(" cm)"));
  }

  delay(100);
}
