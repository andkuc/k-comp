/*
  Example: TOF400C (VL53L1X) Laser Time-of-Flight Ranging
  Task:    Measures precise target distance in millimeters and centimeters.
  Pins:    I2C bus (SDA A4, SCL A5, address 0x29)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_tof400c.h>

void setup() {
  Serial.begin(115200);
  delay(500);

  Serial.println("K-Comp Laser Distance Sensor (TOF400C)");

  if (!initTOF400C()) {
    Serial.println("Error: TOF400C not found! Check I2C wiring.");
    while (1) { delay(100); }
  }

  // Modes: TOF400C_MODE_LONG (up to 4 m indoors) vs. TOF400C_MODE_SHORT
  // (up to 1.3 m, much more reliable in bright sunlight near a window).
  setTOF400CMode(TOF400C_MODE_LONG);
  Serial.println("Laser Online!");
}

void loop() {
  TOF400CData laser = getTOF400CData();

  if (laser.isValid) {
    float distanceCm = laser.distanceMM / 10.0;
    Serial.print("Target Distance: ");
    Serial.print(laser.distanceMM);
    Serial.print(" mm  |  ");
    Serial.print(distanceCm, 1);
    Serial.println(" cm");
  }

  delay(200);
}
