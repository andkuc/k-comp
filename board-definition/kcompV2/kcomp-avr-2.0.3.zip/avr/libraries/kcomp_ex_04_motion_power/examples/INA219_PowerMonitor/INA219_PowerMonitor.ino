/*
  Example: INA219 Voltage, Current and Power Monitor
  Task:    Measures bus voltage (V), shunt drop (mV), current (mA), and power (mW).
  Pins:    I2C (SDA A4, SCL A5, 0x40); wire VIN+/VIN- IN SERIES with the load!
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_ina219.h>

void setup() {
  Serial.begin(115200);

  // IMPORTANT: Connect VIN+ and VIN- IN SERIES in the positive supply line
  // (never in parallel like a voltmeter, or you will short-circuit the supply!).
  if (!initINA219()) {
    Serial.println("Error: INA219 not found! Check I2C wiring.");
    while (1) { delay(100); }
  }

  Serial.println("INA219 Power Monitor Online!");
}

void loop() {
  float busVoltageV = getINA219BusVoltage_V();
  float shuntVoltMv = getINA219ShuntVoltage_mV();
  float currentMa   = getINA219Current_mA();
  float powerMw     = getINA219Power_mW();

  Serial.print("Bus: ");      Serial.print(busVoltageV, 2);
  Serial.print(" V | Shunt: "); Serial.print(shuntVoltMv, 2);
  Serial.print(" mV | Current: "); Serial.print(currentMa, 1);
  Serial.print(" mA | Power: ");   Serial.print(powerMw, 1);
  Serial.println(" mW");

  delay(500);
}
