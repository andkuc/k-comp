// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      ex_02_environment
// @title       K-Comp Examples: 02_Environment
// @targets     avr, esp32s3
// @bus         none (example collection)
// @timers      none
// @sram_bytes  0

#ifndef KCOMP_EX_02_ENVIRONMENT_H
#define KCOMP_EX_02_ENVIRONMENT_H

// Example-only library exposing '02_Environment' directly under Examples for K-Comp V2.

#endif
