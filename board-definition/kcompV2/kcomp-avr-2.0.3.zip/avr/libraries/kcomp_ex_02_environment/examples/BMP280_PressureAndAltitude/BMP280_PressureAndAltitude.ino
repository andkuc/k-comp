/*
  Example: BMP280 Pressure, Temperature and Altitude
  Task:    Reads temperature (C), barometric pressure (hPa), and altitude (m).
  Pins:    I2C bus (SDA A4, SCL A5, address 0x76; alt 0x77)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_bmp280.h>

void setup() {
  Serial.begin(115200);
  Serial.println("BMP280 Sensor Test");

  if (!initBMP280()) {
    Serial.println("Error: BMP280 not found! Check I2C wiring.");
    while (1) { delay(100); }
  }

  Serial.println("BMP280 Initialized.");
}

void loop() {
  float temperature = getBMP280Temperature();
  float pressurePa = getBMP280Pressure();

  // 1013.25 hPa is standard sea-level pressure; replace with local QNH for exact altitude
  float altitude = getBMP280Altitude(1013.25);

  Serial.print("Temp: ");
  Serial.print(temperature);
  Serial.print(" C	");

  Serial.print("Press: ");
  Serial.print(pressurePa / 100.0);
  Serial.print(" hPa	");

  Serial.print("Alt: ");
  Serial.print(altitude);
  Serial.println(" m");

  delay(1000);
}
