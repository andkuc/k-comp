/*
  Program Title: Simple Capacitive Soil Moisture Demo
  Author: Andreas Kucher
  License: MIT

  Reads raw ADC counts and calibrated soil moisture percentage (0..100%)
  from an analog capacitive soil moisture sensor at 115200 baud.
*/

#include <kcomp_soil_sensor.h>
#define SOIL_PIN A3

void setup() {
  Serial.begin(115200);
  initSoilSensor(SOIL_PIN);
  setSoilSensorCalibration(560, 220);
  Serial.println(F("Soil moisture sensor initialized."));
}

void loop() {
  uint16_t raw = getSoilSensorRaw();
  uint8_t moisture = getSoilSensorMoisture();

  Serial.print(F("Raw: "));
  Serial.print(raw);
  Serial.print(F(" | Moisture: "));
  Serial.print(moisture);
  Serial.println(F("%"));

  delay(1000);
}
