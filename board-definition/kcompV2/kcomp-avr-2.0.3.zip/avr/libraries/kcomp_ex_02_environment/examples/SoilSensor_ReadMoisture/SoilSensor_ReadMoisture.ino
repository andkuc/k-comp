/*
  Example: Capacitive Soil Moisture Sensor
  Task:    Reads raw ADC counts and calibrated soil moisture (0-100%).
  Pins:    Analog input on A3
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_soil_sensor.h>

#define SOIL_PIN A3

void setup() {
  Serial.begin(115200);
  initSoilSensor(SOIL_PIN);

  // Calibration: Measure getSoilSensorRaw() once in dry air (dryRaw)
  // and once submerged in a glass of water (wetRaw), then enter both values here.
  setSoilSensorCalibration(560, 220);

  Serial.println("K-Comp Soil Monitor Online");
}

void loop() {
  uint16_t rawVal = getSoilSensorRaw();
  uint8_t moisture = getSoilSensorMoisture();

  Serial.print("Raw Analog: ");
  Serial.print(rawVal);
  Serial.print("  |  Moisture: ");
  Serial.print(moisture);
  Serial.println("%");

  delay(1000);
}
