/*
  Example: DS18B20 1-Wire Temperature Sensor
  Task:    Starts non-blocking 12-bit conversions and prints temperature (C).
  Pins:    Data pin on D12 (IMPORTANT: requires external 4.7k pull-up to 5V!)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_ds18b20.h>

#define DS18B20_PIN 12

void setup() {
  Serial.begin(115200);
  Serial.println("K-Comp Thermometer Online");

  if (!initDS18B20(DS18B20_PIN)) {
    Serial.println("Error: DS18B20 not found! Did you connect the 4.7k pull-up resistor?");
    while (1) { delay(100); }
  }

  // Start the first non-blocking conversion (~750 ms) before entering loop()
  requestDS18B20();
}

void loop() {
  // Non-blocking poll: returns immediately until the 750 ms conversion is done
  DS18B20Data tempSensor = getDS18B20Data();

  if (tempSensor.isValid) {
    Serial.print("Temperature: ");
    Serial.print(tempSensor.temperatureC);
    Serial.println(" C");

    // Immediately trigger the next measurement
    requestDS18B20();
  }
}
