/*
  Example: SPS30 Particulate Matter Monitor (PM1.0 / PM2.5 / PM10)
  Task:    Reads fine dust mass concentration (ug/m3) and air quality score.
  Pins:    I2C bus (SDA A4, SCL A5, address 0x69, 5V power)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_sps30.h>

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("K-Comp SPS30 Particulate Monitor");

  if (initSPS30()) {
    Serial.println("Sensor warming up...");
  } else {
    Serial.println("Error: SPS30 not found! Check I2C wiring.");
    while (1) { delay(100); }
  }
}

void loop() {
  // The SPS30 measures once per second (1 Hz), so we check air.isValid first.
  // PM1.0 / PM2.5 / PM10 = particles smaller than 1.0 / 2.5 / 10 micrometers.
  SPS30Data air = getSPS30Data();

  if (air.isValid) {
    Serial.print("
PM1.0: ");
    Serial.print(air.pm1_0);
    Serial.print(" | PM2.5: ");
    Serial.print(air.pm2_5);
    Serial.print(" | PM10: ");
    Serial.print(air.pm10_0);
    Serial.println(" ug/m3");

    Serial.print("Clean Score: ");
    Serial.print(getSPS30AirQualityScore());
    Serial.println(" / 100");

    uint8_t source = getSPS30PollutionSource();
    if (source == SPS30_SOURCE_COMBUSTION) {
      Serial.println("Warning: Smoke or exhaust detected!");
    }
  }

  delay(500);
}
