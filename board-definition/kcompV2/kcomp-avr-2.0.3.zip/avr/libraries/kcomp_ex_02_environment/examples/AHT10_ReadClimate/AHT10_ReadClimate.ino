/*
  Example: AHT10 Temperature and Humidity
  Task:    Reads temperature (C) and relative humidity (%RH) over I2C.
  Pins:    I2C bus (SDA A4, SCL A5, address 0x38)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_aht10.h>

void setup() {
  Serial.begin(115200);
  Serial.println("AHT10 Sensor Test");

  if (!initAHT10()) {
    Serial.println("Error: AHT10 not found! Check I2C wiring.");
    while (1) { delay(100); }
  }

  Serial.println("AHT10 Initialized.");
}

void loop() {
  float temperature = getAHT10Temperature();
  float humidity = getAHT10Humidity();

  Serial.print("Temperature: ");
  Serial.print(temperature);
  Serial.print(" C	");

  Serial.print("Humidity: ");
  Serial.print(humidity);
  Serial.println(" %");

  delay(1000);
}
