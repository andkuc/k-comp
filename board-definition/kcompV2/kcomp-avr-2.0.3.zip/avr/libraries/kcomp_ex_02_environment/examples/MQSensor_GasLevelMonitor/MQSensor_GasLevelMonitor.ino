/*
  Example: MQ Gas Sensor Monitor (MQ-2 / MQ-3 / MQ-7 / MQ-135)
  Task:    Calibrates clean-air baseline and prints gas score (0-100%) + status.
  Pins:    Analog input on A3 (Note: MQ heater needs warm-up time for stable values!)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_mq_sensors.h>

#define MQ_PIN A3

// Select your connected MQ sensor:
// MQ_SENSOR_MQ2 (Smoke), MQ_SENSOR_MQ3 (Alcohol), MQ_SENSOR_MQ7 (CO), MQ_SENSOR_MQ135 (VOCs)
uint8_t activeSensor = MQ_SENSOR_MQ3;

void setup() {
  Serial.begin(115200);
  initMQSensor(MQ_PIN, activeSensor);

  Serial.print("Initializing MQ Sensor type: ");
  Serial.println(activeSensor);

  // Allow the internal heating element to stabilize in fresh air before calibrating
  Serial.println("Warming up heater... (Keep in fresh air!)");
  delay(3000);

  Serial.println("Calibrating baseline...");
  calibrateMQSensor(MQ_PIN);
  Serial.println("Calibration complete. Sensor is live!
");
}

void loop() {
  uint8_t intensity = getMQSensorScore(MQ_PIN);
  uint8_t status = getMQSensorStatus(MQ_PIN);

  if (activeSensor == MQ_SENSOR_MQ2)        Serial.print("[MQ-2 Smoke]   Intensity: ");
  else if (activeSensor == MQ_SENSOR_MQ3)   Serial.print("[MQ-3 Alcohol] Intensity: ");
  else if (activeSensor == MQ_SENSOR_MQ7)   Serial.print("[MQ-7 CO]      Intensity: ");
  else if (activeSensor == MQ_SENSOR_MQ135) Serial.print("[MQ-135 VOCs]  Intensity: ");

  Serial.print(intensity);
  Serial.print("%  |  Status: ");

  if (status == MQ_STATUS_CLEAN) {
    Serial.println("CLEAN");
  } else if (status == MQ_STATUS_MODERATE) {
    Serial.println("MODERATE");
  } else if (status == MQ_STATUS_HIGH) {
    Serial.println("HIGH WARNING!");
  }

  delay(1000);
}
