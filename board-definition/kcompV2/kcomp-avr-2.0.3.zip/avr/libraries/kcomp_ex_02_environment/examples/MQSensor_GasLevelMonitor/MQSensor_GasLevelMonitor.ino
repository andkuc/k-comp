/*
  Program Title: Simple MQ Gas / Air Quality Sensor Demo
  Author: Andreas Kucher
  License: MIT

  Initializes an MQ-series gas sensor on an analog pin, calibrates the
  clean-air baseline, and prints a 0..100% score and status level at 115200 baud.
*/

#include <kcomp_mq_sensors.h>
#define MQ_PIN A3
#define MQ_TYPE MQ_SENSOR_MQ3

void setup() {
  Serial.begin(115200);
  initMQSensor(MQ_PIN, MQ_TYPE);

  Serial.println(F("Warming up MQ heater in clean air..."));
  delay(3000);

  calibrateMQSensor(MQ_PIN);
  Serial.println(F("MQ baseline calibrated."));
}

void loop() {
  uint8_t score = getMQSensorScore(MQ_PIN);
  uint8_t status = getMQSensorStatus(MQ_PIN);

  Serial.print(F("Score: "));
  Serial.print(score);
  Serial.print(F("% | Status: "));

  if (status == MQ_STATUS_CLEAN) {
    Serial.println(F("CLEAN"));
  } else if (status == MQ_STATUS_MODERATE) {
    Serial.println(F("MODERATE"));
  } else {
    Serial.println(F("HIGH"));
  }

  delay(1000);
}
