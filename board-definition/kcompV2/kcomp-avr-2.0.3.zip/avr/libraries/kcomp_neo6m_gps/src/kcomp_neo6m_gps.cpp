// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_neo6m_gps.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>

#if defined(__AVR__)
  #include <SoftwareSerial.h>
  static SoftwareSerial* gpsSwSerial = NULL;
#endif

static Stream* gpsPort = NULL;

static constexpr uint8_t MAX_NMEA_LEN = 100U;
static constexpr uint8_t MAX_FIELDS   = 20U;
static constexpr double  DEG_TO_RAD_D = 0.017453292519943295;
static constexpr double  RAD_TO_DEG_D = 57.29577951308232;

static GPSData gpsData = {
    0.0, 0.0, 0.0f, 0.0f, 0.0f,
    0U, 0U, 0U, 0U, 0U, 0U,
    0, false, 0U, 0.0f, false, false
};
static char nmeaBuf[MAX_NMEA_LEN];
static uint8_t nmeaIdx = 0U;

static int8_t userOffsetHours = 0;
static bool   userDst = false;
static bool   autoTimezone = false;

static uint8_t daysInMonth(uint16_t year, uint8_t month) {
    if (month == 2U) {
        if ((year % 4U == 0U && year % 100U != 0U) || (year % 400U == 0U)) {
            return 29U;
        }
        return 28U;
    }
    if (month == 4U || month == 6U || month == 9U || month == 11U) {
        return 30U;
    }
    return 31U;
}

static void applyTimezone(GPSData* d) {
    int16_t totalOffset = userOffsetHours;
    if (autoTimezone && d->longitude != 0.0) {
        totalOffset = (int16_t)round(d->longitude / 15.0);
    }
    if (userDst) {
        totalOffset++;
    }

    d->timezoneOffset = (int8_t)totalOffset;
    d->dstActive = userDst;
    if (totalOffset == 0) {
        return;
    }

    int16_t h = (int16_t)d->hour + totalOffset;
    if (h >= 24) {
        h -= 24;
        d->day++;
        if (d->day > daysInMonth(d->year, d->month)) {
            d->day = 1U;
            d->month++;
            if (d->month > 12U) {
                d->month = 1U;
                d->year++;
            }
        }
    } else if (h < 0) {
        h += 24;
        if (d->day > 1U) {
            d->day--;
        } else {
            if (d->month > 1U) {
                d->month--;
            } else {
                d->month = 12U;
                if (d->year > 0U) {
                    d->year--;
                }
            }
            d->day = daysInMonth(d->year, d->month);
        }
    }
    d->hour = (uint8_t)h;
}

static double convertNMEACoord(const char* raw, const char* dir) {
    if (raw == NULL || raw[0] == '\0') {
        return 0.0;
    }
    const double val = atof(raw);
    const int dd = (int)(val / 100.0);
    const double mm = val - ((double)dd * 100.0);
    double res = (double)dd + (mm / 60.0);
    if (dir != NULL && (dir[0] == 'S' || dir[0] == 'W')) {
        res = -res;
    }
    return res;
}

static bool parseNMEASentence(char* sentence) {
    char* fields[MAX_FIELDS];
    uint8_t fieldCount = 0U;
    char* cursor = sentence;
    fields[fieldCount++] = cursor;

    while (*cursor != '\0' && fieldCount < MAX_FIELDS) {
        if (*cursor == ',' || *cursor == '*') {
            *cursor = '\0';
            fields[fieldCount++] = cursor + 1;
        }
        cursor++;
    }

    if (strncmp(fields[0], "$GPRMC", 6) == 0) {
        const char* status = (fieldCount > 2U) ? fields[2] : NULL;
        if (status != NULL && status[0] == 'A') {
            gpsData.valid = true;
            gpsData.updated = true;

            if (fieldCount > 1U && strlen(fields[1]) >= 6U) {
                char tmp[3] = {0, 0, 0};
                tmp[0] = fields[1][0]; tmp[1] = fields[1][1]; gpsData.hour = (uint8_t)atoi(tmp);
                tmp[0] = fields[1][2]; tmp[1] = fields[1][3]; gpsData.minute = (uint8_t)atoi(tmp);
                tmp[0] = fields[1][4]; tmp[1] = fields[1][5]; gpsData.second = (uint8_t)atoi(tmp);
            }
            if (fieldCount > 4U) gpsData.latitude = convertNMEACoord(fields[3], fields[4]);
            if (fieldCount > 6U) gpsData.longitude = convertNMEACoord(fields[5], fields[6]);
            if (fieldCount > 7U) gpsData.speedKmh = (float)(atof(fields[7]) * 1.852);
            if (fieldCount > 8U) gpsData.courseDeg = (float)atof(fields[8]);
            if (fieldCount > 9U && strlen(fields[9]) >= 6U) {
                char tmp[3] = {0, 0, 0};
                tmp[0] = fields[9][0]; tmp[1] = fields[9][1]; gpsData.day = (uint8_t)atoi(tmp);
                tmp[0] = fields[9][2]; tmp[1] = fields[9][3]; gpsData.month = (uint8_t)atoi(tmp);
                tmp[0] = fields[9][4]; tmp[1] = fields[9][5]; gpsData.year = (uint16_t)(2000 + atoi(tmp));
            }

            applyTimezone(&gpsData);
            return true;
        }
        gpsData.valid = false;
    } else if (strncmp(fields[0], "$GPGGA", 6) == 0) {
        if (fieldCount > 7U) gpsData.satellites = (uint8_t)atoi(fields[7]);
        if (fieldCount > 8U) gpsData.hdop = (float)atof(fields[8]);
        if (fieldCount > 9U) gpsData.altitude = (float)atof(fields[9]);
    }

    return false;
}

bool initGPS(uint8_t rxPin, uint8_t txPin, uint32_t baudRate) {
    nmeaIdx = 0U;
    gpsData.valid = false;
    gpsData.updated = false;
    userOffsetHours = 0;
    userDst = false;
    autoTimezone = false;

#if defined(__AVR__)
    if (gpsSwSerial != NULL) {
        delete gpsSwSerial;
        gpsSwSerial = NULL;
    }
    gpsSwSerial = new SoftwareSerial(rxPin, txPin);
    if (gpsSwSerial == NULL) {
        gpsPort = NULL;
        return false;
    }
    gpsSwSerial->begin((long)baudRate);
    gpsPort = gpsSwSerial;
#elif defined(ESP32)
    Serial1.begin(baudRate, SERIAL_8N1, rxPin, txPin);
    gpsPort = &Serial1;
#else
    (void)rxPin;
    (void)txPin;
    (void)baudRate;
    gpsPort = NULL;
    return false;
#endif

    // Verify that the GPS module is actually transmitting NMEA sentences ($G...)
    bool sawDollar = false;
    const uint32_t startMs = millis();
    while ((millis() - startMs) < 1500UL) {
        while (gpsPort->available() > 0) {
            const char c = (char)gpsPort->read();
            if (c == '$') {
                sawDollar = true;
            } else if (sawDollar && c == 'G') {
                return true;
            } else {
                sawDollar = false;
            }
        }
    }
    return false;
}

bool updateGPS() {
    if (gpsPort == NULL) {
        return false;
    }

    bool gotFix = false;
    gpsData.updated = false;

    while (gpsPort->available() > 0) {
        const char c = (char)gpsPort->read();
        if (c == '$') {
            nmeaIdx = 0U;
        }
        if (nmeaIdx < (MAX_NMEA_LEN - 1U)) {
            nmeaBuf[nmeaIdx++] = c;
        }
        if (c == '\n') {
            nmeaBuf[nmeaIdx] = '\0';
            if (parseNMEASentence(nmeaBuf)) {
                gotFix = true;
            }
            nmeaIdx = 0U;
        }
    }
    return gotFix;
}

GPSData getGPSData() {
    return gpsData;
}

void setGPSTimezoneOffset(int8_t hours) {
    userOffsetHours = hours;
    autoTimezone = false;
}

void setGPSDST(bool enabled) {
    userDst = enabled;
}

void setGPSAutoTimezone(bool enable) {
    autoTimezone = enable;
}

double getGPSDistanceMeters(double lat1, double lon1, double lat2, double lon2) {
    const double dLat = (lat2 - lat1) * DEG_TO_RAD_D;
    const double dLon = (lon2 - lon1) * DEG_TO_RAD_D;
    const double rLat1 = lat1 * DEG_TO_RAD_D;
    const double rLat2 = lat2 * DEG_TO_RAD_D;

    const double sinLat = sin(dLat * 0.5);
    const double sinLon = sin(dLon * 0.5);
    const double a = (sinLat * sinLat) + (cos(rLat1) * cos(rLat2) * sinLon * sinLon);
    const double c = 2.0 * atan2(sqrt(a), sqrt(1.0 - a));
    return 6371000.0 * c;
}

double getGPSCourseDeg(double lat1, double lon1, double lat2, double lon2) {
    const double dLon = (lon2 - lon1) * DEG_TO_RAD_D;
    const double rLat1 = lat1 * DEG_TO_RAD_D;
    const double rLat2 = lat2 * DEG_TO_RAD_D;

    const double y = sin(dLon) * cos(rLat2);
    const double x = (cos(rLat1) * sin(rLat2)) - (sin(rLat1) * cos(rLat2) * cos(dLon));
    const double deg = atan2(y, x) * RAD_TO_DEG_D;
    return (deg < 0.0) ? (deg + 360.0) : deg;
}

GPSCardinal getGPSCardinal(double courseDeg) {
    if (courseDeg < 0.0) {
        return CARDINAL_UNKNOWN;
    }
    const int idx = (int)((courseDeg + 22.5) / 45.0) % 8;
    return (GPSCardinal)idx;
}
