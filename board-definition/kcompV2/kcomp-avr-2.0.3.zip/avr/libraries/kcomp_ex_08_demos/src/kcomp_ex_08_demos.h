// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      ex_08_demos
// @title       K-Comp Examples: 08_Demos
// @targets     avr, esp32s3
// @bus         none (example collection)
// @timers      none
// @sram_bytes  0

#ifndef KCOMP_EX_08_DEMOS_H
#define KCOMP_EX_08_DEMOS_H

// Example-only library exposing '08_Demos' directly under Examples for K-Comp V2.

#endif
