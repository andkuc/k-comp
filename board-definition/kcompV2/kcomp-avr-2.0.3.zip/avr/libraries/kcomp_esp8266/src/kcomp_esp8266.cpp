// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher

#include "kcomp_esp8266.h"
#include <stdio.h>
#include <string.h>

#if defined(__AVR__)
  #include <SoftwareSerial.h>
  static SoftwareSerial* espSwSerial = NULL;
#endif

static Stream* espPort = NULL;
static bool espDebug = true;

// Fixed-size response ring/tail buffer (avoids Arduino String heap fragmentation)
static constexpr uint8_t RESP_BUF_SIZE = 128U;

static void closePort() {
#if defined(__AVR__)
    if (espSwSerial != NULL) {
        delete espSwSerial;
        espSwSerial = NULL;
    }
#endif
    espPort = NULL;
}

static bool openPort(uint8_t rxPin, uint8_t txPin, uint32_t baudRate) {
#if defined(__AVR__)
    closePort();
    espSwSerial = new SoftwareSerial(rxPin, txPin);
    if (espSwSerial == NULL) {
        return false;
    }
    espSwSerial->begin((long)baudRate);
    espPort = espSwSerial;
    return true;
#elif defined(ESP32)
    Serial1.begin(baudRate, SERIAL_8N1, rxPin, txPin);
    espPort = &Serial1;
    return true;
#else
    (void)rxPin;
    (void)txPin;
    (void)baudRate;
    espPort = NULL;
    return false;
#endif
}

// Wait until 'expected' appears in the incoming UART stream or timeoutMs elapses.
static bool waitForToken(const char* expected, uint16_t timeoutMs, char* outTail = NULL, uint8_t outSize = 0U) {
    if (espPort == NULL || expected == NULL) {
        return false;
    }

    char respBuf[RESP_BUF_SIZE];
    uint8_t respLen = 0U;
    respBuf[0] = '\0';

    const uint32_t startMs = millis();
    while ((millis() - startMs) < timeoutMs) {
        while (espPort->available() > 0) {
            const char c = (char)espPort->read();
            if (respLen < (RESP_BUF_SIZE - 1U)) {
                respBuf[respLen++] = c;
                respBuf[respLen] = '\0';
            } else {
                // Shift left by 1 byte to keep the most recent tail for substring matching
                memmove(respBuf, respBuf + 1, RESP_BUF_SIZE - 2U);
                respBuf[RESP_BUF_SIZE - 2U] = c;
                respBuf[RESP_BUF_SIZE - 1U] = '\0';
            }

            if (strstr(respBuf, expected) != NULL) {
                if (outTail != NULL && outSize > 0U) {
                    strncpy(outTail, respBuf, outSize - 1U);
                    outTail[outSize - 1U] = '\0';
                }
                return true;
            }
        }
    }

    if (outTail != NULL && outSize > 0U) {
        strncpy(outTail, respBuf, outSize - 1U);
        outTail[outSize - 1U] = '\0';
    }
    return false;
}

static bool sendAtCommand(const char* cmd, const char* expected, uint16_t timeoutMs) {
    if (espPort == NULL) {
        return false;
    }

    while (espPort->available() > 0) {
        (void)espPort->read();
    }

    if (cmd != NULL && cmd[0] != '\0') {
        espPort->println(cmd);
        if (espDebug) {
            Serial.print(F("[ESP Send] "));
            Serial.println(cmd);
        }
    }

    char tail[64];
    const bool ok = waitForToken(expected, timeoutMs, tail, sizeof(tail));
    if (espDebug) {
        if (ok) {
            Serial.println(F("[ESP OK]"));
        } else {
            Serial.print(F("[ESP Timeout] Tail: "));
            Serial.println(tail);
        }
    }
    return ok;
}

void setESP8266Debug(bool enable) {
    espDebug = enable;
}

bool setupESP8266BaudRate(uint8_t rxPin, uint8_t txPin) {
    // 1. Check if the module already responds at 9600 baud
    if (openPort(rxPin, txPin, 9600UL)) {
        delay(100);
        if (sendAtCommand("AT", "OK", 500U)) {
            return true;
        }
    }

    // 2. Negotiate down from factory default 115200 baud
    if (openPort(rxPin, txPin, 115200UL)) {
        delay(100);
        for (uint8_t i = 0U; i < 5U; i++) {
            espPort->println(F("AT+UART_DEF=9600,8,1,0,0"));
            delay(200);
        }
    }

    // 3. Re-open at 9600 baud and verify
    if (!openPort(rxPin, txPin, 9600UL)) {
        return false;
    }
    delay(100);
    const bool ok = sendAtCommand("AT", "OK", 800U);
    if (!ok) {
        closePort();
    }
    return ok;
}

bool initESP8266(uint8_t rxPin, uint8_t txPin, const char* ssid, const char* pass, uint32_t baudRate) {
    if (ssid == NULL || pass == NULL) {
        return false;
    }
    if (!openPort(rxPin, txPin, baudRate)) {
        return false;
    }

    if (!sendAtCommand("AT", "OK", 1000U)) {
        return false;
    }
    (void)sendAtCommand("AT+CWMODE=1", "OK", 2000U);

    char cmd[128];
    snprintf(cmd, sizeof(cmd), "AT+CWJAP=\"%s\",\"%s\"", ssid, pass);
    return sendAtCommand(cmd, "OK", 15000U);
}

bool syncESP8266Time(int8_t timezoneHours) {
    if (espPort == NULL) {
        return false;
    }

    char cmd[32];
    snprintf(cmd, sizeof(cmd), "AT+CIPSNTPCFG=1,%d", (int)timezoneHours);
    (void)sendAtCommand(cmd, "OK", 5000U);

    for (uint8_t attempt = 0U; attempt < 15U; attempt++) {
        while (espPort->available() > 0) {
            (void)espPort->read();
        }
        espPort->println(F("AT+CIPSNTPTIME?"));
        if (waitForToken("202", 1000U)) {
            return true;
        }
    }
    return false;
}

bool setESP8266SSLBufferSize(uint16_t size) {
    if (espPort == NULL) {
        return false;
    }
    char cmd[32];
    snprintf(cmd, sizeof(cmd), "AT+CIPSSLSIZE=%u", (unsigned int)size);
    return sendAtCommand(cmd, "OK", 2000U);
}

bool connectESP8266Server(const char* domain, uint16_t port) {
    if (espPort == NULL || domain == NULL) {
        return false;
    }

    (void)sendAtCommand("AT+CIPCLOSE", "ERROR", 500U);

    const char* proto = (port == 443U) ? "SSL" : "TCP";
    char cmd[128];
    snprintf(cmd, sizeof(cmd), "AT+CIPSTART=\"%s\",\"%s\",%u", proto, domain, (unsigned int)port);
    return sendAtCommand(cmd, "OK", 15000U);
}

bool printESP8266Line(const char* data) {
    if (espPort == NULL || data == NULL) {
        return false;
    }

    const size_t sendLen = strlen(data) + 2U;
    char cmd[24];
    snprintf(cmd, sizeof(cmd), "AT+CIPSEND=%u", (unsigned int)sendLen);

    while (espPort->available() > 0) {
        (void)espPort->read();
    }
    espPort->println(cmd);

    if (!waitForToken(">", 2000U)) {
        if (espDebug) {
            Serial.println(F("[ESP Error] Send prompt timeout"));
        }
        return false;
    }

    espPort->print(data);
    espPort->print("\r\n");
    return waitForToken("SEND OK", 2000U);
}

int getESP8266Available() {
    return (espPort != NULL) ? espPort->available() : 0;
}

int readESP8266() {
    if (espPort != NULL && espPort->available() > 0) {
        return espPort->read();
    }
    return -1;
}

void printESP8266WifiStatus() {
    if (espPort == NULL) {
        return;
    }
    Serial.println(F("--- WiFi Status ---"));
    espPort->println(F("AT+CIFSR"));
    const uint32_t startMs = millis();
    while ((millis() - startMs) < 2000UL) {
        while (espPort->available() > 0) {
            Serial.write((uint8_t)espPort->read());
        }
    }
    Serial.println(F("\n-------------------"));
}

void stopESP8266() {
    if (espPort != NULL) {
        espPort->println(F("AT+CIPCLOSE"));
    }
}
