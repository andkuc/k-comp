/*
  Example: AS7331 UV-A / UV-B / UV-C Sensor
  Task:    Measures UV irradiance (uW/cm2) and raw counts over I2C.
  Pins:    I2C bus (SDA A4, SCL A5, address 0x74)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_as7331.h>

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println("K-Comp AS7331 UV Sensor Test");
  Serial.println("----------------------------");

  if (initAS7331()) {
    Serial.println("AS7331 found and initialized!");
  } else {
    Serial.println("Error: AS7331 not found! Check I2C wiring.");
    while (1) { delay(100); }
  }

  // Higher gain (e.g. 256x) for dim indoor light, lower gain (e.g. 16x) for bright sunlight
  Serial.println("Setting Gain to 256x for indoor sensitivity...");
  setAS7331Gain(AS7331_GAIN_256X);
  Serial.println("Starting measurements...
");
}

void loop() {
  // Note: Standard window glass blocks UV-C completely, so UVC is normally 0 indoors.
  float uva = getAS7331_UVA();
  float uvb = getAS7331_UVB();
  float uvc = getAS7331_UVC();

  Serial.print("UVA: "); Serial.print(uva); Serial.print(" uW/cm2  |  ");
  Serial.print("UVB: "); Serial.print(uvb); Serial.print(" uW/cm2  |  ");
  Serial.print("UVC: "); Serial.print(uvc); Serial.print(" uW/cm2  |  ");
  Serial.print("Raw UVA: "); Serial.println(getAS7331RawUVA());

  delay(1000);
}
