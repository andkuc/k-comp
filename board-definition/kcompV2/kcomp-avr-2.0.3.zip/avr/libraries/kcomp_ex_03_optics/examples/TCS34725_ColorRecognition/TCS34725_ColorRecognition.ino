/*
  Example: TCS34725 RGB Color Recognition
  Task:    Reads RGBC/HSV values and classifies colors non-blockingly via millis().
  Pins:    I2C bus (SDA A4, SCL A5, address 0x29)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_tcs34725.h>

unsigned long lastScan = 0;

void setup() {
  Serial.begin(115200);

  if (!initColorSensor()) {
    Serial.println("Error: TCS34725 not found! Check I2C wiring.");
    while (1) { delay(100); }
  }

  setColorIntegrationTime(COLOR_TIME_101MS);
  calibrateColorEngine(250, 10000);

  // Optional: For custom lighting, call calibrateBlackLevel() on a black surface
  // and calibrateWhiteBalance() on a white sheet of paper.
  Serial.println("--- TCS34725 HSV Color Engine Ready ---");
}

void loop() {
  // Keep the internal sensor and HSV engine updated continuously
  updateColorSensor();

  // Print telemetry once per second without blocking
  if (millis() - lastScan >= 1000) {
    lastScan = millis();

    Serial.print("RGB: ");
    Serial.print(getColorRed());   Serial.print(", ");
    Serial.print(getColorGreen()); Serial.print(", ");
    Serial.print(getColorBlue());
    Serial.print(" | Clear: "); Serial.print(getColorClear());

    Serial.print(" | HSV: ");
    Serial.print(getColorHue());        Serial.print(" deg, ");
    Serial.print(getColorSaturation()); Serial.print("%, ");
    Serial.print(getColorBrightness()); Serial.print("%");

    Serial.print(" -> Est.: ");
    Serial.println(getColorName(estimateColor()));
  }
}
