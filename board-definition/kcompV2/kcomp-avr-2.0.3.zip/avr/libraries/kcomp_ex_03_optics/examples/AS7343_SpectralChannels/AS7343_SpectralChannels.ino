/*
  Example: AS7343 14-Channel Spectral Sensor
  Task:    Reads 11 visible + Clear + NIR spectral channels with onboard LED.
  Pins:    I2C bus (SDA A4, SCL A5, address 0x39)
  Monitor: Serial Monitor at 115200 baud (compatible with Serial Plotter format)
*/

#include <kcomp_as7343.h>

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println("=== K-Comp AS7343 Spectral Sensor ===");

  if (initAS7343()) {
    Serial.println("Sensor found and ready!");
  } else {
    Serial.println("Error: AS7343 not found! Check I2C wiring.");
    while (1) { delay(100); }
  }

  setAS7343Gain(6);
  setAS7343LED(true, 12);
  Serial.println("LED ON. Hold a colored object 2-3 cm above the sensor.");
}

void loop() {
  // Tip: You can also print channels as "F1:val,F2:val,..." for the Arduino Serial Plotter.
  if (updateAS7343()) {
    AS7343Data lightData = getAS7343Data();

    Serial.print("Clear: "); Serial.println(lightData.clear);

    Serial.print("405nm_F1: "); Serial.print(lightData.f1_405nm); Serial.print("	");
    Serial.print("425nm_F2: "); Serial.print(lightData.f2_425nm); Serial.print("	");
    Serial.print("450nm_FZ: "); Serial.println(lightData.fz_450nm);

    Serial.print("475nm_F3: "); Serial.print(lightData.f3_475nm); Serial.print("	");
    Serial.print("515nm_F4: "); Serial.print(lightData.f4_515nm); Serial.print("	");
    Serial.print("550nm_F5: "); Serial.println(lightData.f5_550nm);

    Serial.print("555nm_FY: "); Serial.print(lightData.fy_555nm); Serial.print("	");
    Serial.print("600nm_FXL:"); Serial.print(lightData.fxl_600nm); Serial.print("	");
    Serial.print("640nm_F6: "); Serial.println(lightData.f6_640nm);

    Serial.print("690nm_F7: "); Serial.print(lightData.f7_690nm); Serial.print("	");
    Serial.print("745nm_F8: "); Serial.print(lightData.f8_745nm); Serial.print("	");
    Serial.print("855nm_NIR:"); Serial.println(lightData.nir);

    Serial.println("-----------------------------------------");
  } else {
    Serial.println("Error: Could not read AS7343. Check I2C wiring.");
  }

  delay(1000);
}
