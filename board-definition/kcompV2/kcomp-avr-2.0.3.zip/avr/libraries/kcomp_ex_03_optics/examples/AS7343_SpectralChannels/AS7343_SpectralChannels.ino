/*
  Program Title: Simple AS7343 14-Channel Spectral Sensor Demo
  Author: Andreas Kucher
  License: MIT

  Reads multi-wavelength spectral channels, broadband clear light, and NIR
  from an AS7343 sensor over I2C (address 0x39).
*/

#include <kcomp_as7343.h>

void setup() {
  Serial.begin(115200);
  delay(500);

  Serial.println(F("K-Comp AS7343 Spectral Sensor Test"));
  if (!initAS7343()) {
    Serial.println(F("Error: AS7343 not found! Check I2C wiring."));
    while (1) {}
  }

  setAS7343Gain(6);
  setAS7343LED(true, 12);
  Serial.println(F("AS7343 initialized."));
}

void loop() {
  if (updateAS7343()) {
    AS7343Data d = getAS7343Data();
    Serial.print(F("Clear: "));
    Serial.print(d.clear);
    Serial.print(F(" | 450nm: "));
    Serial.print(d.fz_450nm);
    Serial.print(F(" | 555nm: "));
    Serial.print(d.fy_555nm);
    Serial.print(F(" | 640nm: "));
    Serial.print(d.f6_640nm);
    Serial.print(F(" | NIR: "));
    Serial.println(d.nir);
  } else {
    Serial.println(F("Warning: AS7343 read timeout."));
  }

  delay(1000);
}
