/*
  Example: PAJ7620U2 9-Gesture Optical Sensor
  Task:    Detects swipe, depth, rotation, and wave gestures over I2C.
  Pins:    I2C bus (SDA A4, SCL A5, address 0x73; hand distance 5-15 cm)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_paj7620.h>

void setup() {
  Serial.begin(115200);

  if (!initPAJ7620()) {
    Serial.println("Error: PAJ7620U2 not found! Check I2C wiring.");
    while (1) { delay(100); }
  }

  // 250 ms cooldown suppresses false opposite gestures when your hand leaves the sensor
  setPAJ7620CooldownMs(250);
  Serial.println("PAJ7620U2 ready. Swipe your hand 5-15 cm above the sensor...");
}

void loop() {
  if (updatePAJ7620()) {
    uint8_t gesture = getPAJ7620Gesture();
    switch (gesture) {
      case PAJ7620_GESTURE_UP:                Serial.println("Gesture: UP"); break;
      case PAJ7620_GESTURE_DOWN:              Serial.println("Gesture: DOWN"); break;
      case PAJ7620_GESTURE_LEFT:              Serial.println("Gesture: LEFT"); break;
      case PAJ7620_GESTURE_RIGHT:             Serial.println("Gesture: RIGHT"); break;
      case PAJ7620_GESTURE_FORWARD:           Serial.println("Gesture: FORWARD"); break;
      case PAJ7620_GESTURE_BACKWARD:          Serial.println("Gesture: BACKWARD"); break;
      case PAJ7620_GESTURE_CLOCKWISE:         Serial.println("Gesture: CLOCKWISE"); break;
      case PAJ7620_GESTURE_COUNTER_CLOCKWISE: Serial.println("Gesture: COUNTER-CLOCKWISE"); break;
      case PAJ7620_GESTURE_WAVE:              Serial.println("Gesture: WAVE"); break;
      default: break;
    }
  }

  delay(20);
}
