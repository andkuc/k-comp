/*
  Program Title: Simple PAJ7620U2 9-Gesture Sensor Demo
  Author: Andreas Kucher
  License: MIT

  Detects directional, depth, rotational, and wave gestures over I2C
  (default address 0x73) at 115200 baud.
*/

#include <kcomp_paj7620.h>

void setup() {
  Serial.begin(115200);

  if (!initPAJ7620()) {
    Serial.println(F("Error: PAJ7620U2 not found! Check I2C wiring."));
    while (1) {}
  }

  // Set a 250 ms cooldown to reduce accidental opposite gestures on hand exit
  setPAJ7620CooldownMs(250);
  Serial.println(F("PAJ7620U2 ready. Swipe your hand over the sensor..."));
}

void loop() {
  if (updatePAJ7620()) {
    uint8_t gesture = getPAJ7620Gesture();
    switch (gesture) {
      case PAJ7620_GESTURE_UP:
        Serial.println(F("Gesture: UP"));
        break;
      case PAJ7620_GESTURE_DOWN:
        Serial.println(F("Gesture: DOWN"));
        break;
      case PAJ7620_GESTURE_LEFT:
        Serial.println(F("Gesture: LEFT"));
        break;
      case PAJ7620_GESTURE_RIGHT:
        Serial.println(F("Gesture: RIGHT"));
        break;
      case PAJ7620_GESTURE_FORWARD:
        Serial.println(F("Gesture: FORWARD"));
        break;
      case PAJ7620_GESTURE_BACKWARD:
        Serial.println(F("Gesture: BACKWARD"));
        break;
      case PAJ7620_GESTURE_CLOCKWISE:
        Serial.println(F("Gesture: CLOCKWISE"));
        break;
      case PAJ7620_GESTURE_COUNTER_CLOCKWISE:
        Serial.println(F("Gesture: COUNTER-CLOCKWISE"));
        break;
      case PAJ7620_GESTURE_WAVE:
        Serial.println(F("Gesture: WAVE"));
        break;
      default:
        break;
    }
  }

  delay(20);
}
