/*
  Example: GY-302 (BH1750) Ambient Light Sensor
  Task:    Reads ambient illuminance in Lux over I2C.
  Pins:    I2C bus (SDA A4, SCL A5, address 0x23; alt 0x5C)
  Monitor: Serial Monitor at 115200 baud
*/

#include <kcomp_gy302.h>

void setup() {
  Serial.begin(115200);
  Serial.println("GY-302 (BH1750) Light Sensor Test");

  if (!initGY302(GY302_ADDR_DEFAULT)) {
    Serial.println("Error: GY-302 not found! Check I2C wiring.");
    while (1) { delay(100); }
  }

  // Modes: GY302_MODE_NORMAL (1 lx, 120 ms), GY302_MODE_HIGH (0.5 lx, 120 ms),
  //        GY302_MODE_FAST (4 lx, 16 ms for rapid light changes)
  setGY302Mode(GY302_MODE_NORMAL);
  Serial.println("Sensor initialized OK.");
}

void loop() {
  float lux = getGY302Lux();

  // The driver returns -1.0 on an I2C read error
  if (lux < 0) {
    Serial.println("Error reading GY-302 sensor.");
  } else {
    Serial.print("Light Level: ");
    Serial.print(lux);
    Serial.println(" lx");

    if (lux < 10) {
      Serial.println(" -> Very Dark");
    } else if (lux > 1000) {
      Serial.println(" -> Very Bright");
    }
  }

  delay(500);
}
