// SPDX-License-Identifier: MIT
// Copyright (c) 2025-2026 Andreas Kucher
//
// @module      ex_03_optics
// @title       K-Comp Examples: 03_Optics
// @targets     avr, esp32s3
// @bus         none (example collection)
// @timers      none
// @sram_bytes  0

#ifndef KCOMP_EX_03_OPTICS_H
#define KCOMP_EX_03_OPTICS_H

// Example-only library exposing '03_Optics' directly under Examples for K-Comp V2.

#endif
