# K-Comp Boards

This repository contains the source code and configuration files of K-Comp Boards
[platform](https://github.com/andkuc/k-comp/).
